/**
 * EasyPut NumPad — content.js v2
 * Manifest V3 · Fully refactored · Mobile-first
 *
 * Architecture:
 *   storage.js   — chrome.storage.local read/write
 *   selector.js  — visual element picker
 *   ui.js        — HTML builders
 *   float.js     — floating panel logic (drag, resize)
 *   sidebar.js   — sidebar logic (collapse, resizer)
 *   settings.js  — settings panel & persistence
 *   numpad.js    — button rendering & click logic
 *   main.js      — boot, inject, SPA watcher
 *
 * All modules are IIFEs merged into a single file for MV3 content-script
 * compatibility (no importScripts / ES modules in content scripts).
 */

(function () {
  'use strict';

  // ── Guard against double-injection ──────────────────────────────────────
  if (window.__numpadSidebarInjected) return;
  window.__numpadSidebarInjected = true;

  // ══════════════════════════════════════════════════════════════════════
  // CONSTANTS
  // ══════════════════════════════════════════════════════════════════════
  const IDs = {
    LAYOUT_ROOT: '__numpad_layout_root',
    PAGE_CONTAINER: '__numpad_page_container',
    SIDEBAR_WRAPPER: '__numpad_sidebar_wrapper',
    SIDEBAR_CONTENT: '__numpad_sidebar_content',
    RESIZER: '__numpad_sidebar_resizer',
    LAYOUT_STYLES: '__numpad_layout_styles',
    FLOAT_PANEL: '__numpad_float_panel',
    FLOAT_STYLES: '__numpad_float_styles',
  };

  const STORAGE_KEY = 'numpadSidebarStateV2';
  const DEFAULT_WIDTH = 300;
  const MIN_WIDTH = 220;
  const MAX_WIDTH = 580;
  const MIN_FLOAT_W = 200;
  const MIN_FLOAT_H = 260;

  // Default button values: 12 slots, NONE = hidden
  const DEFAULT_BUTTONS = ['7', '8', '9', '4', '5', '6', '1', '2', '3', '0', '10', 'NONE'];
  const DEFAULT_COLS = 3;
  const DEFAULT_ROWS = 4;

  // ══════════════════════════════════════════════════════════════════════
  // STATE
  // ══════════════════════════════════════════════════════════════════════
  let state = {
    enabled: true,
    open: true,
    width: DEFAULT_WIDTH,
    inputSelector: '',
    submitSelector: '',
    settingsOpen: false,
    activeTab: 'selector',   // 'selector' | 'buttons' | 'layout'
    // floating
    floating: false,
    floatX: 80,
    floatY: 80,
    floatW: 0,
    floatH: 0,
    // customizable numpad
    buttonValues: [...DEFAULT_BUTTONS],  // array of strings, 'NONE' = hidden
    gridCols: DEFAULT_COLS,
    gridRows: DEFAULT_ROWS,
    // selector presets (dropdown)
    inputPresets: [],      // [{id, label, value}] — input field presets only
    submitPresets: [],     // [{id, label, value}] — submit button presets only
    inputPresetId: '',     // selected preset id for input
    submitPresetId: '',    // selected preset id for submit
    // sidebar docking
    sidebarDock: 'right',  // 'left' | 'right' | 'top' | 'bottom'
  };

  // ══════════════════════════════════════════════════════════════════════
  // STORAGE MODULE
  // ══════════════════════════════════════════════════════════════════════
  function persist() {
    chrome.storage.local.set({ [STORAGE_KEY]: state });
  }

  function loadState(cb) {
    chrome.storage.local.get(STORAGE_KEY, (result) => {
      if (result[STORAGE_KEY]) {
        const saved = result[STORAGE_KEY];
        // Migration: ensure all new fields exist
        if (!saved.buttonValues) saved.buttonValues = [...DEFAULT_BUTTONS];
        if (!saved.gridCols) saved.gridCols = DEFAULT_COLS;
        if (!saved.gridRows) saved.gridRows = DEFAULT_ROWS;
        if (saved.enabled === undefined) saved.enabled = true;
        // Migrate legacy selectorPresets (shared pool) to split lists
        if (saved.selectorPresets && !saved.inputPresets) {
          saved.inputPresets = [...saved.selectorPresets];
          saved.submitPresets = [...saved.selectorPresets];
          delete saved.selectorPresets;
        }
        if (!saved.inputPresets) saved.inputPresets = [];
        if (!saved.submitPresets) saved.submitPresets = [];
        if (!saved.inputPresetId) saved.inputPresetId = '';
        if (!saved.submitPresetId) saved.submitPresetId = '';
        if (!saved.sidebarDock) saved.sidebarDock = 'right';
        // Migrate old single-string selector storage if present
        Object.assign(state, saved);
      }
      cb();
    });
  }

  // ══════════════════════════════════════════════════════════════════════
  // SELECTOR CAPTURE MODULE
  // ══════════════════════════════════════════════════════════════════════

  function escapeCssAttributeValue(value) {
    return String(value)
      .replace(/\\/g, '\\\\')
      .replace(/"/g, '\\"');
  }

  function isUniqueSelector(selector) {
    if (!selector) return false;
    try {
      return document.querySelectorAll(selector).length === 1;
    } catch {
      return false;
    }
  }

  function buildAttributeSelector(el, attrName) {
    const rawValue = el.getAttribute(attrName);
    if (!rawValue) return '';
    const selector = `${el.tagName.toLowerCase()}[${attrName}="${escapeCssAttributeValue(rawValue)}"]`;
    return isUniqueSelector(selector) ? selector : '';
  }

  function buildCssPathSelector(el) {
    const parts = [];
    let current = el;

    while (current && current.nodeType === Node.ELEMENT_NODE) {
      if (current === document.documentElement) {
        parts.unshift('html');
        break;
      }

      if (current === document.body) {
        parts.unshift('body');
        break;
      }

      if (current.id) {
        parts.unshift(`#${CSS.escape(current.id)}`);
        break;
      }

      let segment = current.tagName.toLowerCase();
      const safeClasses = Array.from(current.classList || [])
        .filter(c => !/^(active|hover|focus|disabled|ng-|v-|js-)/.test(c))
        .slice(0, 3)
        .map(c => `.${CSS.escape(c)}`)
        .join('');
      if (safeClasses) segment += safeClasses;

      const siblings = current.parentElement
        ? Array.from(current.parentElement.children).filter(child => child.tagName === current.tagName)
        : [];
      if (siblings.length > 1) {
        segment += `:nth-of-type(${siblings.indexOf(current) + 1})`;
      }

      parts.unshift(segment);
      current = current.parentElement;
    }

    const selector = parts.join(' > ');
    return selector && isUniqueSelector(selector) ? selector : '';
  }

  function xpathLiteral(value) {
    const text = String(value);
    if (!text.includes("'")) return `'${text}'`;
    if (!text.includes('"')) return `"${text}"`;

    const pieces = text.split("'");
    const parts = [];
    pieces.forEach((piece, index) => {
      if (index > 0) parts.push(`"'"`);
      parts.push(`'${piece}'`);
    });
    return `concat(${parts.join(', ')})`;
  }

  function buildXPathSelector(el) {
    const segments = [];
    let current = el;

    while (current && current.nodeType === Node.ELEMENT_NODE) {
      const tag = current.tagName.toLowerCase();

      if (current === document.documentElement) {
        segments.unshift('html');
        break;
      }

      if (current === document.body) {
        segments.unshift('body');
        break;
      }

      if (current.id) {
        segments.unshift(`*[@id=${xpathLiteral(current.id)}]`);
        break;
      }

      const siblings = current.parentElement
        ? Array.from(current.parentElement.children).filter(child => child.tagName === current.tagName)
        : [];
      const index = siblings.length > 1 ? siblings.indexOf(current) + 1 : 1;
      segments.unshift(`${tag}[${index}]`);
      current = current.parentElement;
    }

    return `//${segments.join('/')}`;
  }

  /**
   * Generate a DevTools-style selector with the requested priority:
   * id → name → data-* → aria-* → unique CSS selector → XPath fallback.
   */
  function generateSelector(el) {
    if (!el || el.nodeType !== Node.ELEMENT_NODE || el === document.body) return '';

    if (el.id) {
      return `${el.tagName.toLowerCase()}#${CSS.escape(el.id)}`;
    }

    const nameSelector = buildAttributeSelector(el, 'name');
    if (nameSelector) return nameSelector;

    for (const attr of Array.from(el.attributes || [])) {
      if (attr.name.startsWith('data-') && attr.value) {
        const selector = buildAttributeSelector(el, attr.name);
        if (selector) return selector;
      }
    }

    for (const attr of Array.from(el.attributes || [])) {
      if (attr.name.startsWith('aria-') && attr.value) {
        const selector = buildAttributeSelector(el, attr.name);
        if (selector) return selector;
      }
    }

    const cssSelector = buildCssPathSelector(el);
    if (cssSelector) return cssSelector;

    return buildXPathSelector(el);
  }



  // ══════════════════════════════════════════════════════════════════════
  // STYLES
  // ══════════════════════════════════════════════════════════════════════

  /**
   * Writes layout CSS into the injected <style> tag.
   * IMPORTANT: sidebar size (width/height) is NOT set here — it is always
   * set via inline styles by applySidebarSize() so that dynamic updates
   * (collapse, resize, enable/disable) work without a reload.
   * Only structural/positional rules that don't change at runtime live here.
   */
  function applyLayoutStyles() {
    let el = document.getElementById(IDs.LAYOUT_STYLES);
    if (!el) {
      el = document.createElement('style');
      el.id = IDs.LAYOUT_STYLES;
      document.head.appendChild(el);
    }
    const dock = state.sidebarDock || 'right';
    const isHoriz = dock === 'top' || dock === 'bottom';

    // flex-direction: sidebar comes after page for right/bottom, before for left/top
    // right → row,         page first, sidebar last
    // left  → row-reverse, sidebar first (visually left), page second
    // bottom→ column,      page first, sidebar last
    // top   → column-reverse, sidebar first (visually top), page second
    const flexDirMap = { right: 'row', left: 'row-reverse', bottom: 'column', top: 'column-reverse' };
    const flexDir = flexDirMap[dock];

    // Border on the side that faces the page
    const borderSide = { left: 'border-right', right: 'border-left', top: 'border-bottom', bottom: 'border-top' }[dock];
    // Shadow direction
    const shadowMap = { left: '6px 0 28px', right: '-6px 0 28px', top: '0 6px 28px', bottom: '0 -6px 28px' };
    const shadowDir = shadowMap[dock];

    // Resizer position — on the inner edge of the sidebar facing the page
    const resizerCSS = isHoriz ? `
      width: 100% !important; height: 6px !important;
      cursor: ns-resize !important;
      left: 0 !important; right: 0 !important;
      ${dock === 'top' ? 'bottom: 0 !important; top: auto !important;' : 'top: 0 !important; bottom: auto !important;'}
    ` : `
      height: 100% !important; width: 6px !important;
      cursor: ew-resize !important;
      top: 0 !important; bottom: 0 !important;
      ${dock === 'right' ? 'left: 0 !important; right: auto !important;' : 'right: 0 !important; left: auto !important;'}
    `;

    // Sidebar structural rules — NO width/height here (set via inline style)
    const sidebarStructural = isHoriz
      ? 'width: 100% !important;'
      : 'height: 100% !important;';

    el.textContent = `
      html {
        width: 100% !important; height: 100% !important;
        margin: 0 !important; padding: 0 !important;
        overflow: hidden !important;
      }
      body {
        margin: 0 !important; padding: 0 !important;
        width: 100% !important; height: 100% !important;
        overflow: hidden !important;
      }
      #${IDs.LAYOUT_ROOT} {
        display: flex !important;
        flex-direction: ${flexDir} !important;
        width: 100vw !important; height: 100vh !important;
        position: fixed !important;
        top: 0 !important; left: 0 !important;
        right: 0 !important; bottom: 0 !important;
        z-index: 2147483646 !important; box-sizing: border-box !important;
      }
      #${IDs.PAGE_CONTAINER} {
        flex: 1 !important; min-width: 0 !important; min-height: 0 !important;
        overflow: auto !important; display: flex !important;
        flex-direction: column !important; position: relative !important;
        background: inherit !important;
      }
      #${IDs.PAGE_CONTAINER} > * { flex-shrink: 0 !important; }
      #${IDs.SIDEBAR_WRAPPER} {
        flex-shrink: 0 !important; display: flex !important;
        flex-direction: column !important; position: relative !important;
        background: var(--np-bg, #1a1b1e) !important;
        ${borderSide}: 1.5px solid var(--np-border, #373a40) !important;
        box-shadow: ${shadowDir} rgba(0,0,0,0.55) !important;
        overflow: hidden !important; z-index: 2147483647 !important;
        transition: width 0.28s cubic-bezier(0.4, 0, 0.2, 1),
                    height 0.28s cubic-bezier(0.4, 0, 0.2, 1) !important;
        box-sizing: border-box !important;
        ${sidebarStructural}
      }
      #${IDs.SIDEBAR_CONTENT} {
        display: flex !important; flex-direction: column !important;
        width: 100% !important; height: 100% !important;
        overflow-y: auto !important; overflow-x: hidden !important;
      }
      #${IDs.RESIZER} {
        position: absolute !important;
        ${resizerCSS}
        background: transparent !important;
        transition: background 0.15s !important;
        touch-action: none !important;
        z-index: 1000 !important;
      }
    `;
  }

  // ══════════════════════════════════════════════════════════════════════
  // HTML BUILDERS
  // ══════════════════════════════════════════════════════════════════════

  function escAttr(s) {
    return (s || '').replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  /** Build the numpad grid HTML for a given prefix */
  function buildNumpadGridHTML(prefix) {
    const vals = state.buttonValues;
    const visibleVals = vals.filter(v => v && v !== 'NONE');
    const btnHTML = visibleVals.map(v => `
      <button class="np-btn" data-value="${escAttr(v)}" aria-label="Insert ${escAttr(v)}"
        style="user-select:none;-webkit-user-select:none;cursor:pointer;">
        <span class="np-btn-label"
          style="user-select:none;-webkit-user-select:none;pointer-events:none;">${escAttr(v)}</span>
        <span class="np-btn-ripple"></span>
      </button>
    `).join('');

    return `
      <div class="np-grid" id="${prefix}-grid"
        style="--np-cols:${state.gridCols};">${btnHTML}</div>
      <div class="np-status" id="${prefix}-status"></div>
    `;
  }

  /** Build selector dropdown HTML for a given type (input|submit) */
  function buildSelectorDropdownHTML(prefix, type) {
    const presetId = type === 'input' ? state.inputPresetId : state.submitPresetId;
    const presets = type === 'input' ? state.inputPresets : state.submitPresets;
    const label = type === 'input' ? '⌨️ Input Field' : '🖱️ Submit Button';
    const editingPreset = presets.find(p => p.id === presetId);
    const options = [
      `<option value="" ${!presetId ? 'selected' : ''}>None</option>`,
      ...presets.map(p =>
        `<option value="${escAttr(p.id)}" ${p.id === presetId ? 'selected' : ''}>${escAttr(p.label)}</option>`
      ),
      `<option value="__add_new__">+ Add New</option>`,
    ].join('');

    return `
      <div class="np-sel-group" id="${prefix}-${type}-sel-group">
        <p class="np-settings-label">${label}</p>
        <div class="np-selector-row">
          <select class="np-sel-dropdown" id="${prefix}-${type}-dropdown" data-sel-type="${type}">
            ${options}
          </select>
        </div>
        ${editingPreset ? `
          <div class="np-preset-edit-row" id="${prefix}-${type}-edit-row">
            <input class="np-settings-input np-preset-label-input" id="${prefix}-${type}-label-inp"
              type="text" placeholder="Name…" value="${escAttr(editingPreset.label)}" maxlength="32">
            <div class="np-selector-input-row">
              <input class="np-settings-input np-preset-value-input" id="${prefix}-${type}-value-inp"
                type="text" placeholder="CSS selector…" value="${escAttr(editingPreset.value)}" maxlength="256">
              <button class="np-icon-btn np-pick-element-btn" data-action="pick-element" data-preset-type="${type}"
                id="${prefix}-${type}-pick-btn"
                title="Click to activate element picker — then click any element on the page">
                <svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14">
                  <path fill-rule="evenodd" d="M6.672 1.911a1 1 0 10-1.932.518l.259.966a1 1 0 001.932-.518l-.26-.966zM2.429 4.74a1 1 0 10-.518 1.932l.966.259a1 1 0 00.518-1.932l-.966-.26zm8.814-.569a1 1 0 00-1.415-1.414l-.707.707a1 1 0 101.415 1.415l.707-.708zm-7.071 7.072l.707-.707A1 1 0 003.465 9.12l-.707.707a1 1 0 101.415 1.415zm3.2-5.171a1 1 0 00-1.3 1.3l4 10a1 1 0 001.823.075l1.38-2.759 3.018 3.02a1 1 0 001.414-1.415l-3.019-3.02 2.76-1.379a1 1 0 00-.076-1.822l-10-4z" clip-rule="evenodd"/>
                </svg>
              </button>
            </div>
            <div class="np-preset-actions">
              <button class="np-save-btn np-preset-save-btn" data-action="save-preset" data-preset-type="${type}">Save</button>
              <button class="np-icon-btn np-preset-del-btn" data-action="delete-preset" data-preset-type="${type}"
                title="Delete preset" style="color:var(--np-error)">
                <svg viewBox="0 0 20 20" fill="currentColor" width="13" height="13">
                  <path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clip-rule="evenodd"/>
                </svg>
              </button>
            </div>
          </div>
        ` : `<div class="np-selector-preview" id="${prefix}-${type}-preview">${presetId && !editingPreset ? 'Preset not found' : 'None selected'}</div>`}
      </div>
    `;
  }

  /** Build settings tabs HTML */
  function buildSettingsHTML(prefix) {
    const active = state.activeTab;
    return `
      <div class="np-tabs">
        <button class="np-tab ${active === 'selector' ? 'np-tab-active' : ''}"
          data-tab="selector">Selectors</button>
        <button class="np-tab ${active === 'buttons' ? 'np-tab-active' : ''}"
          data-tab="buttons">Buttons</button>
        <button class="np-tab ${active === 'layout' ? 'np-tab-active' : ''}"
          data-tab="layout">Layout</button>
        <button class="np-tab ${active === 'dock' ? 'np-tab-active' : ''}"
          data-tab="dock">Dock</button>
      </div>

      <!-- Tab: Selectors -->
      <div class="np-tab-content ${active === 'selector' ? 'np-tab-visible' : ''}" data-tab-content="selector">
        ${buildSelectorDropdownHTML(prefix, 'input')}
        ${buildSelectorDropdownHTML(prefix, 'submit')}
        <div class="np-settings-hint">Select a saved preset or add a new one to set the CSS selector.</div>
      </div>

      <!-- Tab: Buttons -->
      <div class="np-tab-content ${active === 'buttons' ? 'np-tab-visible' : ''}" data-tab-content="buttons">
        <div class="np-settings-hint" style="margin-bottom:4px;">
          Each slot is a button value. Leave blank or type NONE to hide that button.
        </div>
        <div class="np-btn-editor-grid" id="${prefix}-btn-editor">
          ${state.buttonValues.map((v, i) => `
            <div class="np-btn-slot">
              <span class="np-btn-slot-label">#${i + 1}</span>
              <input class="np-btn-slot-input" type="text"
                data-slot="${i}"
                value="${v === 'NONE' ? '' : escAttr(v)}"
                placeholder="NONE"
                maxlength="8">
            </div>
          `).join('')}
        </div>
        <button class="np-save-btn" data-action="save-buttons" style="margin-top:8px;">Apply Buttons</button>
        <div class="np-settings-hint">Examples: 0, 2, 3.5, A+, ABS. Empty = hidden button.</div>
      </div>

      <!-- Tab: Layout -->
      <div class="np-tab-content ${active === 'layout' ? 'np-tab-visible' : ''}" data-tab-content="layout">
        <div class="np-settings-hint" style="margin-bottom:4px;">Set the grid columns and rows for your numpad.</div>
        <div class="np-grid-controls">
          <div class="np-grid-ctrl-group">
            <p class="np-settings-label">Columns</p>
            <input class="np-number-input" id="${prefix}-grid-cols" type="number"
              min="1" max="6" value="${state.gridCols}">
          </div>
          <div class="np-grid-ctrl-group">
            <p class="np-settings-label">Rows (slots)</p>
            <input class="np-number-input" id="${prefix}-grid-rows" type="number"
              min="1" max="10" value="${state.gridRows}">
          </div>
        </div>
        <button class="np-save-btn" data-action="save-layout" style="margin-top:8px;">Apply Layout</button>
        <div class="np-settings-hint">Increasing rows adds more button slots in the Buttons tab.</div>
      </div>

      <!-- Tab: Dock -->
      <div class="np-tab-content ${active === 'dock' ? 'np-tab-visible' : ''}" data-tab-content="dock">
        <div class="np-settings-hint" style="margin-bottom:6px;">Choose which side to dock the sidebar.</div>
        <div class="np-dock-grid">
          ${['left', 'right', 'top', 'bottom'].map(side => `
            <button class="np-dock-btn ${state.sidebarDock === side ? 'np-dock-active' : ''}"
              data-action="set-dock" data-dock="${side}">
              ${side.charAt(0).toUpperCase() + side.slice(1)}
            </button>
          `).join('')}
        </div>
      </div>
    `;
  }

  function buildSidebarHTML() {
    const numpadHidden = state.floating ? 'style="display:none"' : '';
    const placeholderShown = state.floating ? 'style="display:flex"' : 'style="display:none"';

    return `
      <div class="np-header">
        <div class="np-header-left">
          <button class="np-icon-btn np-collapse-btn" id="np-collapse-btn"
            title="${state.open ? 'Collapse sidebar' : 'Expand sidebar'}"
            style="user-select:none;">
            <svg class="np-chevron" viewBox="0 0 20 20" fill="currentColor" width="15" height="15">
              <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"/>
            </svg>
          </button>
        </div>
        <div class="np-header-actions">
          <button class="np-power-toggle ${state.enabled ? 'np-on' : 'np-off'}"
            id="np-power-toggle" title="${state.enabled ? 'Disable extension' : 'Enable extension'}"
            style="user-select:none;">
            <span class="np-power-dot"></span>
            <span>${state.enabled ? 'ON' : 'OFF'}</span>
          </button>
          <button class="np-icon-btn" id="np-float-toggle-btn" title="Detach to floating window"
            style="user-select:none;">
            <svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14">
              <path d="M3 5a2 2 0 012-2h4a1 1 0 010 2H5v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H5a2 2 0 01-2-2V5z"/>
              <path d="M15 3h2a1 1 0 011 1v2a1 1 0 11-2 0V5.414l-5.293 5.293a1 1 0 01-1.414-1.414L14.586 4H14a1 1 0 110-2z"/>
            </svg>
          </button>
          <button class="np-icon-btn np-settings-btn" id="np-settings-toggle" title="Settings"
            style="user-select:none;">
            <svg viewBox="0 0 20 20" fill="currentColor" width="15" height="15">
              <path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"/>
            </svg>
          </button>
        </div>
      </div>

      <div class="np-settings-panel ${state.settingsOpen ? 'np-settings-open' : ''}" id="np-settings-panel">
        ${buildSettingsHTML('np-sidebar')}
      </div>

      <div class="np-pad-area" id="np-pad-area-sidebar" ${numpadHidden}>
        ${buildNumpadGridHTML('np-sidebar')}
      </div>

      <div id="np-floating-placeholder" ${placeholderShown}
        style="flex-direction:column;align-items:center;justify-content:center;
               padding:24px 16px;gap:10px;color:var(--np-text-muted,#868e96);
               font-size:11px;text-align:center;flex:1;
               user-select:none;-webkit-user-select:none;">
        <svg viewBox="0 0 20 20" fill="currentColor" width="24" height="24" style="opacity:0.35;pointer-events:none;">
          <path d="M3 5a2 2 0 012-2h4a1 1 0 010 2H5v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H5a2 2 0 01-2-2V5z"/>
          <path d="M15 3h2a1 1 0 011 1v2a1 1 0 11-2 0V5.414l-5.293 5.293a1 1 0 01-1.414-1.414L14.586 4H14a1 1 0 110-2z"/>
        </svg>
        <span style="opacity:0.55;">NumPad is floating</span>
      </div>
    `;
  }

  function buildFloatPanelHTML() {
    return `
      <!-- Resize handle: bottom-left only -->
      <div class="np-resize-handle-bl" id="np-float-resize-bl">
        <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor">
          <path d="M0 12 L12 0 L12 2 L2 12 Z M0 12 L6 12 L12 6 L12 8 L8 12 Z"/>
        </svg>
      </div>

      <div class="np-float-titlebar" id="np-float-titlebar">
        <!-- Drag handle: top-left icon only -->
        <div class="np-drag-handle" id="np-float-drag-handle" title="Drag to move">
          <svg viewBox="0 0 20 20" fill="currentColor" width="16" height="16">
            <path d="M7 2a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM13 2a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM7 8a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM13 8a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM7 14a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM13 14a2 2 0 1 1 0 4 2 2 0 0 1 0-4z"/>
          </svg>
        </div>
        <div class="np-float-title-center">
          <span class="np-float-logo">⌨</span>
          <span class="np-float-label">NumPad</span>
        </div>
        <div class="np-float-actions">
          <button class="np-icon-btn" id="np-float-settings-toggle" title="Settings"
            style="user-select:none;">
            <svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14">
              <path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"/>
            </svg>
          </button>
          <button class="np-icon-btn" id="np-dock-btn" title="Dock back to sidebar"
            style="user-select:none;">
            <svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14">
              <path fill-rule="evenodd" d="M3 4a1 1 0 011-1h12a1 1 0 011 1v12a1 1 0 01-1 1H4a1 1 0 01-1-1V4zm2 1v10h10V5H5z" clip-rule="evenodd"/>
              <path d="M8 9a1 1 0 011-1h2a1 1 0 010 2H9a1 1 0 01-1-1z"/>
            </svg>
          </button>
        </div>
      </div>

      <div class="np-settings-panel" id="np-float-settings-panel">
        ${buildSettingsHTML('np-float')}
      </div>

      <div class="np-float-body">
        ${buildNumpadGridHTML('np-float')}
      </div>
    `;
  }

  // ══════════════════════════════════════════════════════════════════════
  // DOM INJECTION
  // ══════════════════════════════════════════════════════════════════════

  function inject() {
    if (document.getElementById(IDs.LAYOUT_ROOT)) return;

    const scrollX = window.scrollX || 0;
    const scrollY = window.scrollY || 0;

    const layoutRoot = document.createElement('div');
    layoutRoot.id = IDs.LAYOUT_ROOT;

    const pageContainer = document.createElement('div');
    pageContainer.id = IDs.PAGE_CONTAINER;

    const sidebarWrapper = document.createElement('aside');
    sidebarWrapper.id = IDs.SIDEBAR_WRAPPER;

    // Compute sidebar width
    const sidebarW = computeSidebarSize();
    applySidebarSize(sidebarWrapper, sidebarW);

    const sidebarContent = document.createElement('div');
    sidebarContent.id = IDs.SIDEBAR_CONTENT;
    sidebarContent.innerHTML = buildSidebarHTML();

    const resizer = document.createElement('div');
    resizer.id = IDs.RESIZER;
    resizer.className = 'np-resizer';
    resizer.title = 'Drag to resize';

    sidebarWrapper.appendChild(resizer);
    sidebarWrapper.appendChild(sidebarContent);

    while (document.body.firstChild) {
      pageContainer.appendChild(document.body.firstChild);
    }

    layoutRoot.appendChild(pageContainer);
    layoutRoot.appendChild(sidebarWrapper);
    document.body.appendChild(layoutRoot);

    applyLayoutStyles();
    window.scrollTo(scrollX, scrollY);

    attachSidebarListeners();

    if (!state.enabled) {
      applySidebarVisibility(false);
    }

    if (state.floating) {
      createFloatPanel();
    }
  }

  function computeSidebarSize() {
    if (!state.enabled) return 0;
    if (state.floating) return 32;
    return state.open ? state.width : 32;
  }

  function applySidebarSize(wrapper, size) {
    const dock = state.sidebarDock || 'right';
    const isHoriz = dock === 'top' || dock === 'bottom';
    if (isHoriz) {
      wrapper.style.height = size + 'px';
      wrapper.style.width = '';   // stylesheet handles 100%
    } else {
      wrapper.style.width = size + 'px';
      wrapper.style.height = '';  // stylesheet handles 100%
    }
  }

  // ══════════════════════════════════════════════════════════════════════
  // ENABLE / DISABLE
  // ══════════════════════════════════════════════════════════════════════

  function applySidebarVisibility(show) {
    const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER);
    if (!wrapper) return;
    if (!show) {
      // Zero out both dimensions; applySidebarSize will fix on re-enable
      wrapper.style.width = '0px';
      wrapper.style.height = '0px';
      wrapper.style.overflow = 'hidden';
      // Also hide float panel
      const fp = document.getElementById(IDs.FLOAT_PANEL);
      if (fp) fp.style.display = 'none';
    } else {
      wrapper.style.overflow = '';
      applySidebarSize(wrapper, computeSidebarSize());
      const fp = document.getElementById(IDs.FLOAT_PANEL);
      if (fp) fp.style.display = '';
    }
  }

  function toggleEnabled() {
    state.enabled = !state.enabled;
    persist();

    // Update power toggle button
    const btn = document.getElementById('np-power-toggle');
    if (btn) {
      btn.className = `np-power-toggle ${state.enabled ? 'np-on' : 'np-off'}`;
      btn.title = state.enabled ? 'Disable extension' : 'Enable extension';
      btn.querySelector('span:last-child').textContent = state.enabled ? 'ON' : 'OFF';
    }

    applySidebarVisibility(state.enabled);
  }

  // ══════════════════════════════════════════════════════════════════════
  // FLOATING PANEL
  // ══════════════════════════════════════════════════════════════════════

  function createFloatPanel() {
    removeFloatPanel();

    const panel = document.createElement('div');
    panel.id = IDs.FLOAT_PANEL;
    panel.innerHTML = buildFloatPanelHTML();

    // Clamp position to viewport
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    state.floatX = Math.max(0, Math.min(state.floatX, vw - MIN_FLOAT_W));
    state.floatY = Math.max(0, Math.min(state.floatY, vh - MIN_FLOAT_H));

    panel.style.left = state.floatX + 'px';
    panel.style.top = state.floatY + 'px';

    if (state.floatW > 0) {
      panel.style.width = state.floatW + 'px';
      panel.style.height = state.floatH + 'px';
    }

    if (!state.enabled) {
      panel.style.display = 'none';
    }

    // Append to documentElement so float panel sits above the layout root
    document.documentElement.appendChild(panel);

    if (state.floatW === 0) {
      requestAnimationFrame(() => {
        const rect = panel.getBoundingClientRect();
        state.floatW = Math.round(rect.width);
        state.floatH = Math.round(rect.height);
        panel.style.width = state.floatW + 'px';
        panel.style.height = state.floatH + 'px';
        persist();
      });
    }

    attachFloatListeners(panel);
  }

  function removeFloatPanel() {
    document.getElementById(IDs.FLOAT_PANEL)?.remove();
  }

  function enterFloating() {
    state.floating = true;
    state.floatW = 0;
    persist();

    const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER);
    if (wrapper) applySidebarSize(wrapper, 32);

    const padArea = document.getElementById('np-pad-area-sidebar');
    const placeholder = document.getElementById('np-floating-placeholder');
    if (padArea) padArea.style.display = 'none';
    if (placeholder) placeholder.style.display = 'flex';

    createFloatPanel();
  }

  function exitFloating() {
    state.floating = false;
    persist();

    removeFloatPanel();

    const padArea = document.getElementById('np-pad-area-sidebar');
    const placeholder = document.getElementById('np-floating-placeholder');
    if (padArea) padArea.style.display = '';
    if (placeholder) placeholder.style.display = 'none';

    // FIX: Always restore sidebar visibility on un-float (mobile fix)
    const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER);
    if (wrapper) {
      applySidebarSize(wrapper, state.enabled ? (state.open ? state.width : 32) : 0);
    }

    bindNumpadButtons('np-sidebar');
  }

  // ══════════════════════════════════════════════════════════════════════
  // SIDEBAR LISTENERS
  // ══════════════════════════════════════════════════════════════════════

  function attachSidebarListeners() {
    document.getElementById('np-collapse-btn')?.addEventListener('click', toggleSidebar);
    document.getElementById('np-settings-toggle')?.addEventListener('click', () => toggleSettings('np-settings-panel'));
    document.getElementById('np-float-toggle-btn')?.addEventListener('click', enterFloating);
    document.getElementById('np-power-toggle')?.addEventListener('click', toggleEnabled);

    // Settings panel delegation
    const settingsPanel = document.getElementById('np-settings-panel');
    if (settingsPanel) {
      attachSettingsPanelListeners(settingsPanel, 'np-sidebar');
    }

    bindNumpadButtons('np-sidebar');
    initSidebarResizer();
  }

  // ══════════════════════════════════════════════════════════════════════
  // FLOAT LISTENERS
  // ══════════════════════════════════════════════════════════════════════

  function attachFloatListeners(panel) {
    panel.querySelector('#np-dock-btn')?.addEventListener('click', exitFloating);

    panel.querySelector('#np-float-settings-toggle')?.addEventListener('click', () => {
      toggleSettings('np-float-settings-panel');
    });

    const settingsPanel = panel.querySelector('#np-float-settings-panel');
    if (settingsPanel) {
      attachSettingsPanelListeners(settingsPanel, 'np-float');
    }

    bindNumpadButtons('np-float');
    initFloatDrag(panel);
    initFloatResize(panel);
  }

  // ══════════════════════════════════════════════════════════════════════
  // SETTINGS PANEL LOGIC (shared between sidebar + float)
  // ══════════════════════════════════════════════════════════════════════

  function attachSettingsPanelListeners(panel, prefix) {
    // Tab switching
    panel.querySelectorAll('.np-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        const tabName = tab.dataset.tab;
        state.activeTab = tabName;
        document.querySelectorAll('.np-tab').forEach(t => {
          t.classList.toggle('np-tab-active', t.dataset.tab === tabName);
        });
        document.querySelectorAll('.np-tab-content').forEach(c => {
          c.classList.toggle('np-tab-visible', c.dataset.tabContent === tabName);
        });
        persist();
      });
    });

    // Attach selector tab listeners
    const selectorTab = panel.querySelector('[data-tab-content="selector"]');
    if (selectorTab) attachSelectorTabListeners(selectorTab, prefix);

    // Save buttons (delegated by data-action) — non-selector actions
    panel.addEventListener('click', (e) => {
      const actionEl = e.target.closest('[data-action]');
      if (!actionEl) return;
      const action = actionEl.dataset.action;

      if (action === 'save-buttons') {
        const inputs = panel.querySelectorAll('.np-btn-slot-input');
        state.buttonValues = Array.from(inputs).map(inp => {
          const v = inp.value.trim();
          return v === '' ? 'NONE' : v;
        });
        persist();
        rebuildAllNumpadGrids();
        showStatus(`${prefix}-status`, 'Buttons updated ✓', 'success');
      }

      if (action === 'save-layout') {
        const colsEl = panel.querySelector(`#${prefix}-grid-cols`);
        const rowsEl = panel.querySelector(`#${prefix}-grid-rows`);
        const cols = Math.max(1, Math.min(6, parseInt(colsEl?.value) || DEFAULT_COLS));
        const rows = Math.max(1, Math.min(10, parseInt(rowsEl?.value) || DEFAULT_ROWS));
        state.gridCols = cols;
        state.gridRows = rows;
        const newLen = rows * cols;
        while (state.buttonValues.length < newLen) state.buttonValues.push('NONE');
        state.buttonValues = state.buttonValues.slice(0, newLen);
        persist();
        rebuildAll();
        showStatus(`${prefix}-status`, 'Layout updated ✓', 'success');
      }

      if (action === 'set-dock') {
        const newDock = actionEl.dataset.dock;
        state.sidebarDock = newDock;
        persist();
        document.querySelectorAll('[data-action="set-dock"]').forEach(b => {
          b.classList.toggle('np-dock-active', b.dataset.dock === newDock);
        });
        // Update stylesheet for new dock direction/border/shadow/resizer
        applyLayoutStyles();
        // Re-apply inline size after dock change (clears stale width or height)
        const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER);
        if (wrapper) applySidebarSize(wrapper, computeSidebarSize());
        // Re-init resizer so it uses the new axis
        initSidebarResizer();
      }
    });
  }

  /**
   * Attach selector dropdown + picker + save/delete listeners inside a selector tab element.
   * Called both from attachSettingsPanelListeners and rebuildAllSelectorDropdowns.
   */
  function attachSelectorTabListeners(tabEl, prefix) {
    tabEl.querySelectorAll('.np-sel-dropdown').forEach(sel => {
      sel.addEventListener('change', () => {
        const type = sel.dataset.selType;
        const val = sel.value;
        const presets = type === 'input' ? state.inputPresets : state.submitPresets;
        if (val === '__add_new__') {
          const newId = 'preset_' + Date.now();
          presets.push({ id: newId, label: 'New Selector', value: '' });
          if (type === 'input') { state.inputPresetId = newId; state.inputSelector = ''; }
          else { state.submitPresetId = newId; state.submitSelector = ''; }
          persist();
          rebuildAllSelectorDropdowns();
        } else if (val === '') {
          if (type === 'input') { state.inputPresetId = ''; state.inputSelector = ''; }
          else { state.submitPresetId = ''; state.submitSelector = ''; }
          persist();
          rebuildAllSelectorDropdowns();
        } else {
          const preset = presets.find(p => p.id === val);
          if (preset) {
            if (type === 'input') { state.inputPresetId = val; state.inputSelector = preset.value; }
            else { state.submitPresetId = val; state.submitSelector = preset.value; }
            persist();
            rebuildAllSelectorDropdowns();
          }
        }
      });
    });


    tabEl.addEventListener('click', (e) => {
      const actionEl = e.target.closest('[data-action]');
      if (!actionEl) return;
      const action = actionEl.dataset.action;

      if (action === 'save-preset') {
        const type = actionEl.dataset.presetType;
        const presetId = type === 'input' ? state.inputPresetId : state.submitPresetId;
        const presets = type === 'input' ? state.inputPresets : state.submitPresets;
        const preset = presets.find(p => p.id === presetId);
        if (!preset) return;
        const labelInp = tabEl.querySelector(`#${prefix}-${type}-label-inp`);
        const valueInp = tabEl.querySelector(`#${prefix}-${type}-value-inp`);
        if (labelInp) preset.label = labelInp.value.trim() || preset.label;
        if (valueInp) {
          preset.value = valueInp.value.trim();
          if (type === 'input') state.inputSelector = preset.value;
          else state.submitSelector = preset.value;
        }
        persist();
        rebuildAllSelectorDropdowns();
      }

      if (action === 'delete-preset') {
        const type = actionEl.dataset.presetType;
        const presetId = type === 'input' ? state.inputPresetId : state.submitPresetId;
        if (type === 'input') {
          state.inputPresets = state.inputPresets.filter(p => p.id !== presetId);
          state.inputPresetId = ''; state.inputSelector = '';
        } else {
          state.submitPresets = state.submitPresets.filter(p => p.id !== presetId);
          state.submitPresetId = ''; state.submitSelector = '';
        }
        persist();
        rebuildAllSelectorDropdowns();
      }

      if (action === 'pick-element') {
        const type = actionEl.dataset.presetType;
        const valueInp = tabEl.querySelector(`#${prefix}-${type}-value-inp`);
        if (!valueInp) return;



        // Highlight overlay
        const highlight = document.createElement('div');
        highlight.id = '__ep-picker-highlight';
        highlight.style.cssText = 'position:fixed;pointer-events:none;z-index:2147483647;outline:2px solid #3b82f6;background:rgba(59,130,246,0.1);transition:none;box-sizing:border-box;';
        document.body.appendChild(highlight);

        // Cursor
        document.body.style.cursor = 'crosshair';

        let lastTarget = null;

        const onMove = (e) => {
          const el = document.elementFromPoint(e.clientX, e.clientY);
          if (!el || el === highlight || lastTarget === el) return;
          lastTarget = el;
          const r = el.getBoundingClientRect();
          highlight.style.left = r.left + 'px';
          highlight.style.top = r.top + 'px';
          highlight.style.width = r.width + 'px';
          highlight.style.height = r.height + 'px';
        };

        const cleanup = () => {
          document.removeEventListener('mousemove', onMove, true);
          document.removeEventListener('click', onClick, true);
          document.removeEventListener('keydown', onKey, true);
          highlight.remove();
          document.body.style.cursor = '';
        };

        const onClick = (e) => {
          e.preventDefault();
          e.stopPropagation();
          cleanup();

          const el = document.elementFromPoint(e.clientX, e.clientY);
          if (!el) return;

          // Build tag#id selector (fallback to generateSelector)
          const selector = el.id
            ? `${el.tagName.toLowerCase()}#${CSS.escape(el.id)}`
            : generateSelector(el);

          if (!selector) return;

          valueInp.value = selector;
          // Also update the preset value in state so Save works immediately
          const presetId = type === 'input' ? state.inputPresetId : state.submitPresetId;
          const presets = type === 'input' ? state.inputPresets : state.submitPresets;
          const preset = presets.find(p => p.id === presetId);
          if (preset) {
            preset.value = selector;
            if (type === 'input') state.inputSelector = selector;
            else state.submitSelector = selector;
            persist();
          }
        };

        const onKey = (e) => {
          if (e.key === 'Escape') { cleanup(); }
        };

        document.addEventListener('mousemove', onMove, true);
        document.addEventListener('click', onClick, true);
        document.addEventListener('keydown', onKey, true);
      }

    });
  }

  /**
   * Rebuild only the selector tab content in all open settings panels
   */
  function rebuildAllSelectorDropdowns() {
    ['np-sidebar', 'np-float'].forEach(prefix => {
      const panelId = prefix === 'np-sidebar' ? 'np-settings-panel' : 'np-float-settings-panel';
      const panel = document.getElementById(panelId);
      if (!panel) return;
      const selectorTab = panel.querySelector('[data-tab-content="selector"]');
      if (!selectorTab) return;
      selectorTab.innerHTML =
        buildSelectorDropdownHTML(prefix, 'input') +
        buildSelectorDropdownHTML(prefix, 'submit') +
        '<div class="np-settings-hint">Select a saved preset or pick 🎯 a new element on the page.</div>';
      attachSelectorTabListeners(selectorTab, prefix);
    });
  }

  function collapseAllSettingsPanels() {
    document.querySelectorAll('.np-settings-panel').forEach(p => {
      p.classList.remove('np-settings-open');
    });
  }

  /**
   * Rebuild just the numpad grids without full re-render
   */
  function rebuildAllNumpadGrids() {
    ['np-sidebar', 'np-float'].forEach(prefix => {
      const grid = document.getElementById(`${prefix}-grid`);
      if (!grid) return;
      const cols = state.gridCols;
      grid.style.setProperty('--np-cols', cols);

      const visibleVals = state.buttonValues.filter(v => v && v !== 'NONE');
      grid.innerHTML = visibleVals.map(v => `
        <button class="np-btn" data-value="${escAttr(v)}" aria-label="Insert ${escAttr(v)}"
          style="user-select:none;-webkit-user-select:none;cursor:pointer;">
          <span class="np-btn-label"
            style="user-select:none;-webkit-user-select:none;pointer-events:none;">${escAttr(v)}</span>
          <span class="np-btn-ripple"></span>
        </button>
      `).join('');

      bindNumpadButtons(prefix);
    });
  }

  /**
   * Full re-render of sidebar + float
   */
  function rebuildAll() {
    // Rebuild sidebar content
    const sidebarContent = document.getElementById(IDs.SIDEBAR_CONTENT);
    if (sidebarContent) {
      sidebarContent.innerHTML = buildSidebarHTML();
      attachSidebarListeners();
    }
    // Rebuild float panel if active
    if (state.floating) {
      createFloatPanel();
    }
  }

  // ══════════════════════════════════════════════════════════════════════
  // NUMPAD BUTTONS
  // ══════════════════════════════════════════════════════════════════════

  function bindNumpadButtons(prefix) {
    const grid = document.getElementById(`${prefix}-grid`);
    if (!grid) return;
    grid.querySelectorAll('.np-btn').forEach(btn => {
      const fresh = btn.cloneNode(true);
      btn.parentNode.replaceChild(fresh, btn);
      fresh.addEventListener('click', (e) => {
        triggerRipple(fresh, e);
        handleNumpadClick(fresh.dataset.value, `${prefix}-status`);
      });
      // Touch support
      fresh.addEventListener('touchend', (e) => {
        e.preventDefault();
        const touch = e.changedTouches[0];
        triggerRipple(fresh, touch);
        handleNumpadClick(fresh.dataset.value, `${prefix}-status`);
      }, { passive: false });
    });
  }

  function handleNumpadClick(value, statusId) {
    if (!state.enabled) return;

    const sel = state.inputSelector;
    if (!sel) {
      showStatus(statusId, 'Set an input selector first', 'warn');
      return;
    }

    const pageContainer = document.getElementById(IDs.PAGE_CONTAINER);
    const searchRoot = pageContainer || document;
    const input = searchRoot.querySelector(sel);

    if (!input) {
      showStatus(statusId, `No element: ${sel}`, 'error');
      return;
    }

    // React/Vue-friendly value setter
    const nativeValueSetter = Object.getOwnPropertyDescriptor(
      Object.getPrototypeOf(input), 'value'
    );
    if (nativeValueSetter && nativeValueSetter.set) {
      nativeValueSetter.set.call(input, value);
    } else {
      input.value = value;
    }

    ['input', 'change'].forEach(evtName => {
      input.dispatchEvent(new Event(evtName, { bubbles: true, cancelable: true }));
    });
    input.dispatchEvent(new Event('blur', { bubbles: true }));

    showStatus(statusId, `Inserted ${value}`, 'success');

    const submitSel = state.submitSelector;
    if (submitSel) {
      const submitBtn = searchRoot.querySelector(submitSel);
      if (submitBtn) {
        setTimeout(() => {
          submitBtn.click();
          showStatus(statusId, `Submitted → ${value}`, 'success');
        }, 80);
      } else {
        showStatus(statusId, `Submit not found: ${submitSel}`, 'warn');
      }
    }
  }

  // ══════════════════════════════════════════════════════════════════════
  // SIDEBAR COLLAPSE / SETTINGS TOGGLE
  // ══════════════════════════════════════════════════════════════════════

  function toggleSidebar() {
    if (state.floating) return;
    state.open = !state.open;
    persist();

    const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER);
    const btn = document.getElementById('np-collapse-btn');
    if (wrapper) applySidebarSize(wrapper, state.open ? state.width : 32);
    if (btn) btn.title = state.open ? 'Collapse sidebar' : 'Expand sidebar';
  }

  function toggleSettings(panelId) {
    const panel = document.getElementById(panelId);
    if (!panel) return;
    const isOpen = panel.classList.toggle('np-settings-open');
    state.settingsOpen = isOpen;
    persist();
  }

  // ══════════════════════════════════════════════════════════════════════
  // FLOAT DRAG (drag handle only)
  // ══════════════════════════════════════════════════════════════════════

  function initFloatDrag(panel) {
    const handle = panel.querySelector('#np-float-drag-handle');
    if (!handle) return;

    // Mouse drag
    handle.addEventListener('mousedown', (e) => {
      if (e.target.closest('button')) return;
      e.preventDefault();

      const startMX = e.clientX, startMY = e.clientY;
      const startPX = state.floatX, startPY = state.floatY;
      lockSelect();

      const onMove = (e) => {
        const vw = window.innerWidth, vh = window.innerHeight;
        const w = panel.offsetWidth, h = panel.offsetHeight;
        state.floatX = Math.max(0, Math.min(vw - w, startPX + (e.clientX - startMX)));
        state.floatY = Math.max(0, Math.min(vh - h, startPY + (e.clientY - startMY)));
        panel.style.left = state.floatX + 'px';
        panel.style.top = state.floatY + 'px';
      };

      const onUp = () => {
        unlockSelect();
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
        persist();
      };

      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });

    // Touch drag
    handle.addEventListener('touchstart', (e) => {
      if (e.touches.length !== 1) return;
      e.preventDefault();

      const t0 = e.touches[0];
      const startTX = t0.clientX, startTY = t0.clientY;
      const startPX = state.floatX, startPY = state.floatY;

      const onMove = (e) => {
        const t = e.touches[0];
        const vw = window.innerWidth, vh = window.innerHeight;
        const w = panel.offsetWidth, h = panel.offsetHeight;
        state.floatX = Math.max(0, Math.min(vw - w, startPX + (t.clientX - startTX)));
        state.floatY = Math.max(0, Math.min(vh - h, startPY + (t.clientY - startTY)));
        panel.style.left = state.floatX + 'px';
        panel.style.top = state.floatY + 'px';
      };

      const onEnd = () => {
        handle.removeEventListener('touchmove', onMove);
        handle.removeEventListener('touchend', onEnd);
        persist();
      };

      handle.addEventListener('touchmove', onMove, { passive: false });
      handle.addEventListener('touchend', onEnd);
    }, { passive: false });
  }

  // ══════════════════════════════════════════════════════════════════════
  // FLOAT RESIZE (bottom-left handle only)
  // ══════════════════════════════════════════════════════════════════════

  function initFloatResize(panel) {
    const handle = panel.querySelector('#np-float-resize-bl');
    if (!handle) return;

    // Mouse resize
    handle.addEventListener('mousedown', (e) => {
      e.preventDefault();
      e.stopPropagation();

      const startX = e.clientX, startY = e.clientY;
      const startW = panel.offsetWidth, startH = panel.offsetHeight;
      const startL = state.floatX, startT = state.floatY;
      lockSelect();

      const onMove = (e) => {
        const dx = e.clientX - startX;
        const dy = e.clientY - startY;
        // Bottom-left: width grows leftward, height grows downward
        const newW = Math.max(MIN_FLOAT_W, startW - dx);
        const newH = Math.max(MIN_FLOAT_H, startH + dy);
        const newL = startL + (startW - newW);

        state.floatW = Math.round(newW);
        state.floatH = Math.round(newH);
        state.floatX = Math.round(newL);

        panel.style.width = state.floatW + 'px';
        panel.style.height = state.floatH + 'px';
        panel.style.left = state.floatX + 'px';
      };

      const onUp = () => {
        unlockSelect();
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
        persist();
      };

      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });

    // Touch resize
    handle.addEventListener('touchstart', (e) => {
      if (e.touches.length !== 1) return;
      e.preventDefault();
      e.stopPropagation();

      const t0 = e.touches[0];
      const startX = t0.clientX, startY = t0.clientY;
      const startW = panel.offsetWidth, startH = panel.offsetHeight;
      const startL = state.floatX;

      const onMove = (e) => {
        const t = e.touches[0];
        const dx = t.clientX - startX;
        const dy = t.clientY - startY;
        const newW = Math.max(MIN_FLOAT_W, startW - dx);
        const newH = Math.max(MIN_FLOAT_H, startH + dy);
        const newL = startL + (startW - newW);

        state.floatW = Math.round(newW);
        state.floatH = Math.round(newH);
        state.floatX = Math.round(newL);

        panel.style.width = state.floatW + 'px';
        panel.style.height = state.floatH + 'px';
        panel.style.left = state.floatX + 'px';
      };

      const onEnd = () => {
        handle.removeEventListener('touchmove', onMove);
        handle.removeEventListener('touchend', onEnd);
        persist();
      };

      handle.addEventListener('touchmove', onMove, { passive: false });
      handle.addEventListener('touchend', onEnd);
    }, { passive: false });
  }

  // ══════════════════════════════════════════════════════════════════════
  // SIDEBAR RESIZER (touch + mouse)
  // ══════════════════════════════════════════════════════════════════════

  function initSidebarResizer() {
    // Clone-replace to remove any previously attached listeners before re-binding
    const oldResizer = document.getElementById(IDs.RESIZER);
    if (!oldResizer) return;
    const resizer = oldResizer.cloneNode(true);
    oldResizer.parentNode.replaceChild(resizer, oldResizer);

    function startResize(startX, startY, startWidth) {
      lockSelect();
      const dock = state.sidebarDock || 'right';
      const isHoriz = dock === 'top' || dock === 'bottom';
      document.body.style.cursor = isHoriz ? 'ns-resize' : 'ew-resize';

      const onMove = (clientX, clientY) => {
        let newSize;
        if (isHoriz) {
          const delta = dock === 'top' ? startY - clientY : clientY - startY;
          newSize = Math.min(MAX_WIDTH, Math.max(MIN_WIDTH, startWidth + delta));
        } else {
          const delta = startX - clientX;
          newSize = Math.min(MAX_WIDTH, Math.max(MIN_WIDTH, startWidth + delta));
        }
        state.width = newSize;
        const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER);
        if (wrapper) applySidebarSize(wrapper, newSize);
      };

      const onMouseMove = (e) => onMove(e.clientX, e.clientY);
      const onTouchMove = (e) => onMove(e.touches[0].clientX, e.touches[0].clientY);

      const onEnd = () => {
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onEnd);
        document.removeEventListener('touchmove', onTouchMove);
        document.removeEventListener('touchend', onEnd);
        unlockSelect();
        document.body.style.cursor = '';
        persist();
      };

      document.addEventListener('mousemove', onMouseMove);
      document.addEventListener('mouseup', onEnd);
      document.addEventListener('touchmove', onTouchMove, { passive: false });
      document.addEventListener('touchend', onEnd);
    }

    resizer.addEventListener('mousedown', (e) => {
      const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER);
      const startWidth = wrapper?.offsetWidth || DEFAULT_WIDTH;
      startResize(e.clientX, e.clientY, startWidth);
      e.preventDefault();
    });

    resizer.addEventListener('touchstart', (e) => {
      const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER);
      const startWidth = wrapper?.offsetWidth || DEFAULT_WIDTH;
      startResize(e.touches[0].clientX, e.touches[0].clientY, startWidth);
      e.preventDefault();
    }, { passive: false });
  }

  // ══════════════════════════════════════════════════════════════════════
  // UTILITIES
  // ══════════════════════════════════════════════════════════════════════

  function lockSelect() {
    document.documentElement.style.userSelect = 'none';
    document.documentElement.style.webkitUserSelect = 'none';
  }
  function unlockSelect() {
    document.documentElement.style.userSelect = '';
    document.documentElement.style.webkitUserSelect = '';
  }

  const statusTimers = {};
  function showStatus(statusId, msg, type = 'success') {
    const el = document.getElementById(statusId);
    if (!el) return;
    el.textContent = msg;
    el.className = `np-status np-status-${type} np-status-visible`;
    clearTimeout(statusTimers[statusId]);
    statusTimers[statusId] = setTimeout(() => {
      el.classList.remove('np-status-visible');
    }, 2500);
  }

  function triggerRipple(btn, e) {
    const ripple = btn.querySelector('.np-btn-ripple');
    if (!ripple) return;
    const rect = btn.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = (e.clientX ?? e.pageX ?? rect.left + rect.width / 2) - rect.left - size / 2;
    const y = (e.clientY ?? e.pageY ?? rect.top + rect.height / 2) - rect.top - size / 2;
    ripple.style.cssText = `width:${size}px;height:${size}px;top:${y}px;left:${x}px;`;
    ripple.classList.remove('np-ripple-active');
    void ripple.offsetWidth;
    ripple.classList.add('np-ripple-active');
  }

  // ══════════════════════════════════════════════════════════════════════
  // SPA WATCHER
  // ══════════════════════════════════════════════════════════════════════

  function watchForLayoutChanges() {
    const observer = new MutationObserver(() => {
      if (!document.getElementById(IDs.LAYOUT_ROOT)) {
        setTimeout(() => inject(), 0);
      }
    });
    observer.observe(document.body, { childList: true, subtree: false });
  }

  // ══════════════════════════════════════════════════════════════════════
  // POPUP TOGGLE MESSAGE
  // ══════════════════════════════════════════════════════════════════════

  if (chrome.runtime?.onMessage) {
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      if (msg?.action === 'toggle') toggleSidebar();
      if (msg?.action === 'setEnabled') {
        if (msg.enabled !== state.enabled) {
          toggleEnabled();
        }
      }
    });
  }

  // ══════════════════════════════════════════════════════════════════════
  // BOOT
  // ══════════════════════════════════════════════════════════════════════

  function init() {
    if (document.body) {
      inject();
      watchForLayoutChanges();
    } else {
      document.addEventListener('DOMContentLoaded', () => {
        inject();
        watchForLayoutChanges();
      });
    }
  }

  loadState(init);

})();

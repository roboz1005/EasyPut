const STORAGE_KEY = 'numpadSidebarStateV2';

const btn = document.getElementById('power-btn');
const label = document.getElementById('power-label');
const dot = btn.querySelector('.popup-dot');
const status = document.getElementById('popup-status');

function setUI(enabled) {
  if (enabled) {
    btn.className = 'popup-toggle on';
    label.textContent = 'ON';
  } else {
    btn.className = 'popup-toggle off';
    label.textContent = 'OFF';
  }
}

// Read current state from storage and reflect it
chrome.storage.local.get(STORAGE_KEY, (result) => {
  const saved = result[STORAGE_KEY];
  const enabled = saved ? (saved.enabled !== false) : true;
  setUI(enabled);
});

btn.addEventListener('click', async () => {
  // Toggle state in storage
  const result = await chrome.storage.local.get(STORAGE_KEY);
  const saved = result[STORAGE_KEY] || {};
  const newEnabled = !(saved.enabled !== false);
  saved.enabled = newEnabled;
  await chrome.storage.local.set({ [STORAGE_KEY]: saved });

  setUI(newEnabled);
  status.textContent = newEnabled ? 'Extension enabled' : 'Extension disabled';

  // Notify the active tab's content script
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab && tab.id) {
    chrome.tabs.sendMessage(tab.id, { action: 'setEnabled', enabled: newEnabled });
  }

  // Close popup after brief feedback
  setTimeout(() => window.close(), 600);
});

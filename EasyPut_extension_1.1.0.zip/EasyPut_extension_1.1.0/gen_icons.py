from PIL import Image, ImageDraw, ImageFont
import os

os.makedirs('icons', exist_ok=True)

for size in [16, 48, 128]:
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Background rounded rect
    r = size // 6
    draw.rounded_rectangle([0, 0, size-1, size-1], radius=r, fill=(26, 27, 30, 255))
    
    # Inner grid dots (numpad feel)
    pad = size // 5
    cell = (size - 2*pad) // 3
    dot = max(1, size // 18)
    accent = (77, 171, 247, 255)
    
    for row in range(3):
        for col in range(3):
            cx = pad + col * cell + cell // 2
            cy = pad + row * cell + cell // 2
            draw.ellipse([cx-dot, cy-dot, cx+dot, cy+dot], fill=accent)
    
    img.save(f'icons/icon{size}.png')
    print(f'Generated icon{size}.png')

print('Icons done.')

/**
 * EasyPut — content.js v1.3
 * Adds: Paste system (presets, text buttons, automation flow, float panel, shortcuts)
 * v1.3 changes:
 *   - Direct TUI ImageEditor addText API integration (no clipboard paste needed)
 *   - Auto-populate Udvash selector presets on first load
 *   - Smart numpad submit: auto-detect #updateNextBtn / #skipNextBtn
 *   - Text buttons now place configured text directly via editor event hook
 *
 * New fields in state:
 *   penSelector, textSelector
 *   pasteEnabled, pastePresets, pasteActivePresetId
 *   floatingNum (renamed from floating), floatingText
 *   floatNumX/Y/W/H, floatTextX/Y/W/H
 */

(function () {
  'use strict';

  if (window.__numpadSidebarInjected) return;
  window.__numpadSidebarInjected = true;

  // ══════════════════════════════════════════════════════════════════════
  // CONSTANTS
  // ══════════════════════════════════════════════════════════════════════
  const IDs = {
    LAYOUT_ROOT: '__numpad_layout_root',
    PAGE_CONTAINER: '__numpad_page_container',
    SIDEBAR_WRAPPER: '__numpad_sidebar_wrapper',
    SIDEBAR_CONTENT: '__numpad_sidebar_content',
    RESIZER: '__numpad_sidebar_resizer',
    LAYOUT_STYLES: '__numpad_layout_styles',
    FLOAT_NUM_PANEL: '__numpad_float_panel',
    FLOAT_TEXT_PANEL: '__numpad_float_text_panel',
    FLOAT_STYLES: '__numpad_float_styles',
  };

  const STORAGE_KEY = 'numpadSidebarStateV2';
  const DEFAULT_WIDTH = 300;
  const MIN_WIDTH = 220;
  const MAX_WIDTH = 580;
  const MIN_FLOAT_W = 200;
  const MIN_FLOAT_H = 200;
  const SETTINGS_PANEL_IDS = ['np-settings-panel', 'np-float-num-settings-panel', 'np-float-text-settings-panel'];

  const DEFAULT_BUTTONS = ['7', '8', '9', '4', '5', '6', '1', '2', '3', '0', '10', 'NONE'];
  const DEFAULT_COLS = 3;
  const DEFAULT_ROWS = 4;

  // ══════════════════════════════════════════════════════════════════════
  // STATE
  // ══════════════════════════════════════════════════════════════════════
  let state = {
    enabled: true,
    open: true,
    width: DEFAULT_WIDTH,
    inputSelector: '',
    submitSelector: '',
    penSelector: '',
    textSelector: '',
    settingsOpen: false,
    activeTab: 'selector',
    // floating num
    floatingNum: false,
    floatNumX: 80,
    floatNumY: 80,
    floatNumW: 0,
    floatNumH: 0,
    // floating text
    floatingText: false,
    floatTextX: 320,
    floatTextY: 80,
    floatTextW: 0,
    floatTextH: 0,
    // customizable numpad
    buttonValues: [...DEFAULT_BUTTONS],
    gridCols: DEFAULT_COLS,
    gridRows: DEFAULT_ROWS,
    // selector presets
    inputPresets: [],
    submitPresets: [],
    penPresets: [],
    textPresets: [],
    inputPresetId: '',
    submitPresetId: '',
    penPresetId: '',
    textPresetId: '',
    // sidebar docking
    sidebarDock: 'right',
    // paste system
    pasteEnabled: true,
    shortcutsEnabled: true,
    pastePresets: [],       // [{id, label, entries:[{id,label,text,shortcut}]}]
    pasteActivePresetId: '',
  };

  // Track last known mouse/touch position for paste automation
  let lastMouseX = window.innerWidth / 2;
  let lastMouseY = window.innerHeight / 2;

  // ══════════════════════════════════════════════════════════════════════
  // STORAGE MODULE
  // ══════════════════════════════════════════════════════════════════════
  function persist() {
    chrome.storage.local.set({ [STORAGE_KEY]: state });
  }

  function loadState(cb) {
    chrome.storage.local.get(STORAGE_KEY, (result) => {
      if (result[STORAGE_KEY]) {
        const saved = result[STORAGE_KEY];
        if (!saved.buttonValues) saved.buttonValues = [...DEFAULT_BUTTONS];
        if (!saved.gridCols) saved.gridCols = DEFAULT_COLS;
        if (!saved.gridRows) saved.gridRows = DEFAULT_ROWS;
        if (saved.enabled === undefined) saved.enabled = true;
        // migrate old selectorPresets
        if (saved.selectorPresets && !saved.inputPresets) {
          saved.inputPresets = [...saved.selectorPresets];
          saved.submitPresets = [...saved.selectorPresets];
          delete saved.selectorPresets;
        }
        if (!saved.inputPresets) saved.inputPresets = [];
        if (!saved.submitPresets) saved.submitPresets = [];
        if (!saved.penPresets) saved.penPresets = [];
        if (!saved.textPresets) saved.textPresets = [];
        if (!saved.inputPresetId) saved.inputPresetId = '';
        if (!saved.submitPresetId) saved.submitPresetId = '';
        if (!saved.penPresetId) saved.penPresetId = '';
        if (!saved.textPresetId) saved.textPresetId = '';
        if (!saved.sidebarDock) saved.sidebarDock = 'right';
        // Migrate old floating → floatingNum
        if (saved.floating !== undefined && saved.floatingNum === undefined) {
          saved.floatingNum = saved.floating;
          saved.floatNumX = saved.floatX || 80;
          saved.floatNumY = saved.floatY || 80;
          saved.floatNumW = saved.floatW || 0;
          saved.floatNumH = saved.floatH || 0;
          delete saved.floating; delete saved.floatX; delete saved.floatY;
          delete saved.floatW; delete saved.floatH;
        }
        if (saved.floatingNum === undefined) saved.floatingNum = false;
        if (!saved.floatNumX) saved.floatNumX = 80;
        if (!saved.floatNumY) saved.floatNumY = 80;
        if (!saved.floatNumW) saved.floatNumW = 0;
        if (!saved.floatNumH) saved.floatNumH = 0;
        if (saved.floatingText === undefined) saved.floatingText = false;
        if (!saved.floatTextX) saved.floatTextX = 320;
        if (!saved.floatTextY) saved.floatTextY = 80;
        if (!saved.floatTextW) saved.floatTextW = 0;
        if (!saved.floatTextH) saved.floatTextH = 0;
        // paste system
        if (saved.pasteEnabled === undefined) saved.pasteEnabled = true;
        if (saved.shortcutsEnabled === undefined) saved.shortcutsEnabled = true;
        if (!saved.pastePresets) saved.pastePresets = [];
        if (!saved.pasteActivePresetId) saved.pasteActivePresetId = '';
        // selectors
        if (!saved.penSelector) saved.penSelector = '';
        if (!saved.textSelector) saved.textSelector = '';
        Object.assign(state, saved);
      }
      cb();
    });
  }

  // ══════════════════════════════════════════════════════════════════════
  // SELECTOR CAPTURE MODULE (unchanged)
  // ══════════════════════════════════════════════════════════════════════
  function escapeCssAttributeValue(value) {
    return String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
  }
  function isUniqueSelector(selector) {
    if (!selector) return false;
    try { return document.querySelectorAll(selector).length === 1; } catch { return false; }
  }
  function buildAttributeSelector(el, attrName) {
    const rawValue = el.getAttribute(attrName);
    if (!rawValue) return '';
    const selector = `${el.tagName.toLowerCase()}[${attrName}="${escapeCssAttributeValue(rawValue)}"]`;
    return isUniqueSelector(selector) ? selector : '';
  }
  function buildCssPathSelector(el) {
    const parts = [];
    let current = el;
    while (current && current.nodeType === Node.ELEMENT_NODE) {
      if (current === document.documentElement) { parts.unshift('html'); break; }
      if (current === document.body) { parts.unshift('body'); break; }
      if (current.id) { parts.unshift(`#${CSS.escape(current.id)}`); break; }
      let segment = current.tagName.toLowerCase();
      const safeClasses = Array.from(current.classList || [])
        .filter(c => !/^(active|hover|focus|disabled|ng-|v-|js-)/.test(c))
        .slice(0, 3).map(c => `.${CSS.escape(c)}`).join('');
      if (safeClasses) segment += safeClasses;
      const siblings = current.parentElement
        ? Array.from(current.parentElement.children).filter(ch => ch.tagName === current.tagName) : [];
      if (siblings.length > 1) segment += `:nth-of-type(${siblings.indexOf(current) + 1})`;
      parts.unshift(segment);
      current = current.parentElement;
    }
    const selector = parts.join(' > ');
    return selector && isUniqueSelector(selector) ? selector : '';
  }
  function xpathLiteral(value) {
    const text = String(value);
    if (!text.includes("'")) return `'${text}'`;
    if (!text.includes('"')) return `"${text}"`;
    const pieces = text.split("'");
    const parts = [];
    pieces.forEach((piece, index) => { if (index > 0) parts.push(`"'"`); parts.push(`'${piece}'`); });
    return `concat(${parts.join(', ')})`;
  }
  function buildXPathSelector(el) {
    const segments = [];
    let current = el;
    while (current && current.nodeType === Node.ELEMENT_NODE) {
      const tag = current.tagName.toLowerCase();
      if (current === document.documentElement) { segments.unshift('html'); break; }
      if (current === document.body) { segments.unshift('body'); break; }
      if (current.id) { segments.unshift(`*[@id=${xpathLiteral(current.id)}]`); break; }
      const siblings = current.parentElement
        ? Array.from(current.parentElement.children).filter(ch => ch.tagName === current.tagName) : [];
      segments.unshift(`${tag}[${siblings.indexOf(current) + 1}]`);
      current = current.parentElement;
    }
    return `//${segments.join('/')}`;
  }
  function generateSelector(el) {
    if (!el || el.nodeType !== Node.ELEMENT_NODE || el === document.body) return '';
    if (el.id) return `${el.tagName.toLowerCase()}#${CSS.escape(el.id)}`;
    const nameSelector = buildAttributeSelector(el, 'name');
    if (nameSelector) return nameSelector;
    for (const attr of Array.from(el.attributes || [])) {
      if (attr.name.startsWith('data-') && attr.value) {
        const s = buildAttributeSelector(el, attr.name); if (s) return s;
      }
    }
    for (const attr of Array.from(el.attributes || [])) {
      if (attr.name.startsWith('aria-') && attr.value) {
        const s = buildAttributeSelector(el, attr.name); if (s) return s;
      }
    }
    const cssSelector = buildCssPathSelector(el);
    if (cssSelector) return cssSelector;
    return buildXPathSelector(el);
  }

  // ══════════════════════════════════════════════════════════════════════
  // MOUSE TRACKING (for paste position)
  // ══════════════════════════════════════════════════════════════════════
  document.addEventListener('mousemove', (e) => {
    lastMouseX = e.clientX;
    lastMouseY = e.clientY;
  }, { passive: true, capture: true });
  document.addEventListener('touchstart', (e) => {
    if (e.touches.length > 0) {
      lastMouseX = e.touches[0].clientX;
      lastMouseY = e.touches[0].clientY;
    }
  }, { passive: true, capture: true });

  // ══════════════════════════════════════════════════════════════════════
  // STYLES
  // ══════════════════════════════════════════════════════════════════════
  function applyLayoutStyles() {
    let el = document.getElementById(IDs.LAYOUT_STYLES);
    if (!el) {
      el = document.createElement('style');
      el.id = IDs.LAYOUT_STYLES;
      document.head.appendChild(el);
    }
    const dock = state.sidebarDock || 'right';
    const isHoriz = dock === 'top' || dock === 'bottom';
    const flexDirMap = { right: 'row', left: 'row-reverse', bottom: 'column', top: 'column-reverse' };
    const flexDir = flexDirMap[dock];
    const borderSide = { left: 'border-right', right: 'border-left', top: 'border-bottom', bottom: 'border-top' }[dock];
    const shadowMap = { left: '6px 0 28px', right: '-6px 0 28px', top: '0 6px 28px', bottom: '0 -6px 28px' };
    const shadowDir = shadowMap[dock];
    const resizerCSS = isHoriz ? `
      width: 100% !important; height: 6px !important; cursor: ns-resize !important;
      left: 0 !important; right: 0 !important;
      ${dock === 'top' ? 'bottom: 0 !important; top: auto !important;' : 'top: 0 !important; bottom: auto !important;'}
    ` : `
      height: 100% !important; width: 6px !important; cursor: ew-resize !important;
      top: 0 !important; bottom: 0 !important;
      ${dock === 'right' ? 'left: 0 !important; right: auto !important;' : 'right: 0 !important; left: auto !important;'}
    `;
    const sidebarStructural = isHoriz ? 'width: 100% !important;' : 'height: 100% !important;';

    el.textContent = `
      html { width: 100% !important; height: 100% !important; margin: 0 !important; padding: 0 !important; overflow: hidden !important; }
      body { margin: 0 !important; padding: 0 !important; width: 100% !important; height: 100% !important; overflow: hidden !important; }
      #${IDs.LAYOUT_ROOT} {
        display: flex !important; flex-direction: ${flexDir} !important;
        width: 100vw !important; height: 100vh !important;
        position: fixed !important; top: 0 !important; left: 0 !important;
        right: 0 !important; bottom: 0 !important;
        z-index: 2147483646 !important; box-sizing: border-box !important;
      }
      #${IDs.PAGE_CONTAINER} {
        flex: 1 !important; min-width: 0 !important; min-height: 0 !important;
        overflow: auto !important; display: flex !important;
        flex-direction: column !important; position: relative !important; background: inherit !important;
      }
      #${IDs.PAGE_CONTAINER} > * { flex-shrink: 0 !important; }
      #${IDs.SIDEBAR_WRAPPER} {
        flex-shrink: 0 !important; display: flex !important; flex-direction: column !important;
        position: relative !important; background: var(--np-bg, #1a1b1e) !important;
        ${borderSide}: 1.5px solid var(--np-border, #373a40) !important;
        box-shadow: ${shadowDir} rgba(0,0,0,0.55) !important;
        overflow: hidden !important; z-index: 2147483647 !important;
        transition: width 0.28s cubic-bezier(0.4,0,0.2,1), height 0.28s cubic-bezier(0.4,0,0.2,1) !important;
        box-sizing: border-box !important; ${sidebarStructural}
      }
      #${IDs.SIDEBAR_CONTENT} {
        display: flex !important; flex-direction: column !important;
        width: 100% !important; height: 100% !important;
        overflow-y: auto !important; overflow-x: hidden !important;
      }
      #${IDs.RESIZER} {
        position: absolute !important; ${resizerCSS}
        background: transparent !important; transition: background 0.15s !important;
        touch-action: none !important; z-index: 1000 !important;
      }
    `;
  }

  // ══════════════════════════════════════════════════════════════════════
  // HTML BUILDERS — UTILITIES
  // ══════════════════════════════════════════════════════════════════════
  function escAttr(s) {
    return (s || '').replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  function escHtml(s) {
    return (s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  // ══════════════════════════════════════════════════════════════════════
  // HTML BUILDERS — NUMPAD GRID
  // ══════════════════════════════════════════════════════════════════════
  function buildNumpadGridHTML(prefix) {
    const vals = state.buttonValues;
    const visibleVals = vals.filter(v => v && v !== 'NONE');
    const btnHTML = visibleVals.map(v => `
      <button class="np-btn" data-value="${escAttr(v)}" aria-label="Insert ${escAttr(v)}"
        style="user-select:none;-webkit-user-select:none;cursor:pointer;">
        <span class="np-btn-label" style="user-select:none;-webkit-user-select:none;pointer-events:none;">${escAttr(v)}</span>
        <span class="np-btn-ripple"></span>
      </button>
    `).join('');
    return `
      <div class="np-grid" id="${prefix}-grid" style="--np-cols:${state.gridCols};">${btnHTML}</div>
      <div class="np-status" id="${prefix}-status"></div>
    `;
  }

  // ══════════════════════════════════════════════════════════════════════
  // HTML BUILDERS — TEXT BUTTONS
  // ══════════════════════════════════════════════════════════════════════
  function getActivePreset() {
    if (!state.pasteActivePresetId) return null;
    return state.pastePresets.find(p => p.id === state.pasteActivePresetId) || null;
  }

  function buildTextButtonsHTML(prefix) {
    if (!state.pasteEnabled) return '';
    const preset = getActivePreset();
    const showHeader = prefix !== 'np-float-text';
    if (!preset || !preset.entries || preset.entries.length === 0) {
      return `<div class="np-text-btns-section" id="${prefix}-text-btns">
        ${showHeader ? `
        <div class="np-text-btns-header">
          <span class="np-text-btns-label">Text Buttons</span>
          <span class="np-text-btns-preset-name">${preset ? escHtml(preset.label) : 'No preset selected'}</span>
        </div>
        ` : ''}
        <div class="np-text-empty">No text entries. Configure in Paste tab.</div>
      </div>`;
    }
    const btns = preset.entries.map(entry => `
      <button class="np-btn np-text-btn" data-paste-entry-id="${escAttr(entry.id)}"
        title="${entry.shortcut ? 'Shortcut: ' + escAttr(entry.shortcut) + ' — ' : ''}${escAttr(entry.text.substring(0, 60))}${entry.text.length > 60 ? '…' : ''}"
        style="user-select:none;-webkit-user-select:none;cursor:pointer;">
        <span class="np-btn-label" style="user-select:none;-webkit-user-select:none;pointer-events:none;">${escAttr(entry.label || 'Text')}</span>
        <span class="np-btn-ripple"></span>
      </button>
    `).join('');
    return `
      <div class="np-text-btns-section" id="${prefix}-text-btns">
        ${showHeader ? `
        <div class="np-text-btns-header">
          <span class="np-text-btns-label">📝 Text</span>
          <span class="np-text-btns-preset-name">${escHtml(preset.label)}</span>
        </div>
        ` : ''}
        <div class="np-grid np-text-grid" id="${prefix}-text-grid" style="--np-cols:${Math.min(state.gridCols, preset.entries.length, 4)};">${btns}</div>
        <div class="np-status" id="${prefix}-text-status"></div>
      </div>
    `;
  }

  // ══════════════════════════════════════════════════════════════════════
  // HTML BUILDERS — SELECTOR DROPDOWN (extended for pen/text)
  // ══════════════════════════════════════════════════════════════════════
  const SELECTOR_CONFIGS = {
    input: { stateKey: 'inputSelector', presetsKey: 'inputPresets', presetIdKey: 'inputPresetId', label: '⌨️ Input Field' },
    submit: { stateKey: 'submitSelector', presetsKey: 'submitPresets', presetIdKey: 'submitPresetId', label: '🖱️ Submit Button' },
    pen: { stateKey: 'penSelector', presetsKey: 'penPresets', presetIdKey: 'penPresetId', label: '🖊️ Pen Button' },
    text: { stateKey: 'textSelector', presetsKey: 'textPresets', presetIdKey: 'textPresetId', label: '📄 Text Button' },
  };

  function buildSelectorDropdownHTML(prefix, type) {
    const cfg = SELECTOR_CONFIGS[type];
    const presetId = state[cfg.presetIdKey];
    const presets = state[cfg.presetsKey];
    const editingPreset = presets.find(p => p.id === presetId);
    const options = [
      `<option value="" ${!presetId ? 'selected' : ''}>None</option>`,
      ...presets.map(p => `<option value="${escAttr(p.id)}" ${p.id === presetId ? 'selected' : ''}>${escAttr(p.label)}</option>`),
      `<option value="__add_new__">+ Add New</option>`,
    ].join('');
    return `
      <div class="np-sel-group" id="${prefix}-${type}-sel-group">
        <p class="np-settings-label">${cfg.label}</p>
        <div class="np-selector-row">
          <select class="np-sel-dropdown" id="${prefix}-${type}-dropdown" data-sel-type="${type}">${options}</select>
        </div>
        ${editingPreset ? `
          <div class="np-preset-edit-row" id="${prefix}-${type}-edit-row">
            <input class="np-settings-input np-preset-label-input" id="${prefix}-${type}-label-inp"
              type="text" placeholder="Name…" value="${escAttr(editingPreset.label)}" maxlength="32">
            <div class="np-selector-input-row">
              <input class="np-settings-input np-preset-value-input" id="${prefix}-${type}-value-inp"
                type="text" placeholder="CSS selector…" value="${escAttr(editingPreset.value)}" maxlength="256">
              <button class="np-icon-btn np-pick-element-btn" data-action="pick-element" data-preset-type="${type}"
                id="${prefix}-${type}-pick-btn" title="Click to activate element picker">
                <svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14">
                  <path fill-rule="evenodd" d="M6.672 1.911a1 1 0 10-1.932.518l.259.966a1 1 0 001.932-.518l-.26-.966zM2.429 4.74a1 1 0 10-.518 1.932l.966.259a1 1 0 00.518-1.932l-.966-.26zm8.814-.569a1 1 0 00-1.415-1.414l-.707.707a1 1 0 101.415 1.415l.707-.708zm-7.071 7.072l.707-.707A1 1 0 003.465 9.12l-.707.707a1 1 0 101.415 1.415zm3.2-5.171a1 1 0 00-1.3 1.3l4 10a1 1 0 001.823.075l1.38-2.759 3.018 3.02a1 1 0 001.414-1.415l-3.019-3.02 2.76-1.379a1 1 0 00-.076-1.822l-10-4z" clip-rule="evenodd"/>
                </svg>
              </button>
            </div>
            <div class="np-preset-actions">
              <button class="np-save-btn np-preset-save-btn" data-action="save-preset" data-preset-type="${type}">Save</button>
              <button class="np-icon-btn np-preset-del-btn" data-action="delete-preset" data-preset-type="${type}"
                title="Delete preset" style="color:var(--np-error)">
                <svg viewBox="0 0 20 20" fill="currentColor" width="13" height="13">
                  <path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clip-rule="evenodd"/>
                </svg>
              </button>
            </div>
          </div>
        ` : `<div class="np-selector-preview" id="${prefix}-${type}-preview">${presetId ? 'Preset not found' : 'None selected'}</div>`}
      </div>
    `;
  }

  function syncActiveSettingsTab(tabName) {
    SETTINGS_PANEL_IDS.forEach((panelId) => {
      const panel = document.getElementById(panelId);
      if (!panel) return;
      panel.querySelectorAll('.np-tab').forEach((tab) => {
        tab.classList.toggle('np-tab-active', tab.dataset.tab === tabName);
      });
      panel.querySelectorAll('.np-tab-content').forEach((content) => {
        content.classList.toggle('np-tab-visible', content.dataset.tabContent === tabName);
      });
    });
  }

  // ══════════════════════════════════════════════════════════════════════
  // HTML BUILDERS — PASTE SETTINGS TAB
  // ══════════════════════════════════════════════════════════════════════
  function buildPasteTabHTML(prefix) {
    const preset = getActivePreset();
    const presetOptions = [
      `<option value="" ${!state.pasteActivePresetId ? 'selected' : ''}>— Select preset —</option>`,
      ...state.pastePresets.map(p =>
        `<option value="${escAttr(p.id)}" ${p.id === state.pasteActivePresetId ? 'selected' : ''}>${escAttr(p.label)}</option>`
      ),
    ].join('');

    const entriesHTML = preset && preset.entries.length > 0 ? preset.entries.map((entry, idx) => `
      <div class="np-paste-entry" data-entry-id="${escAttr(entry.id)}">
        <div class="np-paste-entry-header">
          <span class="np-paste-entry-num">#${idx + 1}</span>
          <input class="np-settings-input np-paste-label-inp" type="text"
            placeholder="Button label" value="${escAttr(entry.label)}" maxlength="20"
            data-entry-field="label" data-entry-id="${escAttr(entry.id)}">
          <div class="np-paste-entry-btns">
            ${idx > 0 ? `<button class="np-icon-btn" data-action="move-entry-up" data-entry-id="${escAttr(entry.id)}" title="Move up">↑</button>` : ''}
            ${idx < preset.entries.length - 1 ? `<button class="np-icon-btn" data-action="move-entry-down" data-entry-id="${escAttr(entry.id)}" title="Move down">↓</button>` : ''}
            <button class="np-icon-btn" data-action="delete-entry" data-entry-id="${escAttr(entry.id)}" title="Delete" style="color:var(--np-error)">✕</button>
          </div>
        </div>
        <textarea class="np-paste-text-inp" rows="3"
          placeholder="Full paste text…"
          data-entry-field="text" data-entry-id="${escAttr(entry.id)}">${escHtml(entry.text)}</textarea>
        <div class="np-paste-shortcut-row">
          <span class="np-settings-label" style="margin:0;font-size:10px;">Shortcut:</span>
          <input class="np-settings-input np-paste-shortcut-inp" type="text" readonly inputmode="none" spellcheck="false" autocomplete="off"
            placeholder="Press keys" value="${escAttr(entry.shortcut || '')}" maxlength="20"
            data-entry-field="shortcut" data-entry-id="${escAttr(entry.id)}">
            <button class="np-save-btn" data-action="save-entry" data-entry-id="${escAttr(entry.id)}" style="padding:3px 8px;">Save</button>
        </div>
      </div>
    `).join('') : (preset ? `<div class="np-text-empty">No entries yet. Click "+ Add Text Entry" below.</div>` : '');

    return `
      <!-- Master toggle -->
      <div class="np-paste-toggle-row">
        <span class="np-settings-label" style="margin:0;">Paste System</span>
        <div class="np-paste-toggle-actions">
          <button class="np-paste-master-toggle ${state.pasteEnabled ? 'np-on' : 'np-off'}"
            id="${prefix}-paste-toggle" data-action="toggle-paste">
            <span class="np-power-dot"></span>
            <span>${state.pasteEnabled ? 'ON' : 'OFF'}</span>
          </button>
          <button class="np-shortcut-toggle ${state.shortcutsEnabled ? 'np-on' : 'np-off'}"
            id="${prefix}-shortcuts-toggle" data-action="toggle-shortcuts"
            title="Toggle shortcuts" aria-label="Toggle shortcuts">
            S
          </button>
        </div>
      </div>
      ${!state.pasteEnabled ? `<div class="np-settings-hint">Paste system is OFF. Text buttons and shortcuts are disabled.</div>` : `
        ${!state.shortcutsEnabled ? `<div class="np-settings-hint">Shortcuts are OFF. Text buttons still work.</div>` : ''}
        <!-- Preset manager -->
        <div class="np-paste-preset-section">
          <p class="np-settings-label">Preset</p>
          <div class="np-paste-preset-row">
            <select class="np-sel-dropdown" id="${prefix}-paste-preset-dropdown">${presetOptions}</select>
            <button class="np-icon-btn" data-action="add-paste-preset" title="Add new preset" style="color:var(--np-accent);">＋</button>
          </div>
          ${preset ? `
            <div class="np-paste-preset-rename-row">
              <input class="np-settings-input" id="${prefix}-paste-preset-name" type="text"
                value="${escAttr(preset.label)}" maxlength="40" placeholder="Preset name">
              <button class="np-save-btn" data-action="rename-paste-preset" style="padding:3px 8px;">Rename</button>
              <button class="np-icon-btn" data-action="delete-paste-preset" title="Delete preset" style="color:var(--np-error);">🗑</button>
            </div>
          ` : ''}
        </div>

        <!-- Entries -->
        ${preset ? `
          <div class="np-paste-entries" id="${prefix}-paste-entries">${entriesHTML}</div>
          <button class="np-save-btn" data-action="add-paste-entry" style="margin-top:6px;width:100%;">+ Add Text Entry</button>
        ` : `<div class="np-settings-hint">Select or create a preset to add text entries.</div>`}
        <div class="np-settings-hint" style="margin-top:6px;">Click flow: Add Page → Text → Paste at position → Pen</div>
      `}
    `;
  }

  function getPageSearchRoot() {
    return document.getElementById(IDs.PAGE_CONTAINER) || document;
  }

  // ══════════════════════════════════════════════════════════════════════
  // HTML BUILDERS — SETTINGS TABS
  // ══════════════════════════════════════════════════════════════════════
  function buildSettingsHTML(prefix) {
    const active = state.activeTab;
    return `
      <div class="np-tabs">
        <button class="np-tab ${active === 'selector' ? 'np-tab-active' : ''}" data-tab="selector">Selectors</button>
        <button class="np-tab ${active === 'buttons' ? 'np-tab-active' : ''}" data-tab="buttons">Buttons</button>
        <button class="np-tab ${active === 'layout' ? 'np-tab-active' : ''}" data-tab="layout">Layout</button>
        <button class="np-tab ${active === 'dock' ? 'np-tab-active' : ''}" data-tab="dock">Dock</button>
        <button class="np-tab ${active === 'paste' ? 'np-tab-active' : ''}" data-tab="paste">Paste</button>
      </div>

      <!-- Selectors -->
      <div class="np-tab-content ${active === 'selector' ? 'np-tab-visible' : ''}" data-tab-content="selector">
        ${buildSelectorDropdownHTML(prefix, 'input')}
        ${buildSelectorDropdownHTML(prefix, 'submit')}
        ${buildSelectorDropdownHTML(prefix, 'pen')}
        ${buildSelectorDropdownHTML(prefix, 'text')}
        <div class="np-settings-hint">Select a saved preset or add a new one to set the CSS selector.</div>
      </div>

      <!-- Buttons -->
      <div class="np-tab-content ${active === 'buttons' ? 'np-tab-visible' : ''}" data-tab-content="buttons">
        <div class="np-settings-hint" style="margin-bottom:4px;">Each slot is a button value. Leave blank or type NONE to hide.</div>
        <div class="np-btn-editor-grid" id="${prefix}-btn-editor">
          ${state.buttonValues.map((v, i) => `
            <div class="np-btn-slot">
              <span class="np-btn-slot-label">#${i + 1}</span>
              <input class="np-btn-slot-input" type="text" data-slot="${i}"
                value="${v === 'NONE' ? '' : escAttr(v)}" placeholder="NONE" maxlength="8">
            </div>
          `).join('')}
        </div>
        <button class="np-save-btn" data-action="save-buttons" style="margin-top:8px;">Apply Buttons</button>
        <div class="np-settings-hint">Examples: 0, 2, 3.5, A+, ABS. Empty = hidden button.</div>
      </div>

      <!-- Layout -->
      <div class="np-tab-content ${active === 'layout' ? 'np-tab-visible' : ''}" data-tab-content="layout">
        <div class="np-settings-hint" style="margin-bottom:4px;">Set the grid columns and rows for your numpad.</div>
        <div class="np-grid-controls">
          <div class="np-grid-ctrl-group">
            <p class="np-settings-label">Columns</p>
            <input class="np-number-input" id="${prefix}-grid-cols" type="number" min="1" max="6" value="${state.gridCols}">
          </div>
          <div class="np-grid-ctrl-group">
            <p class="np-settings-label">Rows (slots)</p>
            <input class="np-number-input" id="${prefix}-grid-rows" type="number" min="1" max="10" value="${state.gridRows}">
          </div>
        </div>
        <button class="np-save-btn" data-action="save-layout" style="margin-top:8px;">Apply Layout</button>
        <div class="np-settings-hint">Increasing rows adds more button slots in the Buttons tab.</div>
      </div>

      <!-- Dock -->
      <div class="np-tab-content ${active === 'dock' ? 'np-tab-visible' : ''}" data-tab-content="dock">
        <div class="np-settings-hint" style="margin-bottom:6px;">Choose which side to dock the sidebar.</div>
        <div class="np-dock-grid">
          ${['left', 'right', 'top', 'bottom'].map(side => `
            <button class="np-dock-btn ${state.sidebarDock === side ? 'np-dock-active' : ''}"
              data-action="set-dock" data-dock="${side}">
              ${side.charAt(0).toUpperCase() + side.slice(1)}
            </button>
          `).join('')}
        </div>
      </div>

      <!-- Paste -->
      <div class="np-tab-content ${active === 'paste' ? 'np-tab-visible' : ''}" data-tab-content="paste">
        ${buildPasteTabHTML(prefix)}
      </div>
    `;
  }

  // ══════════════════════════════════════════════════════════════════════
  // HTML BUILDERS — SIDEBAR
  // ══════════════════════════════════════════════════════════════════════
  function buildSidebarHTML() {
    const numpadHidden = state.floatingNum ? 'style="display:none"' : '';
    const placeholderShown = state.floatingNum ? 'style="display:flex"' : 'style="display:none"';
    return `
      <div class="np-header">
        <div class="np-header-left">
          <button class="np-icon-btn np-collapse-btn" id="np-collapse-btn"
            title="${state.open ? 'Collapse sidebar' : 'Expand sidebar'}" style="user-select:none;">
            <svg class="np-chevron" viewBox="0 0 20 20" fill="currentColor" width="15" height="15">
              <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"/>
            </svg>
          </button>
        </div>
        <div class="np-header-actions">
          <button class="np-power-toggle ${state.enabled ? 'np-on' : 'np-off'}"
            id="np-power-toggle" title="${state.enabled ? 'Disable extension' : 'Enable extension'}" style="user-select:none;">
            <span class="np-power-dot"></span>
            <span>${state.enabled ? 'ON' : 'OFF'}</span>
          </button>
          <button class="np-icon-btn" id="np-float-num-toggle-btn" title="Float Numpad" style="user-select:none;">
            <svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14">
              <path d="M3 5a2 2 0 012-2h4a1 1 0 010 2H5v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H5a2 2 0 01-2-2V5z"/>
              <path d="M15 3h2a1 1 0 011 1v2a1 1 0 11-2 0V5.414l-5.293 5.293a1 1 0 01-1.414-1.414L14.586 4H14a1 1 0 110-2z"/>
            </svg>
          </button>
          ${state.pasteEnabled ? `
          <button class="np-icon-btn" id="np-float-text-toggle-btn" title="Float Text Buttons" style="user-select:none;color:var(--np-accent-paste,#69db7c);">
            <svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14">
              <path fill-rule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clip-rule="evenodd"/>
            </svg>
          </button>
          ` : ''}
          <button class="np-icon-btn np-settings-btn" id="np-settings-toggle" title="Settings" style="user-select:none;">
            <svg viewBox="0 0 20 20" fill="currentColor" width="15" height="15">
              <path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"/>
            </svg>
          </button>
        </div>
      </div>

      <div class="np-settings-panel ${state.settingsOpen ? 'np-settings-open' : ''}" id="np-settings-panel">
        ${buildSettingsHTML('np-sidebar')}
      </div>

      <div class="np-pad-area" id="np-pad-area-sidebar" ${numpadHidden}>
        ${buildNumpadGridHTML('np-sidebar')}
        ${state.pasteEnabled && !state.floatingText ? `
          <div class="np-text-section-sidebar" id="np-sidebar-text-section">
            ${buildTextButtonsHTML('np-sidebar')}
          </div>
        ` : state.pasteEnabled ? `
          <div style="padding:8px 12px;font-size:10px;color:var(--np-text-muted);text-align:center;opacity:0.6;">
            Text buttons are floating
          </div>
        ` : ''}
      </div>

      <div id="np-floating-num-placeholder" ${placeholderShown}
        style="flex-direction:column;align-items:center;justify-content:center;
               padding:12px 16px;gap:6px;color:var(--np-text-muted,#868e96);
               font-size:11px;text-align:center;
               user-select:none;-webkit-user-select:none;">
        <span style="opacity:0.55;">NumPad is floating</span>
      </div>
    `;
  }

  // ══════════════════════════════════════════════════════════════════════
  // HTML BUILDERS — FLOAT PANELS
  // ══════════════════════════════════════════════════════════════════════
  function buildFloatNumPanelHTML() {
    return `
      <div class="np-resize-handle-bl" id="np-float-num-resize-bl">
        <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor">
          <path d="M0 12 L12 0 L12 2 L2 12 Z M0 12 L6 12 L12 6 L12 8 L8 12 Z"/>
        </svg>
      </div>
      <div class="np-float-titlebar" id="np-float-num-titlebar">
        <div class="np-drag-handle" id="np-float-num-drag-handle" title="Drag to move">
          <svg viewBox="0 0 20 20" fill="currentColor" width="16" height="16">
            <path d="M7 2a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM13 2a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM7 8a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM13 8a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM7 14a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM13 14a2 2 0 1 1 0 4 2 2 0 0 1 0-4z"/>
          </svg>
        </div>
        <div class="np-float-title-center">
          <span class="np-float-logo">⌨</span>
          <span class="np-float-label">NumPad</span>
        </div>
        <div class="np-float-actions">
          <button class="np-icon-btn" id="np-float-num-settings-toggle" title="Settings" style="user-select:none;">
            <svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14">
              <path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"/>
            </svg>
          </button>
          <button class="np-icon-btn" id="np-dock-num-btn" title="Dock back to sidebar" style="user-select:none;">
            <svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14">
              <path fill-rule="evenodd" d="M3 4a1 1 0 011-1h12a1 1 0 011 1v12a1 1 0 01-1 1H4a1 1 0 01-1-1V4zm2 1v10h10V5H5z" clip-rule="evenodd"/>
              <path d="M8 9a1 1 0 011-1h2a1 1 0 010 2H9a1 1 0 01-1-1z"/>
            </svg>
          </button>
        </div>
      </div>
      <div class="np-settings-panel" id="np-float-num-settings-panel">
        ${buildSettingsHTML('np-float-num')}
      </div>
      <div class="np-float-body">
        ${buildNumpadGridHTML('np-float-num')}
      </div>
    `;
  }

  function buildFloatTextPanelHTML() {
    return `
      <div class="np-resize-handle-bl" id="np-float-text-resize-bl">
        <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor">
          <path d="M0 12 L12 0 L12 2 L2 12 Z M0 12 L6 12 L12 6 L12 8 L8 12 Z"/>
        </svg>
      </div>
      <div class="np-float-titlebar" id="np-float-text-titlebar">
        <div class="np-drag-handle" id="np-float-text-drag-handle" title="Drag to move">
          <svg viewBox="0 0 20 20" fill="currentColor" width="16" height="16">
            <path d="M7 2a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM13 2a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM7 8a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM13 8a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM7 14a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM13 14a2 2 0 1 1 0 4 2 2 0 0 1 0-4z"/>
          </svg>
        </div>
        <div class="np-float-title-center">
          <span class="np-float-logo" style="color:#69db7c;">📝</span>
        </div>
        <div class="np-float-actions">
          <button class="np-icon-btn" id="np-float-text-settings-toggle" title="Settings" style="user-select:none;">
            <svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14">
              <path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"/>
            </svg>
          </button>
          <button class="np-icon-btn" id="np-dock-text-btn" title="Dock back to sidebar" style="user-select:none;">
            <svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14">
              <path fill-rule="evenodd" d="M3 4a1 1 0 011-1h12a1 1 0 011 1v12a1 1 0 01-1 1H4a1 1 0 01-1-1V4zm2 1v10h10V5H5z" clip-rule="evenodd"/>
              <path d="M8 9a1 1 0 011-1h2a1 1 0 010 2H9a1 1 0 01-1-1z"/>
            </svg>
          </button>
        </div>
      </div>
      <div class="np-settings-panel" id="np-float-text-settings-panel">
        ${buildSettingsHTML('np-float-text')}
      </div>
      <div class="np-float-body">
        ${buildTextButtonsHTML('np-float-text')}
      </div>
    `;
  }

  // ══════════════════════════════════════════════════════════════════════
  // DOM INJECTION
  // ══════════════════════════════════════════════════════════════════════
  function inject() {
    if (document.getElementById(IDs.LAYOUT_ROOT)) return;

    const scrollX = window.scrollX || 0;
    const scrollY = window.scrollY || 0;

    const layoutRoot = document.createElement('div');
    layoutRoot.id = IDs.LAYOUT_ROOT;

    const pageContainer = document.createElement('div');
    pageContainer.id = IDs.PAGE_CONTAINER;

    const sidebarWrapper = document.createElement('aside');
    sidebarWrapper.id = IDs.SIDEBAR_WRAPPER;

    const sidebarW = computeSidebarSize();
    applySidebarSize(sidebarWrapper, sidebarW);

    const sidebarContent = document.createElement('div');
    sidebarContent.id = IDs.SIDEBAR_CONTENT;
    sidebarContent.innerHTML = buildSidebarHTML();

    const resizer = document.createElement('div');
    resizer.id = IDs.RESIZER;
    resizer.className = 'np-resizer';
    resizer.title = 'Drag to resize';

    sidebarWrapper.appendChild(resizer);
    sidebarWrapper.appendChild(sidebarContent);

    while (document.body.firstChild) pageContainer.appendChild(document.body.firstChild);

    layoutRoot.appendChild(pageContainer);
    layoutRoot.appendChild(sidebarWrapper);
    document.body.appendChild(layoutRoot);

    applyLayoutStyles();
    window.scrollTo(scrollX, scrollY);

    attachSidebarListeners();
    initShortcutFieldCapture();

    if (!state.enabled) applySidebarVisibility(false);
    if (state.floatingNum) createFloatNumPanel();
    if (state.floatingText && state.pasteEnabled) createFloatTextPanel();

    syncShortcuts();
  }

  function computeSidebarSize() {
    if (!state.enabled) return 0;
    if (state.floatingNum) return 32;
    return state.open ? state.width : 32;
  }

  function applySidebarSize(wrapper, size) {
    const dock = state.sidebarDock || 'right';
    const isHoriz = dock === 'top' || dock === 'bottom';
    if (isHoriz) { wrapper.style.height = size + 'px'; wrapper.style.width = ''; }
    else { wrapper.style.width = size + 'px'; wrapper.style.height = ''; }
  }

  // ══════════════════════════════════════════════════════════════════════
  // ENABLE / DISABLE
  // ══════════════════════════════════════════════════════════════════════
  function applySidebarVisibility(show) {
    const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER);
    if (!wrapper) return;
    if (!show) {
      wrapper.style.width = '0px';
      wrapper.style.height = '0px';
      wrapper.style.overflow = 'hidden';
      const fp = document.getElementById(IDs.FLOAT_NUM_PANEL);
      if (fp) fp.style.display = 'none';
      const ftp = document.getElementById(IDs.FLOAT_TEXT_PANEL);
      if (ftp) ftp.style.display = 'none';
      removeShortcuts();
    } else {
      wrapper.style.overflow = '';
      applySidebarSize(wrapper, computeSidebarSize());
      const fp = document.getElementById(IDs.FLOAT_NUM_PANEL);
      if (fp) fp.style.display = '';
      const ftp = document.getElementById(IDs.FLOAT_TEXT_PANEL);
      if (ftp && state.pasteEnabled) ftp.style.display = '';
      syncShortcuts();
    }
  }

  function toggleEnabled() {
    state.enabled = !state.enabled;
    persist();
    const btn = document.getElementById('np-power-toggle');
    if (btn) {
      btn.className = `np-power-toggle ${state.enabled ? 'np-on' : 'np-off'}`;
      btn.title = state.enabled ? 'Disable extension' : 'Enable extension';
      btn.querySelector('span:last-child').textContent = state.enabled ? 'ON' : 'OFF';
    }
    applySidebarVisibility(state.enabled);
  }

  // ══════════════════════════════════════════════════════════════════════
  // FLOATING NUM PANEL
  // ══════════════════════════════════════════════════════════════════════
  function createFloatNumPanel() {
    document.getElementById(IDs.FLOAT_NUM_PANEL)?.remove();

    const panel = document.createElement('div');
    panel.id = IDs.FLOAT_NUM_PANEL;
    panel.className = 'np-float-panel';
    panel.innerHTML = buildFloatNumPanelHTML();

    const vw = window.innerWidth, vh = window.innerHeight;
    state.floatNumX = Math.max(0, Math.min(state.floatNumX, vw - MIN_FLOAT_W));
    state.floatNumY = Math.max(0, Math.min(state.floatNumY, vh - MIN_FLOAT_H));

    panel.style.left = state.floatNumX + 'px';
    panel.style.top = state.floatNumY + 'px';
    if (state.floatNumW > 0) { panel.style.width = state.floatNumW + 'px'; panel.style.height = state.floatNumH + 'px'; }
    if (!state.enabled) panel.style.display = 'none';

    document.documentElement.appendChild(panel);

    if (state.floatNumW === 0) {
      requestAnimationFrame(() => {
        const rect = panel.getBoundingClientRect();
        state.floatNumW = Math.round(rect.width);
        state.floatNumH = Math.round(rect.height);
        panel.style.width = state.floatNumW + 'px';
        panel.style.height = state.floatNumH + 'px';
        persist();
      });
    }
    attachFloatNumListeners(panel);
  }

  function enterFloatingNum() {
    state.floatingNum = true;
    state.floatNumW = 0;
    persist();
    const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER);
    if (wrapper) applySidebarSize(wrapper, 32);
    const padArea = document.getElementById('np-pad-area-sidebar');
    const placeholder = document.getElementById('np-floating-num-placeholder');
    if (padArea) padArea.style.display = 'none';
    if (placeholder) placeholder.style.display = 'flex';
    createFloatNumPanel();
  }

  function exitFloatingNum() {
    state.floatingNum = false;
    persist();
    document.getElementById(IDs.FLOAT_NUM_PANEL)?.remove();
    const padArea = document.getElementById('np-pad-area-sidebar');
    const placeholder = document.getElementById('np-floating-num-placeholder');
    if (padArea) padArea.style.display = '';
    if (placeholder) placeholder.style.display = 'none';
    const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER);
    if (wrapper) applySidebarSize(wrapper, state.enabled ? (state.open ? state.width : 32) : 0);
    bindNumpadButtons('np-sidebar');
  }

  // ══════════════════════════════════════════════════════════════════════
  // FLOATING TEXT PANEL
  // ══════════════════════════════════════════════════════════════════════
  function createFloatTextPanel() {
    document.getElementById(IDs.FLOAT_TEXT_PANEL)?.remove();
    if (!state.pasteEnabled) return;

    const panel = document.createElement('div');
    panel.id = IDs.FLOAT_TEXT_PANEL;
    panel.className = 'np-float-panel';
    panel.innerHTML = buildFloatTextPanelHTML();

    const vw = window.innerWidth, vh = window.innerHeight;
    state.floatTextX = Math.max(0, Math.min(state.floatTextX, vw - MIN_FLOAT_W));
    state.floatTextY = Math.max(0, Math.min(state.floatTextY, vh - MIN_FLOAT_H));

    panel.style.left = state.floatTextX + 'px';
    panel.style.top = state.floatTextY + 'px';
    if (state.floatTextW > 0) { panel.style.width = state.floatTextW + 'px'; panel.style.height = state.floatTextH + 'px'; }
    if (!state.enabled) panel.style.display = 'none';

    document.documentElement.appendChild(panel);

    if (state.floatTextW === 0) {
      requestAnimationFrame(() => {
        const rect = panel.getBoundingClientRect();
        state.floatTextW = Math.round(rect.width);
        state.floatTextH = Math.round(rect.height);
        panel.style.width = state.floatTextW + 'px';
        panel.style.height = state.floatTextH + 'px';
        persist();
      });
    }
    attachFloatTextListeners(panel);
  }

  function enterFloatingText() {
    state.floatingText = true;
    state.floatTextW = 0;
    persist();
    // Rebuild sidebar so the section disappears
    rebuildSidebarContent();
    createFloatTextPanel();
  }

  function exitFloatingText() {
    state.floatingText = false;
    persist();
    document.getElementById(IDs.FLOAT_TEXT_PANEL)?.remove();
    rebuildSidebarContent();
  }

  // ══════════════════════════════════════════════════════════════════════
  // SIDEBAR LISTENERS
  // ══════════════════════════════════════════════════════════════════════
  function attachSidebarListeners() {
    document.getElementById('np-collapse-btn')?.addEventListener('click', toggleSidebar);
    document.getElementById('np-settings-toggle')?.addEventListener('click', () => toggleSettings('np-settings-panel'));
    document.getElementById('np-float-num-toggle-btn')?.addEventListener('click', enterFloatingNum);
    document.getElementById('np-float-text-toggle-btn')?.addEventListener('click', enterFloatingText);
    document.getElementById('np-power-toggle')?.addEventListener('click', toggleEnabled);

    const settingsPanel = document.getElementById('np-settings-panel');
    if (settingsPanel) attachSettingsPanelListeners(settingsPanel, 'np-sidebar');

    bindNumpadButtons('np-sidebar');
    bindTextButtons('np-sidebar');
    initSidebarResizer();
  }

  // ══════════════════════════════════════════════════════════════════════
  // FLOAT LISTENERS
  // ══════════════════════════════════════════════════════════════════════
  function attachFloatNumListeners(panel) {
    panel.querySelector('#np-dock-num-btn')?.addEventListener('click', exitFloatingNum);
    panel.querySelector('#np-float-num-settings-toggle')?.addEventListener('click', () => {
      toggleSettings('np-float-num-settings-panel');
    });
    const settingsPanel = panel.querySelector('#np-float-num-settings-panel');
    if (settingsPanel) attachSettingsPanelListeners(settingsPanel, 'np-float-num');
    bindNumpadButtons('np-float-num');
    initFloatDrag(panel, 'num');
    initFloatResize(panel, 'num');
  }

  function attachFloatTextListeners(panel) {
    panel.querySelector('#np-dock-text-btn')?.addEventListener('click', exitFloatingText);
    panel.querySelector('#np-float-text-settings-toggle')?.addEventListener('click', () => {
      toggleSettings('np-float-text-settings-panel');
    });
    const settingsPanel = panel.querySelector('#np-float-text-settings-panel');
    if (settingsPanel) attachSettingsPanelListeners(settingsPanel, 'np-float-text');
    bindTextButtons('np-float-text');
    initFloatDrag(panel, 'text');
    initFloatResize(panel, 'text');
  }

  // ══════════════════════════════════════════════════════════════════════
  // SETTINGS PANEL LOGIC
  // ══════════════════════════════════════════════════════════════════════
  function attachSettingsPanelListeners(panel, prefix) {
    // Tab switching
    panel.querySelectorAll('.np-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        const tabName = tab.dataset.tab;
        state.activeTab = tabName;
        syncActiveSettingsTab(tabName);
        persist();
      });
    });

    const selectorTab = panel.querySelector('[data-tab-content="selector"]');
    if (selectorTab) attachSelectorTabListeners(selectorTab, prefix);

    const pasteTab = panel.querySelector('[data-tab-content="paste"]');
    if (pasteTab) attachPasteTabListeners(pasteTab, prefix);

    panel.addEventListener('click', (e) => {
      const actionEl = e.target.closest('[data-action]');
      if (!actionEl) return;
      const action = actionEl.dataset.action;

      if (action === 'save-buttons') {
        const inputs = panel.querySelectorAll('.np-btn-slot-input');
        state.buttonValues = Array.from(inputs).map(inp => { const v = inp.value.trim(); return v === '' ? 'NONE' : v; });
        persist();
        rebuildAllNumpadGrids();
        showStatus(`${prefix}-status`, 'Buttons updated ✓', 'success');
      }
      if (action === 'save-layout') {
        const colsEl = panel.querySelector(`#${prefix}-grid-cols`);
        const rowsEl = panel.querySelector(`#${prefix}-grid-rows`);
        const cols = Math.max(1, Math.min(6, parseInt(colsEl?.value) || DEFAULT_COLS));
        const rows = Math.max(1, Math.min(10, parseInt(rowsEl?.value) || DEFAULT_ROWS));
        state.gridCols = cols;
        state.gridRows = rows;
        const newLen = rows * cols;
        while (state.buttonValues.length < newLen) state.buttonValues.push('NONE');
        state.buttonValues = state.buttonValues.slice(0, newLen);
        persist();
        rebuildAll();
        showStatus(`${prefix}-status`, 'Layout updated ✓', 'success');
      }
      if (action === 'set-dock') {
        const newDock = actionEl.dataset.dock;
        state.sidebarDock = newDock;
        persist();
        document.querySelectorAll('[data-action="set-dock"]').forEach(b => b.classList.toggle('np-dock-active', b.dataset.dock === newDock));
        applyLayoutStyles();
        const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER);
        if (wrapper) applySidebarSize(wrapper, computeSidebarSize());
        initSidebarResizer();
      }
    });
  }

  // ══════════════════════════════════════════════════════════════════════
  // SELECTOR TAB LISTENERS
  // ══════════════════════════════════════════════════════════════════════
  function attachSelectorTabListeners(tabEl, prefix) {
    tabEl.querySelectorAll('.np-sel-dropdown').forEach(sel => {
      sel.addEventListener('change', () => {
        const type = sel.dataset.selType;
        const val = sel.value;
        const cfg = SELECTOR_CONFIGS[type];
        const presets = state[cfg.presetsKey];

        if (val === '__add_new__') {
          const newId = 'preset_' + Date.now();
          presets.push({ id: newId, label: 'New Selector', value: '' });
          state[cfg.presetIdKey] = newId;
          state[cfg.stateKey] = '';
          persist();
          rebuildAllSelectorDropdowns();
        } else if (val === '') {
          state[cfg.presetIdKey] = '';
          state[cfg.stateKey] = '';
          persist();
          rebuildAllSelectorDropdowns();
        } else {
          const preset = presets.find(p => p.id === val);
          if (preset) {
            state[cfg.presetIdKey] = val;
            state[cfg.stateKey] = preset.value;
            persist();
            rebuildAllSelectorDropdowns();
          }
        }
      });
    });

    tabEl.addEventListener('click', (e) => {
      const actionEl = e.target.closest('[data-action]');
      if (!actionEl) return;
      const action = actionEl.dataset.action;
      const type = actionEl.dataset.presetType;
      if (!type) return;
      const cfg = SELECTOR_CONFIGS[type];

      if (action === 'save-preset') {
        const presetId = state[cfg.presetIdKey];
        const presets = state[cfg.presetsKey];
        const preset = presets.find(p => p.id === presetId);
        if (!preset) return;
        const labelInp = tabEl.querySelector(`#${prefix}-${type}-label-inp`);
        const valueInp = tabEl.querySelector(`#${prefix}-${type}-value-inp`);
        if (labelInp) preset.label = labelInp.value.trim() || preset.label;
        if (valueInp) { preset.value = valueInp.value.trim(); state[cfg.stateKey] = preset.value; }
        persist();
        rebuildAllSelectorDropdowns();
      }

      if (action === 'delete-preset') {
        const presetId = state[cfg.presetIdKey];
        state[cfg.presetsKey] = state[cfg.presetsKey].filter(p => p.id !== presetId);
        state[cfg.presetIdKey] = '';
        state[cfg.stateKey] = '';
        persist();
        rebuildAllSelectorDropdowns();
      }

      if (action === 'pick-element') {
        const valueInp = tabEl.querySelector(`#${prefix}-${type}-value-inp`);
        if (!valueInp) return;
        startElementPicker((selector) => {
          valueInp.value = selector;
          const presetId = state[cfg.presetIdKey];
          const presets = state[cfg.presetsKey];
          const preset = presets.find(p => p.id === presetId);
          if (preset) {
            preset.value = selector;
            state[cfg.stateKey] = selector;
            persist();
          }
        });
      }
    });
  }

  function startElementPicker(onPick) {
    const highlight = document.createElement('div');
    highlight.id = '__ep-picker-highlight';
    highlight.style.cssText = 'position:fixed;pointer-events:none;z-index:2147483647;outline:2px solid #3b82f6;background:rgba(59,130,246,0.1);transition:none;box-sizing:border-box;';
    document.body.appendChild(highlight);
    document.body.style.cursor = 'crosshair';
    let lastTarget = null;

    const onMove = (e) => {
      const el = document.elementFromPoint(e.clientX, e.clientY);
      if (!el || el === highlight || lastTarget === el) return;
      lastTarget = el;
      const r = el.getBoundingClientRect();
      highlight.style.left = r.left + 'px'; highlight.style.top = r.top + 'px';
      highlight.style.width = r.width + 'px'; highlight.style.height = r.height + 'px';
    };
    const cleanup = () => {
      document.removeEventListener('mousemove', onMove, true);
      document.removeEventListener('click', onClick, true);
      document.removeEventListener('keydown', onKey, true);
      highlight.remove();
      document.body.style.cursor = '';
    };
    const onClick = (e) => {
      e.preventDefault(); e.stopPropagation(); cleanup();
      const el = document.elementFromPoint(e.clientX, e.clientY);
      if (!el) return;
      const selector = el.id ? `${el.tagName.toLowerCase()}#${CSS.escape(el.id)}` : generateSelector(el);
      if (selector) onPick(selector);
    };
    const onKey = (e) => { if (e.key === 'Escape') cleanup(); };
    document.addEventListener('mousemove', onMove, true);
    document.addEventListener('click', onClick, true);
    document.addEventListener('keydown', onKey, true);
  }

  function rebuildAllSelectorDropdowns() {
    ['np-sidebar', 'np-float-num'].forEach(prefix => {
      const panelId = prefix === 'np-sidebar' ? 'np-settings-panel' : 'np-float-num-settings-panel';
      const panel = document.getElementById(panelId);
      if (!panel) return;
      const selectorTab = panel.querySelector('[data-tab-content="selector"]');
      if (!selectorTab) return;
      selectorTab.innerHTML =
        Object.keys(SELECTOR_CONFIGS).map(type => buildSelectorDropdownHTML(prefix, type)).join('') +
        '<div class="np-settings-hint">Select a saved preset or pick 🎯 a new element on the page.</div>';
      attachSelectorTabListeners(selectorTab, prefix);
    });
  }

  // ══════════════════════════════════════════════════════════════════════
  // PASTE TAB LISTENERS
  // ══════════════════════════════════════════════════════════════════════
  function attachPasteTabListeners(tabEl, prefix) {
    if (tabEl.__pasteTabClickHandler) {
      tabEl.removeEventListener('click', tabEl.__pasteTabClickHandler);
    }

    const onClick = (e) => {
      const actionEl = e.target.closest('[data-action]');
      if (!actionEl) return;
      const action = actionEl.dataset.action;

      if (action === 'toggle-paste') {
        state.pasteEnabled = !state.pasteEnabled;
        persist();
        rebuildAll();
        // Hide/show float text panel
        if (!state.pasteEnabled) {
          document.getElementById(IDs.FLOAT_TEXT_PANEL)?.remove();
        } else if (state.floatingText) {
          createFloatTextPanel();
        }
        syncShortcuts();
      }

      if (action === 'toggle-shortcuts') {
        state.shortcutsEnabled = !state.shortcutsEnabled;
        persist();
        rebuildPasteTabAll();
        syncShortcuts();
      }

      if (action === 'add-paste-preset') {
        const newId = 'pp_' + Date.now();
        state.pastePresets.push({ id: newId, label: 'New Preset', entries: [] });
        state.pasteActivePresetId = newId;
        persist();
        rebuildPasteTabAll();
        rebuildAllTextButtons();
      }

      if (action === 'rename-paste-preset') {
        const nameInp = tabEl.querySelector(`#${prefix}-paste-preset-name`);
        const preset = getActivePreset();
        if (preset && nameInp) {
          preset.label = nameInp.value.trim() || preset.label;
          persist();
          rebuildPasteTabAll();
          rebuildAllTextButtons();
        }
      }

      if (action === 'delete-paste-preset') {
        state.pastePresets = state.pastePresets.filter(p => p.id !== state.pasteActivePresetId);
        state.pasteActivePresetId = state.pastePresets.length > 0 ? state.pastePresets[0].id : '';
        persist();
        rebuildPasteTabAll();
        rebuildAllTextButtons();
        syncShortcuts();
      }

      if (action === 'add-paste-entry') {
        const preset = getActivePreset();
        if (!preset) return;
        const newEntry = { id: 'pe_' + Date.now(), label: 'Text ' + (preset.entries.length + 1), text: '', shortcut: '' };
        preset.entries.push(newEntry);
        persist();
        rebuildPasteTabAll();
        rebuildAllTextButtons();
      }

      if (action === 'save-entry') {
        const entryId = actionEl.dataset.entryId;
        const preset = getActivePreset();
        if (!preset) return;
        const entry = preset.entries.find(en => en.id === entryId);
        if (!entry) return;
        const labelInp = tabEl.querySelector(`[data-entry-field="label"][data-entry-id="${entryId}"]`);
        const textInp = tabEl.querySelector(`[data-entry-field="text"][data-entry-id="${entryId}"]`);
        const scInp = tabEl.querySelector(`[data-entry-field="shortcut"][data-entry-id="${entryId}"]`);
        if (labelInp) entry.label = labelInp.value.trim() || entry.label;
        if (textInp) entry.text = textInp.value;
        if (scInp) entry.shortcut = scInp.value.trim();
        persist();
        rebuildPasteTabAll();
        rebuildAllTextButtons();
        syncShortcuts();
      }

      if (action === 'delete-entry') {
        const entryId = actionEl.dataset.entryId;
        const preset = getActivePreset();
        if (!preset) return;
        preset.entries = preset.entries.filter(en => en.id !== entryId);
        persist();
        rebuildPasteTabAll();
        rebuildAllTextButtons();
        syncShortcuts();
      }

      if (action === 'move-entry-up') {
        const entryId = actionEl.dataset.entryId;
        const preset = getActivePreset();
        if (!preset) return;
        const idx = preset.entries.findIndex(en => en.id === entryId);
        if (idx > 0) { [preset.entries[idx - 1], preset.entries[idx]] = [preset.entries[idx], preset.entries[idx - 1]]; }
        persist();
        rebuildPasteTabAll();
        rebuildAllTextButtons();
      }

      if (action === 'move-entry-down') {
        const entryId = actionEl.dataset.entryId;
        const preset = getActivePreset();
        if (!preset) return;
        const idx = preset.entries.findIndex(en => en.id === entryId);
        if (idx < preset.entries.length - 1) { [preset.entries[idx], preset.entries[idx + 1]] = [preset.entries[idx + 1], preset.entries[idx]]; }
        persist();
        rebuildPasteTabAll();
        rebuildAllTextButtons();
      }
    };

    tabEl.__pasteTabClickHandler = onClick;
    tabEl.addEventListener('click', onClick);

    // Preset dropdown change
    const presetDd = tabEl.querySelector(`#${prefix}-paste-preset-dropdown`);
    if (presetDd) {
      presetDd.addEventListener('change', () => {
        state.pasteActivePresetId = presetDd.value;
        persist();
        rebuildPasteTabAll();
        rebuildAllTextButtons();
        syncShortcuts();
      });
    }
  }

  function rebuildPasteTabAll() {
    ['np-sidebar', 'np-float-num'].forEach(prefix => {
      const panelId = prefix === 'np-sidebar' ? 'np-settings-panel' : 'np-float-num-settings-panel';
      const panel = document.getElementById(panelId);
      if (!panel) return;
      const pasteTab = panel.querySelector('[data-tab-content="paste"]');
      if (!pasteTab) return;
      pasteTab.innerHTML = buildPasteTabHTML(prefix);
      attachPasteTabListeners(pasteTab, prefix);
    });
  }

  // ══════════════════════════════════════════════════════════════════════
  // UDVASH AUTO-SETUP
  // ══════════════════════════════════════════════════════════════════════
  /**
   * On first load, create default selector presets for the Udvash evaluation page
   * so users don't need to manually configure anything.
   */
  function autoPopulateUdvashSelectors() {
    const defaults = [
      { type: 'input', label: 'Udvash Marks', value: '#Marks' },
      { type: 'pen', label: 'Udvash Draw Pen', value: '#btn-draw-line' },
      { type: 'text', label: 'Udvash Text Mode', value: '#btn-text' },
    ];
    let changed = false;
    defaults.forEach(({ type, label, value }) => {
      const cfg = SELECTOR_CONFIGS[type];
      if (state[cfg.presetsKey].length === 0) {
        const id = `udvash_default_${type}`;
        state[cfg.presetsKey].push({ id, label, value });
        state[cfg.presetIdKey] = id;
        state[cfg.stateKey] = value;
        changed = true;
      }
    });
    if (changed) persist();
  }

  // ══════════════════════════════════════════════════════════════════════
  // TUI EDITOR DIRECT API — INJECT TEXT
  // ══════════════════════════════════════════════════════════════════════
  /**
   * Returns the active TUI ImageEditor instance from the page's globals,
   * or null if not available.
   */
  function getPageEditor() {
    try {
      if (window.editorList && window.activeSlideId && window.editorList[window.activeSlideId]) {
        return window.editorList[window.activeSlideId];
      }
    } catch (e) { /* cross-origin or not on editor page */ }
    return null;
  }

  /**
   * Re-registers the original page addText handler that inserts 'Double Click'.
   * Must be called after our one-shot handler runs or times out.
   */
  function restoreOriginalAddTextHandler(editor) {
    try {
      editor.off('addText');
      editor.on('addText', function (pos) {
        const color = (typeof window.toolColor !== 'undefined') ? window.toolColor : '#FF0000';
        editor.addText('Double Click', {
          position: pos.originPosition,
          styles: { fill: color, fontSize: 40, fontWeight: 'normal', fontFamily: 'Times New Roman' },
          autofocus: true,
        }).then(function () {
          if (typeof window.objectAddedCount !== 'undefined') window.objectAddedCount++;
          if (window.annotatedObjects && window.activeSlideId)
            window.annotatedObjects[window.activeSlideId] = (window.annotatedObjects[window.activeSlideId] || 0) + 1;
          if (typeof window.CountAnnotateImage === 'function') window.CountAnnotateImage();
          if (window.mainStackList) window.mainStackList.push('text');
          if (window.undoStackList) window.undoStackList.push('remove-text');
          if (window.redoStackList) window.redoStackList = [];
        });
      });
    } catch (e) { /* ignore */ }
  }

  /**
   * Inject a preset text string directly via the TUI ImageEditor addText API.
   * Flow:
   *   1. Activate TEXT drawing mode (click #btn-text or call activateTextMode)
   *   2. Install a one-shot addText handler that places our text instead of 'Double Click'
   *   3. After placement, restore the original handler and switch back to pen/draw mode
   *
   * Falls back to the old runPasteFlow if the editor API is unavailable.
   */
  let editorTextInjectionActive = false;

  function injectTextViaEditor(text, statusId) {
    if (!state.enabled || !state.pasteEnabled) return;
    if (!text) { showStatus(statusId, 'No text configured', 'warn'); return; }

    const editor = getPageEditor();
    if (!editor) {
      // Fallback: page not the Udvash editor — use old paste flow
      runPasteFlow(text, lastMouseX, lastMouseY, statusId, null, '');
      return;
    }

    if (editorTextInjectionActive) {
      showStatus(statusId, 'Already waiting for canvas click…', 'warn');
      return;
    }

    editorTextInjectionActive = true;
    let placed = false;

    const color = (typeof window.toolColor !== 'undefined') ? window.toolColor : '#FF0000';

    const oneShotHandler = function (pos) {
      if (placed) return;
      placed = true;

      editor.addText(text, {
        position: pos.originPosition,
        styles: { fill: color, fontSize: 40, fontWeight: 'normal', fontFamily: 'Times New Roman' },
        autofocus: true,
      }).then(function () {
        // Mirror the page's own bookkeeping
        if (typeof window.objectAddedCount !== 'undefined') window.objectAddedCount++;
        if (window.annotatedObjects && window.activeSlideId)
          window.annotatedObjects[window.activeSlideId] = (window.annotatedObjects[window.activeSlideId] || 0) + 1;
        if (typeof window.CountAnnotateImage === 'function') window.CountAnnotateImage();
        if (window.mainStackList) window.mainStackList.push('text');
        if (window.undoStackList) window.undoStackList.push('remove-text');
        if (window.redoStackList) window.redoStackList = [];

        // Restore original handler
        restoreOriginalAddTextHandler(editor);
        editorTextInjectionActive = false;

        // Switch back to pen/draw mode
        const searchRoot = getPageSearchRoot();
        const drawBtn = searchRoot.querySelector('#btn-draw-line');
        if (drawBtn) setTimeout(() => drawBtn.click(), 60);

        showStatus(statusId, 'Text placed ✓', 'success');
      }).catch(function () {
        restoreOriginalAddTextHandler(editor);
        editorTextInjectionActive = false;
        showStatus(statusId, 'Text placement failed', 'error');
      });
    };

    // Patch the addText handler with our one-shot version
    editor.off('addText');
    editor.on('addText', oneShotHandler);

    // Activate TEXT drawing mode so canvas responds to click with addText event
    const searchRoot = getPageSearchRoot();
    const textBtn = searchRoot.querySelector('#btn-text');
    if (textBtn) {
      textBtn.click();
    } else if (typeof window.activateTextMode === 'function') {
      window.activateTextMode();
    } else {
      try {
        editor.stopDrawingMode();
        editor.startDrawingMode('TEXT');
      } catch (e) { /* ignore */ }
    }

    showStatus(statusId, 'Click on canvas to place text…', 'success');

    // Safety timeout: restore original handler if user never clicks
    setTimeout(() => {
      if (!placed) {
        restoreOriginalAddTextHandler(editor);
        editorTextInjectionActive = false;
        showStatus(statusId, 'Text placement cancelled (timeout)', 'warn');
      }
    }, 15000);
  }

  // ══════════════════════════════════════════════════════════════════════
  // NUMPAD BUTTONS
  // ══════════════════════════════════════════════════════════════════════
  function bindNumpadButtons(prefix) {
    const grid = document.getElementById(`${prefix}-grid`);
    if (!grid) return;
    if (grid.__npDelegatedHandler) return;

    const onActivate = (e) => {
      const button = e.target.closest('.np-btn');
      if (!button || !grid.contains(button)) return;
      triggerRipple(button, e);
      handleNumpadClick(button.dataset.value, `${prefix}-status`);
    };

    const onTouchEnd = (e) => {
      e.preventDefault();
      const touch = e.changedTouches[0];
      const button = e.target.closest('.np-btn');
      if (!button || !grid.contains(button)) return;
      triggerRipple(button, touch);
      handleNumpadClick(button.dataset.value, `${prefix}-status`);
    };

    grid.addEventListener('click', onActivate);
    grid.addEventListener('touchend', onTouchEnd, { passive: false });
    grid.__npDelegatedHandler = true;
  }

  function handleNumpadClick(value, statusId) {
    if (!state.enabled) return;
    const searchRoot = getPageSearchRoot();

    // Auto-detect: if no inputSelector set, try the page's #Marks field
    const sel = state.inputSelector;
    const input = sel
      ? searchRoot.querySelector(sel)
      : searchRoot.querySelector('#Marks');

    if (!input) {
      showStatus(statusId, sel ? `No element: ${sel}` : 'No #Marks input found', 'error');
      return;
    }

    const nativeValueSetter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(input), 'value');
    if (nativeValueSetter && nativeValueSetter.set) nativeValueSetter.set.call(input, value);
    else input.value = value;

    ['input', 'change'].forEach(evtName => input.dispatchEvent(new Event(evtName, { bubbles: true, cancelable: true })));
    input.dispatchEvent(new Event('blur', { bubbles: true }));
    showStatus(statusId, `Inserted ${value}`, 'success');

    // Only auto-submit if the user has explicitly configured a submit selector
    const submitSel = state.submitSelector;
    if (submitSel) {
      const submitBtn = searchRoot.querySelector(submitSel);
      if (submitBtn) setTimeout(() => { submitBtn.click(); showStatus(statusId, `Submitted → ${value}`, 'success'); }, 80);
      else showStatus(statusId, `Submit not found: ${submitSel}`, 'warn');
    }
  }

  // ══════════════════════════════════════════════════════════════════════
  // TEXT BUTTONS
  // ══════════════════════════════════════════════════════════════════════
  function bindTextButtons(prefix) {
    // Works for both sidebar and float-text containers
    const section = document.getElementById(`${prefix}-text-btns`);
    if (!section) return;
    const grid = section.querySelector('.np-text-grid');
    if (!grid) return;
    if (grid.__npDelegatedHandler) return;

    const doAction = (button, point, statusSource) => {
      const entryId = button.dataset.pasteEntryId;
      const preset = getActivePreset();
      const entry = preset?.entries.find(en => en.id === entryId);
      if (!entry) return;
      triggerRipple(button, point);

      // Route: use the direct TUI editor API if available (Udvash page),
      // otherwise fall back to the old clipboard/DOM paste flow.
      if (getPageEditor()) {
        injectTextViaEditor(entry.text, `${prefix}-text-status`);
      } else {
        runPasteFlow(entry.text, lastMouseX, lastMouseY, `${prefix}-text-status`, button, entryId);
      }
    };

    grid.addEventListener('click', (e) => {
      const button = e.target.closest('.np-text-btn');
      if (!button || !grid.contains(button)) return;
      doAction(button, e);
    });

    grid.addEventListener('touchend', (e) => {
      e.preventDefault();
      const touch = e.changedTouches[0];
      const button = e.target.closest('.np-text-btn');
      if (!button || !grid.contains(button)) return;
      if (touch) {
        lastMouseX = touch.clientX;
        lastMouseY = touch.clientY;
      }
      doAction(button, touch || e);
    }, { passive: false });

    grid.__npDelegatedHandler = true;
  }

  // ══════════════════════════════════════════════════════════════════════
  // PASTE AUTOMATION FLOW
  // ══════════════════════════════════════════════════════════════════════
  let pasteFlowRunning = false;

  function clickSelector(sel) {
    if (!sel) return false;
    const root = getPageSearchRoot();
    const el = root.querySelector(sel);
    if (!el) return false;
    el.click();
    return true;
  }

  function clickPointAtPosition(x, y) {
    const target = document.elementFromPoint(x, y);
    if (!target) return false;

    const options = {
      bubbles: true,
      cancelable: true,
      clientX: x,
      clientY: y,
      view: window,
    };

    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(type => {
      try {
        target.dispatchEvent(new MouseEvent(type, options));
      } catch {
        // Ignore browsers that do not allow some synthetic mouse events here.
      }
    });

    return true;
  }

  function getTextButtonElement(entryId) {
    if (!entryId) return null;
    return document.querySelector(`.np-text-btn[data-paste-entry-id="${CSS.escape(entryId)}"]`);
  }

  function pasteTextAtPosition(text, x, y) {
    return new Promise((resolve) => {
      // Try clipboard API first (most reliable for real paste)
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(() => {
          const el = document.elementFromPoint(x, y);
          if (el) {
            el.focus();
            el.click();
          }
          setTimeout(() => {
            // Dispatch paste event with data
            const pasteEvent = new ClipboardEvent('paste', {
              bubbles: true,
              cancelable: true,
              clipboardData: new DataTransfer(),
            });
            try { pasteEvent.clipboardData.setData('text/plain', text); } catch { }
            const target = document.elementFromPoint(x, y) || document.activeElement;
            if (target) {
              target.dispatchEvent(pasteEvent);
              // Fallback: if it's an input/textarea, set value
              if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') {
                const nv = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(target), 'value');
                if (nv && nv.set) nv.set.call(target, text);
                else target.value = text;
                ['input', 'change'].forEach(ev => target.dispatchEvent(new Event(ev, { bubbles: true })));
              }
            }
            resolve();
          }, 80);
        }).catch(() => {
          // Fallback: direct element manipulation
          directPasteAtPosition(text, x, y);
          resolve();
        });
      } else {
        directPasteAtPosition(text, x, y);
        resolve();
      }
    });
  }

  function directPasteAtPosition(text, x, y) {
    const el = document.elementFromPoint(x, y);
    if (!el) return;
    el.focus();
    const pasteEvent = new ClipboardEvent('paste', {
      bubbles: true, cancelable: true,
      clipboardData: new DataTransfer(),
    });
    try { pasteEvent.clipboardData.setData('text/plain', text); } catch { }
    el.dispatchEvent(pasteEvent);
    // Also try execCommand for contentEditable / canvas editors
    try { document.execCommand('insertText', false, text); } catch { }
  }

  function isEditableElement(el) {
    if (!el) return false;
    const tag = el.tagName ? el.tagName.toUpperCase() : '';
    return tag === 'INPUT' || tag === 'TEXTAREA' || el.isContentEditable || el.getAttribute?.('contenteditable') === 'true';
  }

  function waitForEditableTarget(x, y, timeoutMs = 2500) {
    return new Promise((resolve) => {
      const start = Date.now();

      const tick = () => {
        const target = document.activeElement && isEditableElement(document.activeElement)
          ? document.activeElement
          : document.elementFromPoint(x, y);

        if (isEditableElement(target)) {
          resolve(target);
          return;
        }

        if (Date.now() - start >= timeoutMs) {
          resolve(target || document.activeElement || null);
          return;
        }

        setTimeout(tick, 50);
      };

      tick();
    });
  }

  function waitForUserClick(statusId) {
    return new Promise((resolve) => {
      const cleanup = () => {
        document.removeEventListener('click', onClick, true);
      };

      const finish = (e) => {
        cleanup();
        resolve({ x: e.clientX, y: e.clientY });
      };

      const onClick = (e) => {
        if (e.button !== 0) return;
        finish(e);
      };

      document.addEventListener('click', onClick, true);
      showStatus(statusId, 'Click where the text box should appear…', 'success');
    });
  }

  async function runPasteFlow(text, x, y, statusId, triggerButtonEl = null, entryId = '') {
    if (!state.enabled || !state.pasteEnabled) return;
    if (pasteFlowRunning) { showStatus(statusId, 'Already running…', 'warn'); return; }
    if (!text) { showStatus(statusId, 'No text configured', 'warn'); return; }

    pasteFlowRunning = true;
    showStatus(statusId, 'Running flow…', 'success');

    try {
      // 1. Click text button
      const textOk = clickSelector(state.textSelector);
      if (state.textSelector && !textOk) showStatus(statusId, 'Text btn not found', 'warn');
      await delay(120);

      // 2. Wait for the manual text placement click, then paste there
      const clickPos = await waitForUserClick(statusId);
      const target = await waitForEditableTarget(clickPos.x, clickPos.y);
      await delay(100);
      if (isEditableElement(target)) {
        target.focus?.();
        if (typeof target.click === 'function') target.click();
        const nativeSetter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(target), 'value');
        if (nativeSetter && nativeSetter.set) nativeSetter.set.call(target, text);
        else if ('value' in target) target.value = text;
        const pasteEvent = new ClipboardEvent('paste', {
          bubbles: true,
          cancelable: true,
          clipboardData: new DataTransfer(),
        });
        try { pasteEvent.clipboardData.setData('text/plain', text); } catch { }
        target.dispatchEvent(pasteEvent);
        ['input', 'change'].forEach(ev => target.dispatchEvent(new Event(ev, { bubbles: true, cancelable: true })));
      } else {
        await pasteTextAtPosition(text, clickPos.x, clickPos.y);
      }
      await delay(80);

      // Re-select the same text button that launched the paste flow.
      const textButton = triggerButtonEl && document.contains(triggerButtonEl)
        ? triggerButtonEl
        : getTextButtonElement(entryId);
      if (textButton) {
        textButton.click();
      } else {
        showStatus(statusId, 'Text btn not found', 'warn');
      }
      await delay(80);
      clickPointAtPosition(Math.max(0, clickPos.x - 4), clickPos.y);
      await delay(80);

      // 3. Click pen
      const penOk = clickSelector(state.penSelector);
      if (state.penSelector && !penOk) showStatus(statusId, 'Pen not found', 'warn');

      showStatus(statusId, 'Done ✓', 'success');
    } catch (err) {
      showStatus(statusId, 'Flow error', 'error');
    } finally {
      pasteFlowRunning = false;
    }
  }

  function delay(ms) { return new Promise(r => setTimeout(r, ms)); }

  // ══════════════════════════════════════════════════════════════════════
  // SHORTCUT MANAGER
  // ══════════════════════════════════════════════════════════════════════
  let _shortcutHandler = null;
  let _shortcutFieldHandler = null;
  let _shortcutFieldCaptureBound = false;

  function normalizeShortcutKey(key) {
    if (!key) return '';
    if (key.length === 1) return key.toUpperCase();
    return key.charAt(0).toUpperCase() + key.slice(1);
  }

  function formatShortcutFromEvent(e) {
    if (!e || ['Control', 'Shift', 'Alt', 'Meta'].includes(e.key)) return '';
    const parts = [];
    if (e.ctrlKey) parts.push('Ctrl');
    if (e.altKey) parts.push('Alt');
    if (e.shiftKey) parts.push('Shift');
    if (e.metaKey) parts.push('Meta');
    const key = normalizeShortcutKey(e.key);
    if (!key) return '';
    return [...parts, key].join('+');
  }

  function isEditableTarget(target) {
    if (!target || !target.closest) return false;
    return !!target.closest('input, textarea, select, [contenteditable="true"], .np-paste-shortcut-inp');
  }

  function commitShortcutValue(inputEl, shortcutValue) {
    const entryId = inputEl?.dataset?.entryId;
    const preset = getActivePreset();
    if (!entryId || !preset) return;
    const entry = preset.entries.find(en => en.id === entryId);
    if (!entry) return;

    if (shortcutValue) {
      for (const otherEntry of preset.entries) {
        if (otherEntry.id !== entry.id && otherEntry.shortcut === shortcutValue) {
          otherEntry.shortcut = '';
        }
      }
    }

    entry.shortcut = shortcutValue;
    inputEl.value = shortcutValue;
    persist();
    rebuildAllTextButtons();
    syncShortcuts();
  }

  function initShortcutFieldCapture() {
    if (_shortcutFieldCaptureBound) return;
    _shortcutFieldCaptureBound = true;

    _shortcutFieldHandler = (e) => {
      const target = e.target;
      if (!target || !target.matches || !target.matches('.np-paste-shortcut-inp')) return;

      e.preventDefault();
      e.stopPropagation();

      if (e.key === 'Escape' || e.key === 'Backspace' || e.key === 'Delete') {
        commitShortcutValue(target, '');
        return;
      }

      const shortcutValue = formatShortcutFromEvent(e);
      if (!shortcutValue) return;
      commitShortcutValue(target, shortcutValue);
    };

    document.addEventListener('keydown', _shortcutFieldHandler, true);
  }

  function parseShortcut(shortcutStr) {
    if (!shortcutStr) return null;
    const parts = shortcutStr.toLowerCase().split('+').map(s => s.trim());
    return {
      ctrl: parts.includes('ctrl'),
      alt: parts.includes('alt'),
      shift: parts.includes('shift'),
      meta: parts.includes('meta') || parts.includes('cmd'),
      key: parts.find(p => !['ctrl', 'alt', 'shift', 'meta', 'cmd'].includes(p)) || '',
    };
  }

  function matchesShortcut(parsed, e) {
    if (!parsed || !parsed.key) return false;
    return e.ctrlKey === parsed.ctrl &&
      e.altKey === parsed.alt &&
      e.shiftKey === parsed.shift &&
      e.metaKey === parsed.meta &&
      e.key.toLowerCase() === parsed.key;
  }

  function initShortcuts() {
    if (!state.pasteEnabled || !state.shortcutsEnabled) return;
    _shortcutHandler = (e) => {
      if (!state.enabled || !state.pasteEnabled || !state.shortcutsEnabled) return;
      if (isEditableTarget(e.target)) return;
      const preset = getActivePreset();
      if (!preset) return;
      for (const entry of preset.entries) {
        if (!entry.shortcut) continue;
        const parsed = parseShortcut(entry.shortcut);
        if (matchesShortcut(parsed, e)) {
          e.preventDefault();
          // Route: use direct editor API if available (Udvash page), else old flow
          if (getPageEditor()) {
            injectTextViaEditor(entry.text, 'np-sidebar-status');
          } else {
            runPasteFlow(entry.text, lastMouseX, lastMouseY, 'np-sidebar-status', null, entry.id);
          }
          break;
        }
      }
    };
    document.addEventListener('keydown', _shortcutHandler, true);
  }

  function syncShortcuts() {
    removeShortcuts();
    if (state.enabled && state.pasteEnabled && state.shortcutsEnabled) initShortcuts();
  }

  function removeShortcuts() {
    if (_shortcutHandler) {
      document.removeEventListener('keydown', _shortcutHandler, true);
      _shortcutHandler = null;
    }
  }

  // ══════════════════════════════════════════════════════════════════════
  // REBUILD HELPERS
  // ══════════════════════════════════════════════════════════════════════
  function rebuildAllTextButtons() {
    ['np-sidebar', 'np-float-text'].forEach(prefix => {
      const containerSelector = prefix === 'np-sidebar' ? '#np-sidebar-text-section' : `#${IDs.FLOAT_TEXT_PANEL} .np-float-body`;
      const container = document.querySelector(containerSelector);
      if (!container) return;
      container.innerHTML = buildTextButtonsHTML(prefix);
      bindTextButtons(prefix);
    });
  }

  function rebuildAllNumpadGrids() {
    ['np-sidebar', 'np-float-num'].forEach(prefix => {
      const grid = document.getElementById(`${prefix}-grid`);
      if (!grid) return;
      grid.style.setProperty('--np-cols', state.gridCols);
      const visibleVals = state.buttonValues.filter(v => v && v !== 'NONE');
      grid.innerHTML = visibleVals.map(v => `
        <button class="np-btn" data-value="${escAttr(v)}" aria-label="Insert ${escAttr(v)}"
          style="user-select:none;-webkit-user-select:none;cursor:pointer;">
          <span class="np-btn-label" style="user-select:none;-webkit-user-select:none;pointer-events:none;">${escAttr(v)}</span>
          <span class="np-btn-ripple"></span>
        </button>
      `).join('');
      bindNumpadButtons(prefix);
    });
  }

  function rebuildSidebarContent() {
    const sidebarContent = document.getElementById(IDs.SIDEBAR_CONTENT);
    if (sidebarContent) {
      sidebarContent.innerHTML = buildSidebarHTML();
      attachSidebarListeners();
    }
  }

  function rebuildAll() {
    rebuildSidebarContent();
    if (state.floatingNum) createFloatNumPanel();
    if (state.floatingText && state.pasteEnabled) createFloatTextPanel();
    else document.getElementById(IDs.FLOAT_TEXT_PANEL)?.remove();
  }

  // ══════════════════════════════════════════════════════════════════════
  // SIDEBAR COLLAPSE / SETTINGS
  // ══════════════════════════════════════════════════════════════════════
  function toggleSidebar() {
    if (state.floatingNum) return;
    state.open = !state.open;
    persist();
    const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER);
    const btn = document.getElementById('np-collapse-btn');
    if (wrapper) applySidebarSize(wrapper, state.open ? state.width : 32);
    if (btn) btn.title = state.open ? 'Collapse sidebar' : 'Expand sidebar';
  }

  function toggleSettings(panelId) {
    const panel = document.getElementById(panelId);
    if (!panel) return;
    const isOpen = panel.classList.toggle('np-settings-open');
    state.settingsOpen = isOpen;
    persist();
  }

  // ══════════════════════════════════════════════════════════════════════
  // FLOAT DRAG
  // ══════════════════════════════════════════════════════════════════════
  function initFloatDrag(panel, type) {
    const handleId = type === 'num' ? 'np-float-num-drag-handle' : 'np-float-text-drag-handle';
    const handle = panel.querySelector(`#${handleId}`);
    if (!handle) return;

    const getPos = () => type === 'num' ? { x: state.floatNumX, y: state.floatNumY } : { x: state.floatTextX, y: state.floatTextY };
    const setPos = (x, y) => {
      if (type === 'num') { state.floatNumX = x; state.floatNumY = y; }
      else { state.floatTextX = x; state.floatTextY = y; }
      panel.style.left = x + 'px'; panel.style.top = y + 'px';
    };

    handle.addEventListener('mousedown', (e) => {
      if (e.target.closest('button')) return;
      e.preventDefault();
      const startMX = e.clientX, startMY = e.clientY;
      const { x: startPX, y: startPY } = getPos();
      lockSelect();
      const onMove = (e) => {
        const vw = window.innerWidth, vh = window.innerHeight;
        const w = panel.offsetWidth, h = panel.offsetHeight;
        setPos(Math.max(0, Math.min(vw - w, startPX + (e.clientX - startMX))),
          Math.max(0, Math.min(vh - h, startPY + (e.clientY - startMY))));
      };
      const onUp = () => { unlockSelect(); document.removeEventListener('mousemove', onMove); document.removeEventListener('mouseup', onUp); persist(); };
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });

    handle.addEventListener('touchstart', (e) => {
      if (e.touches.length !== 1) return;
      e.preventDefault();
      const t0 = e.touches[0];
      const startTX = t0.clientX, startTY = t0.clientY;
      const { x: startPX, y: startPY } = getPos();
      const onMove = (e) => {
        const t = e.touches[0];
        const vw = window.innerWidth, vh = window.innerHeight;
        const w = panel.offsetWidth, h = panel.offsetHeight;
        setPos(Math.max(0, Math.min(vw - w, startPX + (t.clientX - startTX))),
          Math.max(0, Math.min(vh - h, startPY + (t.clientY - startTY))));
      };
      const onEnd = () => { handle.removeEventListener('touchmove', onMove); handle.removeEventListener('touchend', onEnd); persist(); };
      handle.addEventListener('touchmove', onMove, { passive: false });
      handle.addEventListener('touchend', onEnd);
    }, { passive: false });
  }

  // ══════════════════════════════════════════════════════════════════════
  // FLOAT RESIZE
  // ══════════════════════════════════════════════════════════════════════
  function initFloatResize(panel, type) {
    const handleId = type === 'num' ? 'np-float-num-resize-bl' : 'np-float-text-resize-bl';
    const handle = panel.querySelector(`#${handleId}`);
    if (!handle) return;

    const getState = () => type === 'num'
      ? { x: state.floatNumX, w: state.floatNumW, h: state.floatNumH }
      : { x: state.floatTextX, w: state.floatTextW, h: state.floatTextH };
    const setState = (x, w, h) => {
      if (type === 'num') { state.floatNumX = x; state.floatNumW = w; state.floatNumH = h; }
      else { state.floatTextX = x; state.floatTextW = w; state.floatTextH = h; }
      panel.style.width = w + 'px'; panel.style.height = h + 'px'; panel.style.left = x + 'px';
    };

    handle.addEventListener('mousedown', (e) => {
      e.preventDefault(); e.stopPropagation();
      const startX = e.clientX, startY = e.clientY;
      const startW = panel.offsetWidth, startH = panel.offsetHeight;
      const { x: startL } = getState();
      lockSelect();
      const onMove = (e) => {
        const dx = e.clientX - startX, dy = e.clientY - startY;
        const newW = Math.max(MIN_FLOAT_W, startW - dx);
        const newH = Math.max(MIN_FLOAT_H, startH + dy);
        setState(Math.round(startL + (startW - newW)), Math.round(newW), Math.round(newH));
      };
      const onUp = () => { unlockSelect(); document.removeEventListener('mousemove', onMove); document.removeEventListener('mouseup', onUp); persist(); };
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });

    handle.addEventListener('touchstart', (e) => {
      if (e.touches.length !== 1) return;
      e.preventDefault(); e.stopPropagation();
      const t0 = e.touches[0];
      const startX = t0.clientX, startY = t0.clientY;
      const startW = panel.offsetWidth, startH = panel.offsetHeight;
      const { x: startL } = getState();
      const onMove = (e) => {
        const t = e.touches[0];
        const dx = t.clientX - startX, dy = t.clientY - startY;
        const newW = Math.max(MIN_FLOAT_W, startW - dx);
        const newH = Math.max(MIN_FLOAT_H, startH + dy);
        setState(Math.round(startL + (startW - newW)), Math.round(newW), Math.round(newH));
      };
      const onEnd = () => { handle.removeEventListener('touchmove', onMove); handle.removeEventListener('touchend', onEnd); persist(); };
      handle.addEventListener('touchmove', onMove, { passive: false });
      handle.addEventListener('touchend', onEnd);
    }, { passive: false });
  }

  // ══════════════════════════════════════════════════════════════════════
  // SIDEBAR RESIZER
  // ══════════════════════════════════════════════════════════════════════
  function initSidebarResizer() {
    const oldResizer = document.getElementById(IDs.RESIZER);
    if (!oldResizer) return;
    const resizer = oldResizer.cloneNode(true);
    oldResizer.parentNode.replaceChild(resizer, oldResizer);

    function startResize(startX, startY, startWidth) {
      lockSelect();
      const dock = state.sidebarDock || 'right';
      const isHoriz = dock === 'top' || dock === 'bottom';
      document.body.style.cursor = isHoriz ? 'ns-resize' : 'ew-resize';

      const onMove = (clientX, clientY) => {
        let newSize;
        if (isHoriz) {
          const delta = dock === 'top' ? startY - clientY : clientY - startY;
          newSize = Math.min(MAX_WIDTH, Math.max(MIN_WIDTH, startWidth + delta));
        } else {
          newSize = Math.min(MAX_WIDTH, Math.max(MIN_WIDTH, startWidth + (startX - clientX)));
        }
        state.width = newSize;
        const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER);
        if (wrapper) applySidebarSize(wrapper, newSize);
      };

      const onMouseMove = (e) => onMove(e.clientX, e.clientY);
      const onTouchMove = (e) => onMove(e.touches[0].clientX, e.touches[0].clientY);
      const onEnd = () => {
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onEnd);
        document.removeEventListener('touchmove', onTouchMove);
        document.removeEventListener('touchend', onEnd);
        unlockSelect();
        document.body.style.cursor = '';
        persist();
      };

      document.addEventListener('mousemove', onMouseMove);
      document.addEventListener('mouseup', onEnd);
      document.addEventListener('touchmove', onTouchMove, { passive: false });
      document.addEventListener('touchend', onEnd);
    }

    resizer.addEventListener('mousedown', (e) => {
      const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER);
      startResize(e.clientX, e.clientY, wrapper?.offsetWidth || DEFAULT_WIDTH);
      e.preventDefault();
    });
    resizer.addEventListener('touchstart', (e) => {
      const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER);
      startResize(e.touches[0].clientX, e.touches[0].clientY, wrapper?.offsetWidth || DEFAULT_WIDTH);
      e.preventDefault();
    }, { passive: false });
  }

  // ══════════════════════════════════════════════════════════════════════
  // UTILITIES
  // ══════════════════════════════════════════════════════════════════════
  function lockSelect() { document.documentElement.style.userSelect = 'none'; document.documentElement.style.webkitUserSelect = 'none'; }
  function unlockSelect() { document.documentElement.style.userSelect = ''; document.documentElement.style.webkitUserSelect = ''; }

  const statusTimers = {};
  function showStatus(statusId, msg, type = 'success') {
    const el = document.getElementById(statusId);
    if (!el) return;
    el.textContent = msg;
    el.className = `np-status np-status-${type} np-status-visible`;
    clearTimeout(statusTimers[statusId]);
    statusTimers[statusId] = setTimeout(() => el.classList.remove('np-status-visible'), 2500);
  }

  function triggerRipple(btn, e) {
    const ripple = btn.querySelector('.np-btn-ripple');
    if (!ripple) return;
    const rect = btn.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = (e?.clientX ?? rect.left + rect.width / 2) - rect.left - size / 2;
    const y = (e?.clientY ?? rect.top + rect.height / 2) - rect.top - size / 2;
    ripple.style.cssText = `width:${size}px;height:${size}px;top:${y}px;left:${x}px;`;
    ripple.classList.remove('np-ripple-active');
    void ripple.offsetWidth;
    ripple.classList.add('np-ripple-active');
  }

  // ══════════════════════════════════════════════════════════════════════
  // SPA WATCHER
  // ══════════════════════════════════════════════════════════════════════
  function watchForLayoutChanges() {
    const observer = new MutationObserver(() => {
      if (!document.getElementById(IDs.LAYOUT_ROOT)) setTimeout(() => inject(), 0);
    });
    observer.observe(document.body, { childList: true, subtree: false });
  }

  // ══════════════════════════════════════════════════════════════════════
  // POPUP MESSAGE
  // ══════════════════════════════════════════════════════════════════════
  if (chrome.runtime?.onMessage) {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg?.action === 'toggle') toggleSidebar();
      if (msg?.action === 'setEnabled') { if (msg.enabled !== state.enabled) toggleEnabled(); }
    });
  }

  // ══════════════════════════════════════════════════════════════════════
  // BOOT
  // ══════════════════════════════════════════════════════════════════════
  function init() {
    autoPopulateUdvashSelectors();
    if (document.body) { inject(); watchForLayoutChanges(); }
    else document.addEventListener('DOMContentLoaded', () => { inject(); watchForLayoutChanges(); });
  }

  loadState(init);

})();

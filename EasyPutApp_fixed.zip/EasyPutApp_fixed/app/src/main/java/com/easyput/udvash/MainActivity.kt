package com.easyput.udvash

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.KeyEvent
import android.webkit.*
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var offlineLayout: LinearLayout
    private lateinit var retryBtn: Button

    private lateinit var btnMenu: Button
    private lateinit var menuPanel: LinearLayout
    private lateinit var btnZoomIn: Button
    private lateinit var btnZoomOut: Button
    private lateinit var btnZoomReset: Button
    private lateinit var tvZoomLevel: TextView
    private lateinit var btnRefresh: Button
    private lateinit var switchExtension: SwitchCompat

    private val zoomLevels = intArrayOf(25, 33, 50, 67, 75, 80, 90, 100, 110, 125, 150, 175, 200, 250, 300)
    private val defaultZoomIndex = 7
    private var currentZoomIndex = defaultZoomIndex
    private var extensionEnabled = true

    // Double-tap suppression
    private var lastTapTime = 0L
    private var lastTapX = 0f
    private var lastTapY = 0f
    private val DOUBLE_TAP_TIMEOUT = 300L
    private val DOUBLE_TAP_SLOP = 60f

    companion object {
        private const val TARGET_URL     = "https://teacher.udvash-unmesh.com/"
        private const val KEY_ZOOM_INDEX = "zoom_index"
        private const val KEY_EXT_ON     = "extension_on"
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView         = findViewById(R.id.webView)
        progressBar     = findViewById(R.id.progressBar)
        offlineLayout   = findViewById(R.id.offlineLayout)
        retryBtn        = findViewById(R.id.retryBtn)
        btnMenu         = findViewById(R.id.btnMenu)
        menuPanel       = findViewById(R.id.menuPanel)
        btnZoomIn       = findViewById(R.id.btnZoomIn)
        btnZoomOut      = findViewById(R.id.btnZoomOut)
        btnZoomReset    = findViewById(R.id.btnZoomReset)
        tvZoomLevel     = findViewById(R.id.tvZoomLevel)
        btnRefresh      = findViewById(R.id.btnRefresh)
        switchExtension = findViewById(R.id.switchExtension)

        savedInstanceState?.let {
            currentZoomIndex = it.getInt(KEY_ZOOM_INDEX, defaultZoomIndex)
            extensionEnabled = it.getBoolean(KEY_EXT_ON, true)
        }
        // Set switch state without triggering the listener yet
        switchExtension.isChecked = extensionEnabled

        setupWebView()
        setupMenu()

        retryBtn.setOnClickListener {
            if (isNetworkAvailable()) {
                offlineLayout.visibility = View.GONE
                webView.visibility       = View.VISIBLE
                webView.reload()
            }
        }

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
            applyZoom()
        } else {
            loadUrl()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
        outState.putInt(KEY_ZOOM_INDEX, currentZoomIndex)
        outState.putBoolean(KEY_EXT_ON, extensionEnabled)
    }

    // ── Menu ──────────────────────────────────────────────────────────────────

    private fun setupMenu() {
        btnMenu.setOnClickListener {
            menuPanel.visibility =
                if (menuPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }

        webView.setOnTouchListener { v, event ->
            if (menuPanel.visibility == View.VISIBLE) menuPanel.visibility = View.GONE
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    val now = SystemClock.uptimeMillis()
                    val dx = event.x - lastTapX
                    val dy = event.y - lastTapY
                    if (now - lastTapTime < DOUBLE_TAP_TIMEOUT &&
                        dx * dx + dy * dy < DOUBLE_TAP_SLOP * DOUBLE_TAP_SLOP) {
                        // Second tap of a double-tap — swallow the entire gesture
                        lastTapTime = 0L
                        return@setOnTouchListener true
                    }
                }
                MotionEvent.ACTION_UP -> {
                    lastTapTime = SystemClock.uptimeMillis()
                    lastTapX = event.x
                    lastTapY = event.y
                }
            }
            v.onTouchEvent(event)
            true
        }

        updateZoomLabel()

        btnZoomOut.setOnClickListener {
            if (currentZoomIndex > 0) { currentZoomIndex--; applyZoom() }
        }
        btnZoomIn.setOnClickListener {
            if (currentZoomIndex < zoomLevels.lastIndex) { currentZoomIndex++; applyZoom() }
        }
        btnZoomReset.setOnClickListener {
            currentZoomIndex = defaultZoomIndex; applyZoom()
        }

        btnRefresh.setOnClickListener {
            menuPanel.visibility = View.GONE
            webView.reload()
        }

        // ── Extension toggle ──────────────────────────────────────────────────
        // Bug fix: the extension JS has a singleton guard `window.__numpadSidebarInjected`.
        // Once set, re-calling the script does nothing. When toggling back ON we must:
        //   1. Clear the flag
        //   2. Remove the stale DOM root
        //   3. Remove the stale CSS style tag (our own guard also blocks re-insert)
        // Then re-inject after a short settle delay.
        switchExtension.setOnCheckedChangeListener { _, isChecked ->
            extensionEnabled = isChecked
            if (isChecked) {
                // Reset all guards so the extension initialises from scratch
                webView.evaluateJavascript("""
                    (function() {
                        window.__numpadSidebarInjected = false;
                        var root = document.getElementById('__numpad_layout_root');
                        if (root) root.remove();
                        var css = document.getElementById('__easyput_css');
                        if (css) css.remove();
                    })();
                """.trimIndent(), null)
                // Wait for DOM removal to settle before re-injecting
                webView.postDelayed({
                    injectCSS(webView)
                    injectExtensionJS(webView)
                }, 80)
            } else {
                removeInjectedContent(webView)
            }
        }
    }

    // ── Zoom ──────────────────────────────────────────────────────────────────

    private fun applyZoom() {
        val pct   = zoomLevels[currentZoomIndex]
        val scale = pct / 100.0
        webView.setInitialScale(pct)
        val js = """
            (function() {
                var meta = document.querySelector('meta[name="viewport"]');
                if (!meta) {
                    meta = document.createElement('meta');
                    meta.name = 'viewport';
                    document.head.appendChild(meta);
                }
                meta.content = 'width=device-width, initial-scale=$scale, maximum-scale=5.0, minimum-scale=0.1';
                var evt = document.createEvent('Event');
                evt.initEvent('resize', true, true);
                window.dispatchEvent(evt);
            })();
        """.trimIndent()
        webView.evaluateJavascript(js, null)
        updateZoomLabel()
    }

    private fun updateZoomLabel() {
        tvZoomLevel.text     = "${zoomLevels[currentZoomIndex]}%"
        btnZoomOut.isEnabled = currentZoomIndex > 0
        btnZoomIn.isEnabled  = currentZoomIndex < zoomLevels.lastIndex
        btnZoomOut.alpha     = if (btnZoomOut.isEnabled) 1f else 0.35f
        btnZoomIn.alpha      = if (btnZoomIn.isEnabled)  1f else 0.35f
    }

    // ── WebView setup ─────────────────────────────────────────────────────────

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled           = true
            domStorageEnabled           = true
            databaseEnabled             = true
            useWideViewPort             = true
            loadWithOverviewMode        = true
            setSupportZoom(true)
            builtInZoomControls         = true
            displayZoomControls         = false
            setSupportMultipleWindows(false)
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess             = false
            allowContentAccess          = false
            cacheMode                   = WebSettings.LOAD_DEFAULT
        }

        // Allow both vertical and horizontal scrolling
        webView.isVerticalScrollBarEnabled = true
        webView.isHorizontalScrollBarEnabled = true
        webView.overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }

        webView.addJavascriptInterface(AndroidStorageBridge(this), "AndroidStorage")

        webView.webViewClient = object : WebViewClient() {

            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                progressBar.visibility = View.VISIBLE
                progressBar.progress   = 0
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                progressBar.visibility = View.GONE
                applyZoom()
                if (extensionEnabled) {
                    injectCSS(view)
                    injectExtensionJS(view)
                }
                CookieManager.getInstance().flush()
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                super.onReceivedError(view, request, error)
                if (request.isForMainFrame) {
                    progressBar.visibility = View.GONE
                    if (!isNetworkAvailable()) {
                        webView.visibility       = View.GONE
                        offlineLayout.visibility = View.VISIBLE
                    }
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                return if (url.contains("udvash-unmesh.com") || url.contains("udvash.com")) {
                    false
                } else {
                    try { startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))) }
                    catch (_: Exception) {}
                    true
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progressBar.progress = newProgress
                if (newProgress == 100) progressBar.visibility = View.GONE
            }
            override fun onJsAlert(view: WebView, url: String, message: String, result: JsResult): Boolean { result.confirm(); return true }
            override fun onJsConfirm(view: WebView, url: String, message: String, result: JsResult): Boolean { result.cancel(); return true }
        }
    }

    private fun loadUrl() {
        if (isNetworkAvailable()) webView.loadUrl(TARGET_URL)
        else { webView.visibility = View.GONE; offlineLayout.visibility = View.VISIBLE }
    }

    // ── Extension helpers ─────────────────────────────────────────────────────

    private fun injectCSS(view: WebView) {
        val css = ExtensionAssets.SIDEBAR_CSS
            .replace("\\", "\\\\").replace("'", "\\'")
            .replace("\n", "\\n").replace("\r", "")
        val js = """
            (function() {
                var old = document.getElementById('__easyput_css');
                if (old) old.remove();
                var s = document.createElement('style');
                s.id = '__easyput_css';
                s.textContent = '$css';
                document.head.appendChild(s);
            })();
        """.trimIndent()
        view.evaluateJavascript(js, null)
    }

    private fun injectExtensionJS(view: WebView) {
        view.evaluateJavascript(ExtensionAssets.ADAPTED_CONTENT_JS, null)
    }

    private fun removeInjectedContent(view: WebView) {
        view.evaluateJavascript("""
            (function() {
                var s = document.getElementById('__easyput_css'); if (s) s.remove();
                var r = document.getElementById('__numpad_layout_root'); if (r) r.remove();
                var b = document.getElementById('easyput-toggle-btn'); if (b) b.remove();
            })();
        """.trimIndent(), null)
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun isNetworkAvailable(): Boolean {
        val cm   = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net  = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            menuPanel.visibility == View.VISIBLE -> menuPanel.visibility = View.GONE
            webView.canGoBack()                  -> webView.goBack()
            else                                 -> super.onBackPressed()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            when {
                menuPanel.visibility == View.VISIBLE -> { menuPanel.visibility = View.GONE; return true }
                webView.canGoBack()                  -> { webView.goBack();                 return true }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onResume()  { super.onResume();  webView.onResume() }
    override fun onPause()   { super.onPause();   webView.onPause(); CookieManager.getInstance().flush() }
    override fun onDestroy() { webView.stopLoading(); webView.destroy(); super.onDestroy() }
}

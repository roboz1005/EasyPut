package com.easyput.udvash

import android.content.Context
import android.webkit.JavascriptInterface

/**
 * AndroidStorageBridge
 *
 * Injected into WebView as "AndroidStorage".
 * Replaces chrome.storage.local with Android SharedPreferences,
 * allowing the EasyPut extension to persist state between app restarts.
 *
 * JS calls:
 *   AndroidStorage.save(key, jsonValue)
 *   AndroidStorage.load(key)              → returns JSON string or ""
 *   AndroidStorage.remove(key)
 *   AndroidStorage.getAllKeys()           → returns JSON array string
 */
class AndroidStorageBridge(private val context: Context) {

    companion object {
        private const val PREFS_NAME = "EasyPutExtensionState"
    }

    private val prefs by lazy {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    @JavascriptInterface
    fun save(key: String, value: String) {
        prefs.edit().putString(key, value).apply()
    }

    @JavascriptInterface
    fun load(key: String): String {
        return prefs.getString(key, "") ?: ""
    }

    @JavascriptInterface
    fun remove(key: String) {
        prefs.edit().remove(key).apply()
    }

    @JavascriptInterface
    fun getAllKeys(): String {
        val keys = prefs.all.keys.filter { it.isNotEmpty() }
        return "[${keys.joinToString(",") { "\"$it\"" }}]"
    }
}

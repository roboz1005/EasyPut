package com.easyput.udvash

/**
 * ExtensionAssets
 *
 * Contains the full EasyPut extension assets adapted for Android WebView injection:
 *   - SIDEBAR_CSS: the original sidebar.css verbatim
 *   - ADAPTED_CONTENT_JS: content.js with chrome.storage.local replaced by
 *     AndroidStorage Java bridge calls, and chrome.runtime removed.
 */
object ExtensionAssets {

    // ──────────────────────────────────────────────────────────────────────────
    // SIDEBAR CSS (verbatim from sidebar.css)
    // ──────────────────────────────────────────────────────────────────────────
    val SIDEBAR_CSS: String = """
/* EasyPut NumPad — sidebar.css v2 */
:root {
  --np-bg: #1a1b1e;
  --np-surface: #25262b;
  --np-surface2: #2c2d33;
  --np-border: #373a40;
  --np-accent: #4dabf7;
  --np-accent-dim: #1c3e5a;
  --np-accent-glow: rgba(77, 171, 247, 0.25);
  --np-text: #e8eaed;
  --np-text-muted: #868e96;
  --np-input-text: #ffffff;
  --np-success: #51cf66;
  --np-warn: #ffd43b;
  --np-error: #ff6b6b;
  --np-radius: 10px;
  --np-shadow: -6px 0 28px rgba(0, 0, 0, 0.55);
  --np-font: 'Menlo', 'Monaco', 'Consolas', 'SF Mono', monospace;
  --np-transition: 0.28s cubic-bezier(0.4, 0, 0.2, 1);
}
#__numpad_sidebar_wrapper { position: relative !important; }
#__numpad_sidebar_content {
  display: flex !important; flex-direction: column !important;
  width: 100% !important; height: 100% !important;
  font-family: var(--np-font) !important; font-size: 12px !important;
  color: var(--np-text) !important; overflow: hidden !important;
  box-sizing: border-box !important;
}
#__numpad_sidebar_content input, #__numpad_sidebar_content select,
#__numpad_float_panel input, #__numpad_float_panel select {
  color: var(--np-input-text) !important;
  -webkit-text-fill-color: var(--np-input-text) !important;
  background-color: var(--np-bg) !important;
  border-color: var(--np-border) !important;
  font-family: var(--np-font) !important;
}
#__numpad_sidebar_resizer {
  position: absolute !important; top: 0 !important; left: 0 !important;
  width: 6px !important; height: 100% !important; cursor: ew-resize !important;
  z-index: 1000 !important; background: transparent !important;
  transition: background 0.15s !important; touch-action: none !important;
}
#__numpad_sidebar_resizer:hover, #__numpad_sidebar_resizer:active {
  background: linear-gradient(to right, var(--np-accent-dim), transparent) !important;
}
#__numpad_sidebar_resizer::before {
  content: '' !important; position: absolute !important; left: 2px !important;
  top: 50% !important; transform: translateY(-50%) !important;
  width: 2px !important; height: 40px !important; border-radius: 2px !important;
  background: var(--np-border) !important; transition: background 0.15s, height 0.15s !important;
}
#__numpad_sidebar_resizer:hover::before { background: var(--np-accent) !important; height: 60px !important; }
.np-header {
  display: flex !important; align-items: center !important;
  justify-content: flex-start !important; padding: 0 10px 0 5px !important;
  height: 46px !important; min-height: 46px !important;
  background: var(--np-surface) !important;
  border-bottom: 1.5px solid var(--np-border) !important;
  flex-shrink: 0 !important; user-select: none !important; -webkit-user-select: none !important;
}
.np-header-left { display: flex !important; align-items: center !important; gap: 8px !important; }
.np-logo { font-size: 16px !important; line-height: 1 !important; filter: grayscale(0.3) !important; }
.np-title {
  font-size: 11px !important; font-weight: 700 !important; letter-spacing: 0.12em !important;
  text-transform: uppercase !important; color: var(--np-text) !important;
}
.np-header-actions { display: flex !important; align-items: center !important; gap: 2px !important; margin-left: auto !important; }
.np-power-toggle {
  display: flex !important; align-items: center !important; gap: 5px !important;
  cursor: pointer !important; padding: 3px 7px !important; border-radius: 20px !important;
  border: 1.5px solid var(--np-border) !important; background: transparent !important;
  color: var(--np-text-muted) !important; font-family: var(--np-font) !important;
  font-size: 9px !important; font-weight: 700 !important; letter-spacing: 0.1em !important;
  text-transform: uppercase !important; transition: all 0.2s !important;
  user-select: none !important; -webkit-user-select: none !important; outline: none !important; min-height: 26px !important;
}
.np-power-toggle.np-on { border-color: var(--np-success) !important; color: var(--np-success) !important; background: rgba(81,207,102,0.08) !important; }
.np-power-toggle.np-off { border-color: var(--np-error) !important; color: var(--np-error) !important; background: rgba(255,107,107,0.08) !important; }
.np-power-dot { width: 6px !important; height: 6px !important; border-radius: 50% !important; background: currentColor !important; flex-shrink: 0 !important; }
.np-icon-btn {
  display: flex !important; align-items: center !important; justify-content: center !important;
  width: 32px !important; height: 32px !important; border: none !important;
  background: transparent !important; border-radius: 6px !important; cursor: pointer !important;
  color: var(--np-text-muted) !important; transition: background 0.15s, color 0.15s !important;
  padding: 0 !important; outline: none !important; user-select: none !important;
  -webkit-user-select: none !important; touch-action: manipulation !important;
  -webkit-tap-highlight-color: transparent !important;
}
.np-icon-btn:hover { background: var(--np-surface2) !important; color: var(--np-text) !important; }
.np-icon-btn:active { background: var(--np-accent-dim) !important; color: var(--np-accent) !important; }
.np-chevron { transition: transform var(--np-transition) !important; }
.np-settings-panel {
  max-height: 0 !important; overflow: hidden !important;
  transition: max-height 0.35s cubic-bezier(0.4,0,0.2,1) !important;
  background: var(--np-surface) !important;
  border-bottom: 1.5px solid var(--np-border) !important; flex-shrink: 0 !important;
}
.np-settings-panel.np-settings-open { max-height: 520px !important; overflow-y: auto !important; }
.np-tabs {
  display: flex !important; border-bottom: 1.5px solid var(--np-border) !important;
  background: var(--np-bg) !important; flex-shrink: 0 !important;
  position: sticky !important; top: 0 !important; z-index: 2 !important;
}
.np-tab {
  flex: 1 !important; padding: 8px 4px !important; font-family: var(--np-font) !important;
  font-size: 9px !important; font-weight: 700 !important; letter-spacing: 0.08em !important;
  text-transform: uppercase !important; color: var(--np-text-muted) !important;
  background: transparent !important; border: none !important; cursor: pointer !important;
  transition: color 0.15s, border-bottom 0.15s !important; border-bottom: 2px solid transparent !important;
  outline: none !important; user-select: none !important; -webkit-user-select: none !important;
  touch-action: manipulation !important; -webkit-tap-highlight-color: transparent !important;
}
.np-tab.np-tab-active { color: var(--np-accent) !important; border-bottom-color: var(--np-accent) !important; }
.np-tab-content { display: none !important; padding: 14px !important; flex-direction: column !important; gap: 8px !important; }
.np-tab-content.np-tab-visible { display: flex !important; }
.np-settings-label { margin: 0 0 2px !important; font-size: 10px !important; font-weight: 700 !important; letter-spacing: 0.06em !important; text-transform: uppercase !important; color: var(--np-accent) !important; }
.np-selector-row { display: flex !important; align-items: center !important; gap: 6px !important; }
.np-settings-input {
  flex: 1 !important; min-width: 0 !important; background: var(--np-bg) !important;
  border: 1.5px solid var(--np-border) !important; border-radius: 8px !important;
  padding: 8px 11px !important; font-family: var(--np-font) !important; font-size: 11px !important;
  color: var(--np-input-text) !important; -webkit-text-fill-color: var(--np-input-text) !important;
  outline: none !important; box-sizing: border-box !important;
  transition: border-color 0.18s, box-shadow 0.18s !important; width: 100% !important; caret-color: var(--np-accent) !important;
}
.np-settings-input:focus { border-color: var(--np-accent) !important; box-shadow: 0 0 0 2px var(--np-accent-glow) !important; }
.np-settings-input::placeholder { color: var(--np-text-muted) !important; -webkit-text-fill-color: var(--np-text-muted) !important; opacity: 0.55 !important; }
.np-selector-preview { font-size: 9.5px !important; color: var(--np-text-muted) !important; background: var(--np-bg) !important; border-radius: 4px !important; padding: 4px 8px !important; word-break: break-all !important; min-height: 20px !important; opacity: 0.8 !important; line-height: 1.4 !important; }
.np-save-btn {
  margin-top: 4px !important; padding: 9px 16px !important; background: var(--np-accent) !important;
  color: #111 !important; border: none !important; border-radius: 6px !important;
  font-family: var(--np-font) !important; font-size: 11px !important; font-weight: 700 !important;
  letter-spacing: 0.06em !important; cursor: pointer !important;
  transition: opacity 0.15s, transform 0.1s !important; align-self: stretch !important;
  outline: none !important; user-select: none !important; -webkit-user-select: none !important;
  touch-action: manipulation !important; -webkit-tap-highlight-color: transparent !important; min-height: 38px !important;
}
.np-save-btn:hover { opacity: 0.88 !important; }
.np-save-btn:active { transform: scale(0.97) !important; }
.np-settings-hint { margin-top: 2px !important; font-size: 10px !important; color: var(--np-text-muted) !important; line-height: 1.5 !important; opacity: 0.7 !important; }
.np-btn-editor-grid { display: grid !important; grid-template-columns: repeat(3,1fr) !important; gap: 6px !important; }
.np-btn-slot { display: flex !important; flex-direction: column !important; gap: 3px !important; }
.np-btn-slot-label { font-size: 9px !important; color: var(--np-text-muted) !important; text-align: center !important; user-select: none !important; }
.np-btn-slot-input {
  background: var(--np-bg) !important; border: 1.5px solid var(--np-border) !important;
  border-radius: 8px !important; padding: 6px 4px !important; font-family: var(--np-font) !important;
  font-size: 13px !important; font-weight: 600 !important; color: var(--np-input-text) !important;
  -webkit-text-fill-color: var(--np-input-text) !important; caret-color: var(--np-accent) !important;
  outline: none !important; text-align: center !important; box-sizing: border-box !important;
  width: 100% !important; transition: border-color 0.18s, box-shadow 0.18s !important;
}
.np-btn-slot-input:focus { border-color: var(--np-accent) !important; box-shadow: 0 0 0 2px var(--np-accent-glow) !important; }
.np-grid-controls { display: grid !important; grid-template-columns: 1fr 1fr !important; gap: 8px !important; }
.np-grid-ctrl-group { display: flex !important; flex-direction: column !important; gap: 4px !important; }
.np-number-input {
  background: var(--np-bg) !important; border: 1.5px solid var(--np-border) !important;
  border-radius: 8px !important; padding: 7px 10px !important; font-family: var(--np-font) !important;
  font-size: 13px !important; font-weight: 600 !important; color: var(--np-input-text) !important;
  -webkit-text-fill-color: var(--np-input-text) !important; caret-color: var(--np-accent) !important;
  outline: none !important; text-align: center !important; box-sizing: border-box !important;
  width: 100% !important; transition: border-color 0.18s, box-shadow 0.18s !important;
}
.np-number-input:focus { border-color: var(--np-accent) !important; box-shadow: 0 0 0 2px var(--np-accent-glow) !important; }
.np-pad-area { display: flex !important; flex-direction: column !important; padding: 16px 14px 14px !important; overflow: hidden !important; gap: 12px !important; align-items: flex-start !important; flex: 1 !important; overflow-y: auto !important; }
.np-grid { display: grid !important; grid-template-columns: repeat(var(--np-cols,3),1fr) !important; gap: 10px !important; width: 100% !important; }
.np-btn {
  position: relative !important; overflow: hidden !important; display: flex !important;
  align-items: center !important; justify-content: center !important; aspect-ratio: 1 !important;
  background: var(--np-surface) !important; border: 1.5px solid var(--np-border) !important;
  border-radius: var(--np-radius) !important; cursor: pointer !important;
  color: var(--np-input-text) !important; font-family: var(--np-font) !important;
  font-size: 18px !important; font-weight: 600 !important;
  transition: background var(--np-transition), border-color var(--np-transition), transform 0.1s, box-shadow var(--np-transition) !important;
  outline: none !important; padding: 0 !important; min-height: 0 !important; min-width: 0 !important;
  letter-spacing: -0.02em !important; user-select: none !important; -webkit-user-select: none !important;
  touch-action: manipulation !important; -webkit-tap-highlight-color: transparent !important;
}
.np-btn:hover { background: var(--np-surface2) !important; border-color: var(--np-accent) !important; box-shadow: 0 0 12px var(--np-accent-glow) !important; transform: translateY(-1px) !important; }
.np-btn:active { transform: scale(0.94) translateY(0) !important; background: var(--np-accent-dim) !important; border-color: var(--np-accent) !important; }
.np-btn-label { position: relative !important; z-index: 2 !important; color: var(--np-input-text) !important; user-select: none !important; -webkit-user-select: none !important; pointer-events: none !important; font-size: clamp(11px,3.5vw,20px) !important; }
.np-btn-ripple { position: absolute !important; border-radius: 50% !important; background: rgba(77,171,247,0.3) !important; transform: scale(0) !important; pointer-events: none !important; z-index: 1 !important; }
.np-btn-ripple.np-ripple-active { animation: np-ripple-anim 0.5s linear forwards !important; }
@keyframes np-ripple-anim { to { transform: scale(2.8) !important; opacity: 0 !important; } }
.np-status {
  height: 28px !important; display: flex !important; align-items: center !important;
  justify-content: center !important; border-radius: 6px !important; font-size: 10.5px !important;
  font-weight: 500 !important; letter-spacing: 0.04em !important; padding: 0 12px !important;
  opacity: 0 !important; transform: translateY(4px) !important;
  transition: opacity 0.2s, transform 0.2s !important; flex-shrink: 0 !important;
  background: var(--np-surface2) !important; border: 1px solid var(--np-border) !important;
  color: var(--np-text-muted) !important; width: 100% !important; box-sizing: border-box !important; user-select: none !important;
}
.np-status.np-status-visible { opacity: 1 !important; transform: translateY(0) !important; }
.np-status.np-status-success { color: var(--np-success) !important; border-color: rgba(81,207,102,0.3) !important; background: rgba(81,207,102,0.08) !important; }
.np-status.np-status-warn { color: var(--np-warn) !important; border-color: rgba(255,212,59,0.3) !important; background: rgba(255,212,59,0.07) !important; }
.np-status.np-status-error { color: var(--np-error) !important; border-color: rgba(255,107,107,0.3) !important; background: rgba(255,107,107,0.07) !important; }
#__numpad_float_panel {
  position: fixed !important; z-index: 2147483647 !important;
  background: var(--np-bg,#1a1b1e) !important; border: 1.5px solid var(--np-border,#373a40) !important;
  border-radius: 12px !important; box-shadow: 0 8px 40px rgba(0,0,0,0.72),0 2px 8px rgba(0,0,0,0.4) !important;
  display: flex !important; flex-direction: column !important; overflow: visible !important;
  box-sizing: border-box !important; font-family: var(--np-font) !important; font-size: 12px !important;
  color: var(--np-text,#e8eaed) !important; user-select: none !important; -webkit-user-select: none !important;
  min-width: 200px !important; min-height: 260px !important;
}
#__numpad_float_panel .np-float-titlebar {
  display: flex !important; align-items: center !important; justify-content: space-between !important;
  padding: 0 10px 0 6px !important; height: 40px !important; min-height: 40px !important;
  background: var(--np-surface) !important; border-bottom: 1.5px solid var(--np-border) !important;
  border-radius: 11px 11px 0 0 !important; flex-shrink: 0 !important; cursor: default !important;
}
#__numpad_float_panel .np-drag-handle {
  display: flex !important; align-items: center !important; justify-content: center !important;
  width: 34px !important; height: 34px !important; cursor: grab !important;
  color: var(--np-text-muted) !important; border-radius: 6px !important;
  transition: background 0.15s, color 0.15s !important; flex-shrink: 0 !important; touch-action: none !important;
}
#__numpad_float_panel .np-drag-handle:active { cursor: grabbing !important; background: var(--np-surface2) !important; color: var(--np-accent) !important; }
#__numpad_float_panel .np-float-title-center { display: flex !important; align-items: center !important; gap: 6px !important; flex: 1 !important; pointer-events: none !important; }
#__numpad_float_panel .np-float-logo { font-size: 14px !important; }
#__numpad_float_panel .np-float-label { font-size: 10px !important; font-weight: 700 !important; letter-spacing: 0.12em !important; text-transform: uppercase !important; color: var(--np-text) !important; }
#__numpad_float_panel .np-float-actions { display: flex !important; align-items: center !important; gap: 2px !important; cursor: default !important; }
#__numpad_float_panel .np-float-body { padding: 12px 12px 10px !important; display: flex !important; flex-direction: column !important; gap: 10px !important; flex: 1 !important; overflow: hidden !important; box-sizing: border-box !important; }
#__numpad_float_panel .np-settings-panel { border-radius: 0 !important; flex-shrink: 0 !important; }
#__numpad_float_panel .np-settings-panel.np-settings-open { max-height: 400px !important; }
#__numpad_float_panel .np-resize-handle-bl {
  position: absolute !important; bottom: -1px !important; left: -1px !important;
  width: 22px !important; height: 22px !important; cursor: sw-resize !important; z-index: 10 !important;
  border-radius: 0 0 0 12px !important; display: flex !important; align-items: flex-end !important;
  justify-content: flex-start !important; padding: 4px !important; box-sizing: border-box !important; touch-action: none !important;
}
.np-selector-input-row { display: flex !important; gap: 4px !important; align-items: center !important; width: 100% !important; }
.np-selector-input-row .np-settings-input { flex: 1 !important; min-width: 0 !important; }
.np-pick-element-btn {
  flex-shrink: 0 !important; width: 28px !important; height: 28px !important; border-radius: 5px !important;
  border: 1px solid var(--np-border) !important; background: var(--np-surface2) !important;
  color: var(--np-text-muted) !important; cursor: pointer !important; display: flex !important;
  align-items: center !important; justify-content: center !important;
  transition: background 0.15s, color 0.15s, border-color 0.15s !important;
}
.np-pick-element-btn:hover { background: var(--np-accent) !important; color: #111 !important; border-color: var(--np-accent) !important; }
#__numpad_sidebar_wrapper ::-webkit-scrollbar { width: 4px !important; }
#__numpad_sidebar_wrapper ::-webkit-scrollbar-track { background: transparent !important; }
#__numpad_sidebar_wrapper ::-webkit-scrollbar-thumb { background: var(--np-border) !important; border-radius: 4px !important; }
#__numpad_float_panel ::-webkit-scrollbar { width: 4px !important; }
#__numpad_float_panel ::-webkit-scrollbar-thumb { background: var(--np-border) !important; border-radius: 4px !important; }
#np-floating-placeholder { user-select: none !important; -webkit-user-select: none !important; }
.np-sel-group { display: flex !important; flex-direction: column !important; gap: 6px !important; background: var(--np-surface2) !important; border: 1.5px solid var(--np-border) !important; border-radius: 9px !important; padding: 10px !important; }
.np-sel-dropdown {
  flex: 1 !important; min-width: 0 !important; background: var(--np-bg) !important;
  border: 1.5px solid var(--np-border) !important; border-radius: 8px !important;
  padding: 7px 10px !important; font-family: var(--np-font) !important; font-size: 11px !important;
  color: var(--np-input-text) !important; -webkit-text-fill-color: var(--np-input-text) !important;
  outline: none !important; box-sizing: border-box !important; cursor: pointer !important;
  appearance: none !important; -webkit-appearance: none !important;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'%3E%3Cpath d='M0 0l5 6 5-6z' fill='%23868e96'/%3E%3C/svg%3E") !important;
  background-repeat: no-repeat !important; background-position: right 9px center !important; padding-right: 26px !important;
}
.np-sel-dropdown:focus { border-color: var(--np-accent) !important; box-shadow: 0 0 0 2px var(--np-accent-glow) !important; }
.np-sel-dropdown option { background: var(--np-surface) !important; color: var(--np-text) !important; }
.np-preset-edit-row { display: flex !important; flex-direction: column !important; gap: 6px !important; padding: 10px !important; background: var(--np-bg) !important; border-radius: 8px !important; border: 1.5px solid var(--np-accent-dim) !important; }
.np-preset-actions { display: flex !important; align-items: center !important; gap: 6px !important; margin-top: 2px !important; }
.np-preset-save-btn { flex: 1 !important; padding: 5px 10px !important; font-size: 10px !important; }
.np-preset-del-btn { width: 28px !important; height: 28px !important; flex-shrink: 0 !important; }
.np-dock-grid { display: grid !important; grid-template-columns: 1fr 1fr !important; gap: 7px !important; }
.np-dock-btn {
  padding: 8px 4px !important; background: var(--np-surface2) !important;
  border: 1.5px solid var(--np-border) !important; border-radius: 7px !important;
  color: var(--np-text-muted) !important; font-family: var(--np-font) !important; font-size: 10px !important;
  font-weight: 700 !important; letter-spacing: 0.08em !important; text-transform: uppercase !important;
  cursor: pointer !important; transition: all 0.15s !important; outline: none !important; touch-action: manipulation !important;
}
.np-dock-btn:hover { border-color: var(--np-accent) !important; color: var(--np-text) !important; }
.np-dock-btn.np-dock-active { background: var(--np-accent-dim) !important; border-color: var(--np-accent) !important; color: var(--np-accent) !important; }
#__numpad_sidebar_content { overflow-y: auto !important; overflow-x: hidden !important; }
""".trimIndent()

    // ──────────────────────────────────────────────────────────────────────────
    // ADAPTED CONTENT JS
    //
    // Changes from original content.js:
    //   1. chrome.storage.local.set/get  →  AndroidStorage.save/load bridge
    //   2. chrome.runtime.onMessage      →  removed (not needed in app)
    //   3. Element picker uses touchstart for mobile compatibility
    //   4. Touch events added on drag/resize handles (already in original)
    //   5. Storage calls are now synchronous via the Java bridge (no callbacks needed)
    // ──────────────────────────────────────────────────────────────────────────
    val ADAPTED_CONTENT_JS: String = """
(function () {
  'use strict';

  // Guard against double-injection
  if (window.__numpadSidebarInjected) return;
  window.__numpadSidebarInjected = true;

  const IDs = {
    LAYOUT_ROOT: '__numpad_layout_root',
    PAGE_CONTAINER: '__numpad_page_container',
    SIDEBAR_WRAPPER: '__numpad_sidebar_wrapper',
    SIDEBAR_CONTENT: '__numpad_sidebar_content',
    RESIZER: '__numpad_sidebar_resizer',
    LAYOUT_STYLES: '__numpad_layout_styles',
    FLOAT_PANEL: '__numpad_float_panel',
    FLOAT_STYLES: '__numpad_float_styles',
  };

  const STORAGE_KEY = 'numpadSidebarStateV2';
  const DEFAULT_WIDTH = 280;
  const MIN_WIDTH = 200;
  const MAX_WIDTH = 480;
  const MIN_FLOAT_W = 200;
  const MIN_FLOAT_H = 260;
  const DEFAULT_BUTTONS = ['7','8','9','4','5','6','1','2','3','0','10','NONE'];
  const DEFAULT_COLS = 3;
  const DEFAULT_ROWS = 4;

  let state = {
    enabled: true, open: true, width: DEFAULT_WIDTH,
    inputSelector: '', submitSelector: '', settingsOpen: false, activeTab: 'selector',
    floating: false, floatX: 80, floatY: 80, floatW: 0, floatH: 0,
    buttonValues: [...DEFAULT_BUTTONS], gridCols: DEFAULT_COLS, gridRows: DEFAULT_ROWS,
    inputPresets: [], submitPresets: [], inputPresetId: '', submitPresetId: '',
    sidebarDock: 'right',
  };

  // ── STORAGE: AndroidStorage bridge replaces chrome.storage.local ──────────
  function persist() {
    try {
      if (window.AndroidStorage) {
        AndroidStorage.save(STORAGE_KEY, JSON.stringify(state));
      }
    } catch(e) {}
  }

  function loadState(cb) {
    try {
      if (window.AndroidStorage) {
        var raw = AndroidStorage.load(STORAGE_KEY);
        if (raw && raw.length > 0) {
          var saved = JSON.parse(raw);
          if (!saved.buttonValues) saved.buttonValues = [...DEFAULT_BUTTONS];
          if (!saved.gridCols) saved.gridCols = DEFAULT_COLS;
          if (!saved.gridRows) saved.gridRows = DEFAULT_ROWS;
          if (saved.enabled === undefined) saved.enabled = true;
          if (saved.selectorPresets && !saved.inputPresets) {
            saved.inputPresets = [...saved.selectorPresets];
            saved.submitPresets = [...saved.selectorPresets];
            delete saved.selectorPresets;
          }
          if (!saved.inputPresets) saved.inputPresets = [];
          if (!saved.submitPresets) saved.submitPresets = [];
          if (!saved.inputPresetId) saved.inputPresetId = '';
          if (!saved.submitPresetId) saved.submitPresetId = '';
          if (!saved.sidebarDock) saved.sidebarDock = 'right';
          Object.assign(state, saved);
          state.enabled = true;
        }
      }
    } catch(e) {}
    cb();
  }

  // ── SELECTOR CAPTURE ──────────────────────────────────────────────────────
  function escapeCssAttributeValue(value) {
    return String(value).replace(/\\\\/g, '\\\\\\\\').replace(/"/g, '\\\\"');
  }
  function isUniqueSelector(selector) {
    if (!selector) return false;
    try { return document.querySelectorAll(selector).length === 1; } catch { return false; }
  }
  function buildAttributeSelector(el, attrName) {
    const rawValue = el.getAttribute(attrName);
    if (!rawValue) return '';
    const selector = el.tagName.toLowerCase() + '[' + attrName + '="' + escapeCssAttributeValue(rawValue) + '"]';
    return isUniqueSelector(selector) ? selector : '';
  }
  function buildCssPathSelector(el) {
    const parts = [];
    let current = el;
    while (current && current.nodeType === Node.ELEMENT_NODE) {
      if (current === document.documentElement) { parts.unshift('html'); break; }
      if (current === document.body) { parts.unshift('body'); break; }
      if (current.id) { parts.unshift('#' + CSS.escape(current.id)); break; }
      let segment = current.tagName.toLowerCase();
      const safeClasses = Array.from(current.classList || [])
        .filter(c => !/^(active|hover|focus|disabled|ng-|v-|js-)/.test(c))
        .slice(0, 3).map(c => '.' + CSS.escape(c)).join('');
      if (safeClasses) segment += safeClasses;
      const siblings = current.parentElement
        ? Array.from(current.parentElement.children).filter(child => child.tagName === current.tagName)
        : [];
      if (siblings.length > 1) segment += ':nth-of-type(' + (siblings.indexOf(current) + 1) + ')';
      parts.unshift(segment);
      current = current.parentElement;
    }
    const selector = parts.join(' > ');
    return selector && isUniqueSelector(selector) ? selector : '';
  }
  function generateSelector(el) {
    if (!el || el.nodeType !== Node.ELEMENT_NODE || el === document.body) return '';
    if (el.id) return el.tagName.toLowerCase() + '#' + CSS.escape(el.id);
    const nameSelector = buildAttributeSelector(el, 'name');
    if (nameSelector) return nameSelector;
    for (const attr of Array.from(el.attributes || [])) {
      if (attr.name.startsWith('data-') && attr.value) {
        const selector = buildAttributeSelector(el, attr.name);
        if (selector) return selector;
      }
    }
    const cssSelector = buildCssPathSelector(el);
    if (cssSelector) return cssSelector;
    return '';
  }

  // ── STYLES ────────────────────────────────────────────────────────────────
  function applyLayoutStyles() {
    let el = document.getElementById(IDs.LAYOUT_STYLES);
    if (!el) { el = document.createElement('style'); el.id = IDs.LAYOUT_STYLES; document.head.appendChild(el); }
    const dock = state.sidebarDock || 'right';
    const isHoriz = dock === 'top' || dock === 'bottom';
    const flexDirMap = { right: 'row', left: 'row-reverse', bottom: 'column', top: 'column-reverse' };
    const flexDir = flexDirMap[dock];
    const borderSide = { left: 'border-right', right: 'border-left', top: 'border-bottom', bottom: 'border-top' }[dock];
    const shadowMap = { left: '6px 0 28px', right: '-6px 0 28px', top: '0 6px 28px', bottom: '0 -6px 28px' };
    const shadowDir = shadowMap[dock];
    const resizerCSS = isHoriz
      ? 'width:100%!important;height:6px!important;cursor:ns-resize!important;left:0!important;right:0!important;' + (dock==='top'?'bottom:0!important;top:auto!important;':'top:0!important;bottom:auto!important;')
      : 'height:100%!important;width:6px!important;cursor:ew-resize!important;top:0!important;bottom:0!important;' + (dock==='right'?'left:0!important;right:auto!important;':'right:0!important;left:auto!important;');
    const sidebarStructural = isHoriz ? 'width:100%!important;' : 'height:100%!important;';
    el.textContent = [
      'html{width:100%!important;height:100%!important;margin:0!important;padding:0!important;overflow:hidden!important;}',
      'body{margin:0!important;padding:0!important;width:100%!important;height:100%!important;overflow:hidden!important;}',
      '#'+IDs.LAYOUT_ROOT+'{display:flex!important;flex-direction:'+flexDir+'!important;width:100vw!important;height:100vh!important;position:fixed!important;top:0!important;left:0!important;right:0!important;bottom:0!important;z-index:2147483646!important;box-sizing:border-box!important;}',
      '#'+IDs.PAGE_CONTAINER+'{flex:1!important;min-width:0!important;min-height:0!important;overflow:auto!important;display:flex!important;flex-direction:column!important;position:relative!important;background:inherit!important;}',
      '#'+IDs.SIDEBAR_WRAPPER+'{flex-shrink:0!important;display:flex!important;flex-direction:column!important;position:relative!important;background:var(--np-bg,#1a1b1e)!important;'+borderSide+':1.5px solid var(--np-border,#373a40)!important;box-shadow:'+shadowDir+' rgba(0,0,0,0.55)!important;overflow:hidden!important;z-index:2147483647!important;transition:width 0.28s cubic-bezier(0.4,0,0.2,1),height 0.28s cubic-bezier(0.4,0,0.2,1)!important;box-sizing:border-box!important;'+sidebarStructural+'}',
      '#'+IDs.SIDEBAR_CONTENT+'{display:flex!important;flex-direction:column!important;width:100%!important;height:100%!important;overflow-y:auto!important;overflow-x:hidden!important;}',
      '#'+IDs.RESIZER+'{position:absolute!important;'+resizerCSS+'background:transparent!important;transition:background 0.15s!important;touch-action:none!important;z-index:1000!important;}',
    ].join('');
  }

  // ── HTML BUILDERS ─────────────────────────────────────────────────────────
  function escAttr(s) {
    return (s||'').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }
  function buildNumpadGridHTML(prefix) {
    const visibleVals = state.buttonValues.filter(v => v && v !== 'NONE');
    const btnHTML = visibleVals.map(v =>
      '<button class="np-btn" data-value="'+escAttr(v)+'" aria-label="Insert '+escAttr(v)+'" style="user-select:none;-webkit-user-select:none;cursor:pointer;">' +
      '<span class="np-btn-label" style="user-select:none;-webkit-user-select:none;pointer-events:none;">'+escAttr(v)+'</span>' +
      '<span class="np-btn-ripple"></span></button>'
    ).join('');
    return '<div class="np-grid" id="'+prefix+'-grid" style="--np-cols:'+state.gridCols+';">'+btnHTML+'</div>' +
           '<div class="np-status" id="'+prefix+'-status"></div>';
  }
  function buildSelectorDropdownHTML(prefix, type) {
    const presetId = type === 'input' ? state.inputPresetId : state.submitPresetId;
    const presets = type === 'input' ? state.inputPresets : state.submitPresets;
    const label = type === 'input' ? '⌨️ Input Field' : '🖱️ Submit Button';
    const editingPreset = presets.find(p => p.id === presetId);
    const options = ['<option value="" '+((!presetId)?'selected':'')+'>None</option>']
      .concat(presets.map(p => '<option value="'+escAttr(p.id)+'" '+(p.id===presetId?'selected':'')+'>'+escAttr(p.label)+'</option>'))
      .concat(['<option value="__add_new__">+ Add New</option>']).join('');
    return '<div class="np-sel-group" id="'+prefix+'-'+type+'-sel-group">' +
      '<p class="np-settings-label">'+label+'</p>' +
      '<div class="np-selector-row"><select class="np-sel-dropdown" id="'+prefix+'-'+type+'-dropdown" data-sel-type="'+type+'">'+options+'</select></div>' +
      (editingPreset ?
        '<div class="np-preset-edit-row" id="'+prefix+'-'+type+'-edit-row">' +
        '<input class="np-settings-input np-preset-label-input" id="'+prefix+'-'+type+'-label-inp" type="text" placeholder="Name…" value="'+escAttr(editingPreset.label)+'" maxlength="32">' +
        '<div class="np-selector-input-row">' +
        '<input class="np-settings-input np-preset-value-input" id="'+prefix+'-'+type+'-value-inp" type="text" placeholder="CSS selector…" value="'+escAttr(editingPreset.value)+'" maxlength="256">' +
        '<button class="np-icon-btn np-pick-element-btn" data-action="pick-element" data-preset-type="'+type+'" id="'+prefix+'-'+type+'-pick-btn" title="Tap to activate element picker">' +
        '<svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14"><path fill-rule="evenodd" d="M6.672 1.911a1 1 0 10-1.932.518l.259.966a1 1 0 001.932-.518l-.26-.966zM2.429 4.74a1 1 0 10-.518 1.932l.966.259a1 1 0 00.518-1.932l-.966-.26zm8.814-.569a1 1 0 00-1.415-1.414l-.707.707a1 1 0 101.415 1.415l.707-.708zm-7.071 7.072l.707-.707A1 1 0 003.465 9.12l-.707.707a1 1 0 101.415 1.415zm3.2-5.171a1 1 0 00-1.3 1.3l4 10a1 1 0 001.823.075l1.38-2.759 3.018 3.02a1 1 0 001.414-1.415l-3.019-3.02 2.76-1.379a1 1 0 00-.076-1.822l-10-4z" clip-rule="evenodd"/></svg>' +
        '</button></div>' +
        '<div class="np-preset-actions">' +
        '<button class="np-save-btn np-preset-save-btn" data-action="save-preset" data-preset-type="'+type+'">Save</button>' +
        '<button class="np-icon-btn np-preset-del-btn" data-action="delete-preset" data-preset-type="'+type+'" title="Delete preset" style="color:var(--np-error)">' +
        '<svg viewBox="0 0 20 20" fill="currentColor" width="13" height="13"><path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clip-rule="evenodd"/></svg>' +
        '</button></div></div>'
      : '<div class="np-selector-preview" id="'+prefix+'-'+type+'-preview">'+(presetId && !editingPreset ? 'Preset not found' : 'None selected')+'</div>') +
      '</div>';
  }
  function buildSettingsHTML(prefix) {
    const active = state.activeTab;
    return '<div class="np-tabs">' +
      ['selector','buttons','layout','dock'].map(t =>
        '<button class="np-tab '+(active===t?'np-tab-active':'')+'" data-tab="'+t+'">'+t.charAt(0).toUpperCase()+t.slice(1)+'</button>'
      ).join('') + '</div>' +
      '<div class="np-tab-content '+(active==='selector'?'np-tab-visible':'')+'" data-tab-content="selector">' +
        buildSelectorDropdownHTML(prefix,'input') + buildSelectorDropdownHTML(prefix,'submit') +
        '<div class="np-settings-hint">Select a saved preset or add a new one.</div></div>' +
      '<div class="np-tab-content '+(active==='buttons'?'np-tab-visible':'')+'" data-tab-content="buttons">' +
        '<div class="np-settings-hint" style="margin-bottom:4px;">Each slot is a button value. Leave blank or NONE to hide.</div>' +
        '<div class="np-btn-editor-grid" id="'+prefix+'-btn-editor">' +
        state.buttonValues.map((v,i) =>
          '<div class="np-btn-slot"><span class="np-btn-slot-label">#'+(i+1)+'</span>' +
          '<input class="np-btn-slot-input" type="text" data-slot="'+i+'" value="'+(v==='NONE'?'':escAttr(v))+'" placeholder="NONE" maxlength="8"></div>'
        ).join('') + '</div>' +
        '<button class="np-save-btn" data-action="save-buttons" style="margin-top:8px;">Apply Buttons</button>' +
        '<div class="np-settings-hint">Examples: 0, 2, 3.5, A+, ABS. Empty = hidden.</div></div>' +
      '<div class="np-tab-content '+(active==='layout'?'np-tab-visible':'')+'" data-tab-content="layout">' +
        '<div class="np-settings-hint" style="margin-bottom:4px;">Set grid columns and rows.</div>' +
        '<div class="np-grid-controls">' +
        '<div class="np-grid-ctrl-group"><p class="np-settings-label">Columns</p><input class="np-number-input" id="'+prefix+'-grid-cols" type="number" min="1" max="6" value="'+state.gridCols+'"></div>' +
        '<div class="np-grid-ctrl-group"><p class="np-settings-label">Rows (slots)</p><input class="np-number-input" id="'+prefix+'-grid-rows" type="number" min="1" max="10" value="'+state.gridRows+'"></div>' +
        '</div><button class="np-save-btn" data-action="save-layout" style="margin-top:8px;">Apply Layout</button></div>' +
      '<div class="np-tab-content '+(active==='dock'?'np-tab-visible':'')+'" data-tab-content="dock">' +
        '<div class="np-settings-hint" style="margin-bottom:6px;">Choose which side to dock the sidebar.</div>' +
        '<div class="np-dock-grid">' +
        ['left','right','top','bottom'].map(side =>
          '<button class="np-dock-btn '+(state.sidebarDock===side?'np-dock-active':'')+'" data-action="set-dock" data-dock="'+side+'">'+side.charAt(0).toUpperCase()+side.slice(1)+'</button>'
        ).join('') + '</div></div>';
  }
  function buildSidebarHTML() {
    const numpadHidden = state.floating ? 'style="display:none"' : '';
    const placeholderShown = state.floating ? 'style="display:flex"' : 'style="display:none"';
    return '<div class="np-header">' +
      '<div class="np-header-left">' +
      '<button class="np-icon-btn np-collapse-btn" id="np-collapse-btn" title="'+(state.open?'Collapse':'Expand')+' sidebar" style="user-select:none;">' +
      '<svg class="np-chevron" viewBox="0 0 20 20" fill="currentColor" width="15" height="15"><path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"/></svg>' +
      '</button></div>' +
      '<div class="np-header-actions">' +
      '<button class="np-icon-btn" id="np-float-toggle-btn" title="Detach to floating window" style="user-select:none;">' +
      '<svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14"><path d="M3 5a2 2 0 012-2h4a1 1 0 010 2H5v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H5a2 2 0 01-2-2V5z"/><path d="M15 3h2a1 1 0 011 1v2a1 1 0 11-2 0V5.414l-5.293 5.293a1 1 0 01-1.414-1.414L14.586 4H14a1 1 0 110-2z"/></svg>' +
      '</button>' +
      '<button class="np-icon-btn np-settings-btn" id="np-settings-toggle" title="Settings" style="user-select:none;">' +
      '<svg viewBox="0 0 20 20" fill="currentColor" width="15" height="15"><path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"/></svg>' +
      '</button></div></div>' +
      '<div class="np-settings-panel '+(state.settingsOpen?'np-settings-open':'')+'" id="np-settings-panel">' + buildSettingsHTML('np-sidebar') + '</div>' +
      '<div class="np-pad-area" id="np-pad-area-sidebar" '+numpadHidden+'>' + buildNumpadGridHTML('np-sidebar') + '</div>' +
      '<div id="np-floating-placeholder" '+placeholderShown+' style="flex-direction:column;align-items:center;justify-content:center;padding:24px 16px;gap:10px;color:var(--np-text-muted,#868e96);font-size:11px;text-align:center;flex:1;user-select:none;-webkit-user-select:none;">' +
      '<svg viewBox="0 0 20 20" fill="currentColor" width="24" height="24" style="opacity:0.35;pointer-events:none;"><path d="M3 5a2 2 0 012-2h4a1 1 0 010 2H5v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H5a2 2 0 01-2-2V5z"/><path d="M15 3h2a1 1 0 011 1v2a1 1 0 11-2 0V5.414l-5.293 5.293a1 1 0 01-1.414-1.414L14.586 4H14a1 1 0 110-2z"/></svg>' +
      '<span style="opacity:0.55;">NumPad is floating</span></div>';
  }
  function buildFloatPanelHTML() {
    return '<div class="np-resize-handle-bl" id="np-float-resize-bl">' +
      '<svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor"><path d="M0 12 L12 0 L12 2 L2 12 Z M0 12 L6 12 L12 6 L12 8 L8 12 Z"/></svg></div>' +
      '<div class="np-float-titlebar" id="np-float-titlebar">' +
      '<div class="np-drag-handle" id="np-float-drag-handle" title="Drag to move">' +
      '<svg viewBox="0 0 20 20" fill="currentColor" width="16" height="16"><path d="M7 2a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM13 2a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM7 8a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM13 8a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM7 14a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM13 14a2 2 0 1 1 0 4 2 2 0 0 1 0-4z"/></svg></div>' +
      '<div class="np-float-title-center"><span class="np-float-logo">⌨</span><span class="np-float-label">NumPad</span></div>' +
      '<div class="np-float-actions">' +
      '<button class="np-icon-btn" id="np-float-settings-toggle" title="Settings" style="user-select:none;">' +
      '<svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14"><path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"/></svg></button>' +
      '<button class="np-icon-btn" id="np-dock-btn" title="Dock back to sidebar" style="user-select:none;">' +
      '<svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14"><path fill-rule="evenodd" d="M3 4a1 1 0 011-1h12a1 1 0 011 1v12a1 1 0 01-1 1H4a1 1 0 01-1-1V4zm2 1v10h10V5H5z" clip-rule="evenodd"/><path d="M8 9a1 1 0 011-1h2a1 1 0 010 2H9a1 1 0 01-1-1z"/></svg></button>' +
      '</div></div>' +
      '<div class="np-settings-panel" id="np-float-settings-panel">' + buildSettingsHTML('np-float') + '</div>' +
      '<div class="np-float-body">' + buildNumpadGridHTML('np-float') + '</div>';
  }

  // ── DOM INJECTION ─────────────────────────────────────────────────────────
  function inject() {
    if (document.getElementById(IDs.LAYOUT_ROOT)) return;
    const scrollX = window.scrollX || 0, scrollY = window.scrollY || 0;
    const layoutRoot = document.createElement('div'); layoutRoot.id = IDs.LAYOUT_ROOT;
    const pageContainer = document.createElement('div'); pageContainer.id = IDs.PAGE_CONTAINER;
    const sidebarWrapper = document.createElement('aside'); sidebarWrapper.id = IDs.SIDEBAR_WRAPPER;
    const sidebarW = computeSidebarSize();
    applySidebarSize(sidebarWrapper, sidebarW);
    const sidebarContent = document.createElement('div'); sidebarContent.id = IDs.SIDEBAR_CONTENT;
    sidebarContent.innerHTML = buildSidebarHTML();
    const resizer = document.createElement('div'); resizer.id = IDs.RESIZER; resizer.className = 'np-resizer'; resizer.title = 'Drag to resize';
    sidebarWrapper.appendChild(resizer); sidebarWrapper.appendChild(sidebarContent);
    while (document.body.firstChild) pageContainer.appendChild(document.body.firstChild);
    layoutRoot.appendChild(pageContainer); layoutRoot.appendChild(sidebarWrapper);
    document.body.appendChild(layoutRoot);
    applyLayoutStyles(); window.scrollTo(scrollX, scrollY);
    attachSidebarListeners();
    if (!state.enabled) applySidebarVisibility(false);
    if (state.floating) createFloatPanel();
  }
  function computeSidebarSize() {
    if (!state.enabled) return 0;
    if (state.floating) return 32;
    return state.open ? state.width : 32;
  }
  function applySidebarSize(wrapper, size) {
    const dock = state.sidebarDock || 'right';
    const isHoriz = dock === 'top' || dock === 'bottom';
    if (isHoriz) { wrapper.style.height = size + 'px'; wrapper.style.width = ''; }
    else { wrapper.style.width = size + 'px'; wrapper.style.height = ''; }
  }

  // ── ENABLE/DISABLE ────────────────────────────────────────────────────────
  function applySidebarVisibility(show) {
    const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER);
    if (!wrapper) return;
    if (!show) {
      wrapper.style.width = '0px'; wrapper.style.height = '0px'; wrapper.style.overflow = 'hidden';
      const fp = document.getElementById(IDs.FLOAT_PANEL); if (fp) fp.style.display = 'none';
    } else {
      wrapper.style.overflow = ''; applySidebarSize(wrapper, computeSidebarSize());
      const fp = document.getElementById(IDs.FLOAT_PANEL); if (fp) fp.style.display = '';
    }
  }
  function toggleEnabled() {
    state.enabled = !state.enabled; persist();
    applySidebarVisibility(state.enabled);
  }

  // ── FLOATING PANEL ────────────────────────────────────────────────────────
  function createFloatPanel() {
    removeFloatPanel();
    const panel = document.createElement('div'); panel.id = IDs.FLOAT_PANEL;
    panel.innerHTML = buildFloatPanelHTML();
    const vw = window.innerWidth, vh = window.innerHeight;
    state.floatX = Math.max(0, Math.min(state.floatX, vw - MIN_FLOAT_W));
    state.floatY = Math.max(0, Math.min(state.floatY, vh - MIN_FLOAT_H));
    panel.style.left = state.floatX + 'px'; panel.style.top = state.floatY + 'px';
    if (state.floatW > 0) { panel.style.width = state.floatW + 'px'; panel.style.height = state.floatH + 'px'; }
    if (!state.enabled) panel.style.display = 'none';
    document.documentElement.appendChild(panel);
    if (state.floatW === 0) {
      requestAnimationFrame(() => {
        const rect = panel.getBoundingClientRect();
        state.floatW = Math.round(rect.width); state.floatH = Math.round(rect.height);
        panel.style.width = state.floatW + 'px'; panel.style.height = state.floatH + 'px'; persist();
      });
    }
    attachFloatListeners(panel);
  }
  function removeFloatPanel() { const p = document.getElementById(IDs.FLOAT_PANEL); if (p) p.remove(); }
  function enterFloating() {
    state.floating = true; state.floatW = 0; persist();
    const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER); if (wrapper) applySidebarSize(wrapper, 32);
    const padArea = document.getElementById('np-pad-area-sidebar');
    const placeholder = document.getElementById('np-floating-placeholder');
    if (padArea) padArea.style.display = 'none'; if (placeholder) placeholder.style.display = 'flex';
    createFloatPanel();
  }
  function exitFloating() {
    state.floating = false; persist(); removeFloatPanel();
    const padArea = document.getElementById('np-pad-area-sidebar');
    const placeholder = document.getElementById('np-floating-placeholder');
    if (padArea) padArea.style.display = ''; if (placeholder) placeholder.style.display = 'none';
    const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER);
    if (wrapper) applySidebarSize(wrapper, state.enabled ? (state.open ? state.width : 32) : 0);
    bindNumpadButtons('np-sidebar');
  }

  // ── SIDEBAR LISTENERS ─────────────────────────────────────────────────────
  function attachSidebarListeners() {
    document.getElementById('np-collapse-btn')?.addEventListener('click', toggleSidebar);
    document.getElementById('np-settings-toggle')?.addEventListener('click', () => toggleSettings('np-settings-panel'));
    document.getElementById('np-float-toggle-btn')?.addEventListener('click', enterFloating);
    const settingsPanel = document.getElementById('np-settings-panel');
    if (settingsPanel) attachSettingsPanelListeners(settingsPanel, 'np-sidebar');
    bindNumpadButtons('np-sidebar');
    initSidebarResizer();
  }
  function attachFloatListeners(panel) {
    panel.querySelector('#np-dock-btn')?.addEventListener('click', exitFloating);
    panel.querySelector('#np-float-settings-toggle')?.addEventListener('click', () => toggleSettings('np-float-settings-panel'));
    const settingsPanel = panel.querySelector('#np-float-settings-panel');
    if (settingsPanel) attachSettingsPanelListeners(settingsPanel, 'np-float');
    bindNumpadButtons('np-float'); initFloatDrag(panel); initFloatResize(panel);
  }

  // ── SETTINGS PANEL LOGIC ──────────────────────────────────────────────────
  function attachSettingsPanelListeners(panel, prefix) {
    panel.querySelectorAll('.np-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        const tabName = tab.dataset.tab; state.activeTab = tabName;
        document.querySelectorAll('.np-tab').forEach(t => t.classList.toggle('np-tab-active', t.dataset.tab === tabName));
        document.querySelectorAll('.np-tab-content').forEach(c => c.classList.toggle('np-tab-visible', c.dataset.tabContent === tabName));
        persist();
      });
    });
    const selectorTab = panel.querySelector('[data-tab-content="selector"]');
    if (selectorTab) attachSelectorTabListeners(selectorTab, prefix);
    panel.addEventListener('click', (e) => {
      const actionEl = e.target.closest('[data-action]'); if (!actionEl) return;
      const action = actionEl.dataset.action;
      if (action === 'save-buttons') {
        const inputs = panel.querySelectorAll('.np-btn-slot-input');
        state.buttonValues = Array.from(inputs).map(inp => { const v = inp.value.trim(); return v === '' ? 'NONE' : v; });
        persist(); rebuildAllNumpadGrids(); showStatus(prefix+'-status','Buttons updated ✓','success');
      }
      if (action === 'save-layout') {
        const colsEl = panel.querySelector('#'+prefix+'-grid-cols');
        const rowsEl = panel.querySelector('#'+prefix+'-grid-rows');
        const cols = Math.max(1, Math.min(6, parseInt(colsEl?.value) || DEFAULT_COLS));
        const rows = Math.max(1, Math.min(10, parseInt(rowsEl?.value) || DEFAULT_ROWS));
        state.gridCols = cols; state.gridRows = rows;
        const newLen = rows * cols;
        while (state.buttonValues.length < newLen) state.buttonValues.push('NONE');
        state.buttonValues = state.buttonValues.slice(0, newLen);
        persist(); rebuildAll(); showStatus(prefix+'-status','Layout updated ✓','success');
      }
      if (action === 'set-dock') {
        const newDock = actionEl.dataset.dock; state.sidebarDock = newDock; persist();
        document.querySelectorAll('[data-action="set-dock"]').forEach(b => b.classList.toggle('np-dock-active', b.dataset.dock === newDock));
        applyLayoutStyles();
        const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER); if (wrapper) applySidebarSize(wrapper, computeSidebarSize());
        initSidebarResizer();
      }
    });
  }
  function attachSelectorTabListeners(tabEl, prefix) {
    tabEl.querySelectorAll('.np-sel-dropdown').forEach(sel => {
      sel.addEventListener('change', () => {
        const type = sel.dataset.selType, val = sel.value;
        const presets = type === 'input' ? state.inputPresets : state.submitPresets;
        if (val === '__add_new__') {
          const newId = 'preset_' + Date.now(); presets.push({ id: newId, label: 'New Selector', value: '' });
          if (type === 'input') { state.inputPresetId = newId; state.inputSelector = ''; }
          else { state.submitPresetId = newId; state.submitSelector = ''; }
          persist(); rebuildAllSelectorDropdowns();
        } else if (val === '') {
          if (type === 'input') { state.inputPresetId = ''; state.inputSelector = ''; }
          else { state.submitPresetId = ''; state.submitSelector = ''; }
          persist(); rebuildAllSelectorDropdowns();
        } else {
          const preset = presets.find(p => p.id === val);
          if (preset) {
            if (type === 'input') { state.inputPresetId = val; state.inputSelector = preset.value; }
            else { state.submitPresetId = val; state.submitSelector = preset.value; }
            persist(); rebuildAllSelectorDropdowns();
          }
        }
      });
    });
    tabEl.addEventListener('click', (e) => {
      const actionEl = e.target.closest('[data-action]'); if (!actionEl) return;
      const action = actionEl.dataset.action;
      if (action === 'save-preset') {
        const type = actionEl.dataset.presetType;
        const presetId = type === 'input' ? state.inputPresetId : state.submitPresetId;
        const presets = type === 'input' ? state.inputPresets : state.submitPresets;
        const preset = presets.find(p => p.id === presetId); if (!preset) return;
        const labelInp = tabEl.querySelector('#'+prefix+'-'+type+'-label-inp');
        const valueInp = tabEl.querySelector('#'+prefix+'-'+type+'-value-inp');
        if (labelInp) preset.label = labelInp.value.trim() || preset.label;
        if (valueInp) { preset.value = valueInp.value.trim(); if (type === 'input') state.inputSelector = preset.value; else state.submitSelector = preset.value; }
        persist(); rebuildAllSelectorDropdowns();
      }
      if (action === 'delete-preset') {
        const type = actionEl.dataset.presetType;
        const presetId = type === 'input' ? state.inputPresetId : state.submitPresetId;
        if (type === 'input') { state.inputPresets = state.inputPresets.filter(p => p.id !== presetId); state.inputPresetId = ''; state.inputSelector = ''; }
        else { state.submitPresets = state.submitPresets.filter(p => p.id !== presetId); state.submitPresetId = ''; state.submitSelector = ''; }
        persist(); rebuildAllSelectorDropdowns();
      }
      if (action === 'pick-element') {
        const type = actionEl.dataset.presetType;
        const valueInp = tabEl.querySelector('#'+prefix+'-'+type+'-value-inp'); if (!valueInp) return;
        const highlight = document.createElement('div');
        highlight.id = '__ep-picker-highlight';
        highlight.style.cssText = 'position:fixed;pointer-events:none;z-index:2147483647;outline:2px solid #3b82f6;background:rgba(59,130,246,0.1);transition:none;box-sizing:border-box;';
        document.body.appendChild(highlight);
        document.body.style.cursor = 'crosshair';
        let lastTarget = null;
        const onMove = (e) => {
          const clientX = e.clientX !== undefined ? e.clientX : e.touches[0].clientX;
          const clientY = e.clientY !== undefined ? e.clientY : e.touches[0].clientY;
          const el = document.elementFromPoint(clientX, clientY);
          if (!el || el === highlight || lastTarget === el) return;
          lastTarget = el;
          const r = el.getBoundingClientRect();
          highlight.style.left = r.left+'px'; highlight.style.top = r.top+'px';
          highlight.style.width = r.width+'px'; highlight.style.height = r.height+'px';
        };
        const cleanup = () => {
          document.removeEventListener('mousemove', onMove, true);
          document.removeEventListener('click', onClick, true);
          document.removeEventListener('touchmove', onMove, true);
          document.removeEventListener('touchend', onTouch, true);
          document.removeEventListener('keydown', onKey, true);
          highlight.remove(); document.body.style.cursor = '';
        };
        const doSelect = (clientX, clientY) => {
          const el = document.elementFromPoint(clientX, clientY); if (!el) return;
          const selector = el.id ? el.tagName.toLowerCase()+'#'+CSS.escape(el.id) : generateSelector(el);
          if (!selector) return;
          valueInp.value = selector;
          const presetId = type === 'input' ? state.inputPresetId : state.submitPresetId;
          const presets = type === 'input' ? state.inputPresets : state.submitPresets;
          const preset = presets.find(p => p.id === presetId);
          if (preset) { preset.value = selector; if (type === 'input') state.inputSelector = selector; else state.submitSelector = selector; persist(); }
        };
        const onClick = (e) => { e.preventDefault(); e.stopPropagation(); cleanup(); doSelect(e.clientX, e.clientY); };
        const onTouch = (e) => { e.preventDefault(); e.stopPropagation(); cleanup(); doSelect(e.changedTouches[0].clientX, e.changedTouches[0].clientY); };
        const onKey = (e) => { if (e.key === 'Escape') cleanup(); };
        document.addEventListener('mousemove', onMove, true);
        document.addEventListener('click', onClick, true);
        document.addEventListener('touchmove', onMove, { capture: true, passive: false });
        document.addEventListener('touchend', onTouch, { capture: true, passive: false });
        document.addEventListener('keydown', onKey, true);
      }
    });
  }
  function rebuildAllSelectorDropdowns() {
    ['np-sidebar','np-float'].forEach(prefix => {
      const panelId = prefix === 'np-sidebar' ? 'np-settings-panel' : 'np-float-settings-panel';
      const panel = document.getElementById(panelId); if (!panel) return;
      const selectorTab = panel.querySelector('[data-tab-content="selector"]'); if (!selectorTab) return;
      selectorTab.innerHTML = buildSelectorDropdownHTML(prefix,'input') + buildSelectorDropdownHTML(prefix,'submit') +
        '<div class="np-settings-hint">Select a saved preset or add a new one.</div>';
      attachSelectorTabListeners(selectorTab, prefix);
    });
  }
  function rebuildAllNumpadGrids() {
    ['np-sidebar','np-float'].forEach(prefix => {
      const grid = document.getElementById(prefix+'-grid'); if (!grid) return;
      grid.style.setProperty('--np-cols', state.gridCols);
      const visibleVals = state.buttonValues.filter(v => v && v !== 'NONE');
      grid.innerHTML = visibleVals.map(v =>
        '<button class="np-btn" data-value="'+escAttr(v)+'" style="user-select:none;-webkit-user-select:none;cursor:pointer;">' +
        '<span class="np-btn-label" style="user-select:none;pointer-events:none;">'+escAttr(v)+'</span>' +
        '<span class="np-btn-ripple"></span></button>'
      ).join('');
      bindNumpadButtons(prefix);
    });
  }
  function rebuildAll() {
    const sidebarContent = document.getElementById(IDs.SIDEBAR_CONTENT);
    if (sidebarContent) { sidebarContent.innerHTML = buildSidebarHTML(); attachSidebarListeners(); }
    if (state.floating) createFloatPanel();
  }

  // ── NUMPAD BUTTONS ────────────────────────────────────────────────────────
  function bindNumpadButtons(prefix) {
    const grid = document.getElementById(prefix+'-grid'); if (!grid) return;
    grid.querySelectorAll('.np-btn').forEach(btn => {
      const fresh = btn.cloneNode(true); btn.parentNode.replaceChild(fresh, btn);
      fresh.addEventListener('click', (e) => { triggerRipple(fresh, e); handleNumpadClick(fresh.dataset.value, prefix+'-status'); });
      fresh.addEventListener('touchend', (e) => { e.preventDefault(); const touch = e.changedTouches[0]; triggerRipple(fresh, touch); handleNumpadClick(fresh.dataset.value, prefix+'-status'); }, { passive: false });
    });
  }
  function handleNumpadClick(value, statusId) {
    if (!state.enabled) return;
    const sel = state.inputSelector;
    if (!sel) { showStatus(statusId,'Set an input selector first','warn'); return; }
    const pageContainer = document.getElementById(IDs.PAGE_CONTAINER);
    const searchRoot = pageContainer || document;
    const input = searchRoot.querySelector(sel);
    if (!input) { showStatus(statusId,'No element: '+sel,'error'); return; }
    const nativeValueSetter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(input),'value');
    if (nativeValueSetter && nativeValueSetter.set) { nativeValueSetter.set.call(input, value); } else { input.value = value; }
    ['input','change'].forEach(evtName => input.dispatchEvent(new Event(evtName, { bubbles: true, cancelable: true })));
    input.dispatchEvent(new Event('blur', { bubbles: true }));
    showStatus(statusId,'Inserted '+value,'success');
    const submitSel = state.submitSelector;
    if (submitSel) {
      const submitBtn = searchRoot.querySelector(submitSel);
      if (submitBtn) { setTimeout(() => { submitBtn.click(); showStatus(statusId,'Submitted → '+value,'success'); }, 80); }
      else { showStatus(statusId,'Submit not found: '+submitSel,'warn'); }
    }
  }

  // ── SIDEBAR COLLAPSE/SETTINGS ─────────────────────────────────────────────
  function toggleSidebar() {
    if (state.floating) return;
    state.open = !state.open; persist();
    const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER);
    if (wrapper) applySidebarSize(wrapper, state.open ? state.width : 32);
  }
  function toggleSettings(panelId) {
    const panel = document.getElementById(panelId); if (!panel) return;
    const isOpen = panel.classList.toggle('np-settings-open'); state.settingsOpen = isOpen; persist();
  }

  // ── FLOAT DRAG ────────────────────────────────────────────────────────────
  function initFloatDrag(panel) {
    const handle = panel.querySelector('#np-float-drag-handle'); if (!handle) return;
    handle.addEventListener('mousedown', (e) => {
      if (e.target.closest('button')) return; e.preventDefault();
      const startMX = e.clientX, startMY = e.clientY, startPX = state.floatX, startPY = state.floatY;
      lockSelect();
      const onMove = (e) => {
        const vw = window.innerWidth, vh = window.innerHeight, w = panel.offsetWidth, h = panel.offsetHeight;
        state.floatX = Math.max(0, Math.min(vw-w, startPX+(e.clientX-startMX)));
        state.floatY = Math.max(0, Math.min(vh-h, startPY+(e.clientY-startMY)));
        panel.style.left = state.floatX+'px'; panel.style.top = state.floatY+'px';
      };
      const onUp = () => { unlockSelect(); document.removeEventListener('mousemove',onMove); document.removeEventListener('mouseup',onUp); persist(); };
      document.addEventListener('mousemove',onMove); document.addEventListener('mouseup',onUp);
    });
    handle.addEventListener('touchstart', (e) => {
      if (e.touches.length !== 1) return; e.preventDefault();
      const t0 = e.touches[0], startTX = t0.clientX, startTY = t0.clientY, startPX = state.floatX, startPY = state.floatY;
      const onMove = (e) => {
        const t = e.touches[0], vw = window.innerWidth, vh = window.innerHeight, w = panel.offsetWidth, h = panel.offsetHeight;
        state.floatX = Math.max(0, Math.min(vw-w, startPX+(t.clientX-startTX)));
        state.floatY = Math.max(0, Math.min(vh-h, startPY+(t.clientY-startTY)));
        panel.style.left = state.floatX+'px'; panel.style.top = state.floatY+'px';
      };
      const onEnd = () => { handle.removeEventListener('touchmove',onMove); handle.removeEventListener('touchend',onEnd); persist(); };
      handle.addEventListener('touchmove',onMove,{passive:false}); handle.addEventListener('touchend',onEnd);
    }, {passive:false});
  }

  // ── FLOAT RESIZE ──────────────────────────────────────────────────────────
  function initFloatResize(panel) {
    const handle = panel.querySelector('#np-float-resize-bl'); if (!handle) return;
    handle.addEventListener('mousedown', (e) => {
      e.preventDefault(); e.stopPropagation();
      const startX = e.clientX, startY = e.clientY, startW = panel.offsetWidth, startH = panel.offsetHeight, startL = state.floatX;
      lockSelect();
      const onMove = (e) => {
        const dx = e.clientX-startX, dy = e.clientY-startY;
        state.floatW = Math.max(MIN_FLOAT_W, Math.round(startW-dx));
        state.floatH = Math.max(MIN_FLOAT_H, Math.round(startH+dy));
        state.floatX = Math.round(startL+(startW-state.floatW));
        panel.style.width = state.floatW+'px'; panel.style.height = state.floatH+'px'; panel.style.left = state.floatX+'px';
      };
      const onUp = () => { unlockSelect(); document.removeEventListener('mousemove',onMove); document.removeEventListener('mouseup',onUp); persist(); };
      document.addEventListener('mousemove',onMove); document.addEventListener('mouseup',onUp);
    });
    handle.addEventListener('touchstart', (e) => {
      if (e.touches.length !== 1) return; e.preventDefault(); e.stopPropagation();
      const t0 = e.touches[0], startX = t0.clientX, startY = t0.clientY, startW = panel.offsetWidth, startH = panel.offsetHeight, startL = state.floatX;
      const onMove = (e) => {
        const t = e.touches[0], dx = t.clientX-startX, dy = t.clientY-startY;
        state.floatW = Math.max(MIN_FLOAT_W, Math.round(startW-dx));
        state.floatH = Math.max(MIN_FLOAT_H, Math.round(startH+dy));
        state.floatX = Math.round(startL+(startW-state.floatW));
        panel.style.width = state.floatW+'px'; panel.style.height = state.floatH+'px'; panel.style.left = state.floatX+'px';
      };
      const onEnd = () => { handle.removeEventListener('touchmove',onMove); handle.removeEventListener('touchend',onEnd); persist(); };
      handle.addEventListener('touchmove',onMove,{passive:false}); handle.addEventListener('touchend',onEnd);
    }, {passive:false});
  }

  // ── SIDEBAR RESIZER ───────────────────────────────────────────────────────
  function initSidebarResizer() {
    const oldResizer = document.getElementById(IDs.RESIZER); if (!oldResizer) return;
    const resizer = oldResizer.cloneNode(true); oldResizer.parentNode.replaceChild(resizer, oldResizer);
    function startResize(startX, startY, startWidth) {
      lockSelect();
      const dock = state.sidebarDock || 'right', isHoriz = dock === 'top' || dock === 'bottom';
      document.body.style.cursor = isHoriz ? 'ns-resize' : 'ew-resize';
      const onMove = (clientX, clientY) => {
        let newSize;
        if (isHoriz) { const delta = dock==='top' ? startY-clientY : clientY-startY; newSize = Math.min(MAX_WIDTH, Math.max(MIN_WIDTH, startWidth+delta)); }
        else { const delta = startX-clientX; newSize = Math.min(MAX_WIDTH, Math.max(MIN_WIDTH, startWidth+delta)); }
        state.width = newSize;
        const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER); if (wrapper) applySidebarSize(wrapper, newSize);
      };
      const onEnd = () => {
        document.removeEventListener('mousemove', onMouseMove); document.removeEventListener('mouseup', onEnd);
        document.removeEventListener('touchmove', onTouchMove); document.removeEventListener('touchend', onEnd);
        unlockSelect(); document.body.style.cursor = ''; persist();
      };
      const onMouseMove = (e) => onMove(e.clientX, e.clientY);
      const onTouchMove = (e) => onMove(e.touches[0].clientX, e.touches[0].clientY);
      document.addEventListener('mousemove',onMouseMove); document.addEventListener('mouseup',onEnd);
      document.addEventListener('touchmove',onTouchMove,{passive:false}); document.addEventListener('touchend',onEnd);
    }
    resizer.addEventListener('mousedown', (e) => { const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER); startResize(e.clientX, e.clientY, wrapper?.offsetWidth || DEFAULT_WIDTH); e.preventDefault(); });
    resizer.addEventListener('touchstart', (e) => { const wrapper = document.getElementById(IDs.SIDEBAR_WRAPPER); startResize(e.touches[0].clientX, e.touches[0].clientY, wrapper?.offsetWidth || DEFAULT_WIDTH); e.preventDefault(); }, {passive:false});
  }

  // ── UTILITIES ─────────────────────────────────────────────────────────────
  function lockSelect() { document.documentElement.style.userSelect='none'; document.documentElement.style.webkitUserSelect='none'; }
  function unlockSelect() { document.documentElement.style.userSelect=''; document.documentElement.style.webkitUserSelect=''; }
  const statusTimers = {};
  function showStatus(statusId, msg, type) {
    type = type || 'success';
    const el = document.getElementById(statusId); if (!el) return;
    el.textContent = msg; el.className = 'np-status np-status-'+type+' np-status-visible';
    clearTimeout(statusTimers[statusId]);
    statusTimers[statusId] = setTimeout(() => el.classList.remove('np-status-visible'), 2500);
  }
  function triggerRipple(btn, e) {
    const ripple = btn.querySelector('.np-btn-ripple'); if (!ripple) return;
    const rect = btn.getBoundingClientRect(), size = Math.max(rect.width, rect.height);
    const x = (e.clientX != null ? e.clientX : rect.left+rect.width/2) - rect.left - size/2;
    const y = (e.clientY != null ? e.clientY : rect.top+rect.height/2) - rect.top - size/2;
    ripple.style.cssText = 'width:'+size+'px;height:'+size+'px;top:'+y+'px;left:'+x+'px;';
    ripple.classList.remove('np-ripple-active'); void ripple.offsetWidth; ripple.classList.add('np-ripple-active');
  }

  // ── SPA WATCHER ───────────────────────────────────────────────────────────
  function watchForLayoutChanges() {
    const observer = new MutationObserver(() => {
      if (!document.getElementById(IDs.LAYOUT_ROOT)) setTimeout(() => inject(), 0);
    });
    observer.observe(document.body, { childList: true, subtree: false });
  }

  // ── BOOT ──────────────────────────────────────────────────────────────────
  function init() {
    if (document.body) { inject(); watchForLayoutChanges(); }
    else { document.addEventListener('DOMContentLoaded', () => { inject(); watchForLayoutChanges(); }); }
  }

  loadState(init);
})();
""".trimIndent()
}

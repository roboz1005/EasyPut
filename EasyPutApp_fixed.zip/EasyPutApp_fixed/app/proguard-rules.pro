# EasyPut ProGuard rules
# Keep JavaScript interface methods (called via WebView)
-keepclassmembers class com.easyput.udvash.AndroidStorageBridge {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep all public members of the main package
-keep public class com.easyput.udvash.** { *; }
